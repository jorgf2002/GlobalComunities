﻿# Host: localhost  (Version: 5.5.24-log)
# Date: 2015-10-29 07:54:57
# Generator: MySQL-Front 5.3  (Build 4.234)

/*!40101 SET NAMES utf8 */;

#
# Structure for table "actividad"
#

DROP TABLE IF EXISTS `actividad`;
CREATE TABLE `actividad` (
  `id_actividad` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_act` varchar(100) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `sigla_act` varchar(20) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `activo` int(11) NOT NULL,
  PRIMARY KEY (`id_actividad`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

#
# Data for table "actividad"
#

INSERT INTO `actividad` VALUES (1,'Reunion','R',0),(2,'Asamblea Comunitaria','Asm',0),(5,'Sesion de trabajo','ST',0),(6,'Visita de Seguimiento','Vs',0),(7,'Evento de Formacion','EF',0),(8,'Evento ICO','ICO',0),(10,'Brigada de Salud','BG',0),(11,'Grados','GR',0),(12,'Ferias Empresariales','FE',0),(13,'Iniciativa de Integracion Comunitaria','IIC',0),(14,'Acto Simbolico','',0),(15,'Replica Psicosocial','',0),(16,'Acompañamiento Psicosocial','JAP',0),(17,'Trabajo Comunidad Educativa','TCE',0),(18,'Replica de Genero','',0),(19,'Replica de Salud','',0);

#
# Structure for table "cargo"
#

DROP TABLE IF EXISTS `cargo`;
CREATE TABLE `cargo` (
  `idcargo` int(12) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `activo` int(10) DEFAULT '0',
  `perfil` int(11) NOT NULL,
  PRIMARY KEY (`idcargo`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

#
# Data for table "cargo"
#

INSERT INTO `cargo` VALUES (1,'M&E',0,0),(2,'Gerente',0,0),(3,'Coordinacion Desarrollo Comunitario',0,0),(4,'Coordinacion Fortalecimiento Institucional',0,0),(5,'Coordinacion Desarrollo Economico',0,0),(6,'Coordinacion de Generación de Ingresos',0,0),(7,'Coordinacion de Infraestructura',0,0),(8,'Coordinacion de Seguridad',0,0),(9,'Coordinacion de Comunicaciones',0,0),(10,'Coordinacion Financiera y Administrativa',0,0),(11,'Contratista',0,1),(12,'Ejecutor',0,1),(13,'Enlace Profesional',0,1),(14,'Coordinadora Fortalecimiento Comunitario',0,0),(15,'Contratista',0,2),(16,'Operdaor',0,2),(17,'Facilitador',0,2),(18,'Coordinador Jr',0,2),(19,'Profesional de Apoyo',0,2);

#
# Structure for table "cargo_u"
#

DROP TABLE IF EXISTS `cargo_u`;
CREATE TABLE `cargo_u` (
  `id_cargo` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_carg` varchar(60) NOT NULL,
  `activo` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_cargo`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

#
# Data for table "cargo_u"
#

INSERT INTO `cargo_u` VALUES (1,'Contratista',0),(2,'Operador',0),(3,'Facilitador',0),(4,'Coordinador Jr',0),(5,'Profesional de Apoyo',0);

#
# Structure for table "comunidad"
#

DROP TABLE IF EXISTS `comunidad`;
CREATE TABLE `comunidad` (
  `id_comunidad` int(11) NOT NULL AUTO_INCREMENT,
  `comunidad` varchar(100) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `id_municipio` int(11) NOT NULL,
  `activo` int(11) NOT NULL,
  PRIMARY KEY (`id_comunidad`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8;

#
# Data for table "comunidad"
#

INSERT INTO `comunidad` VALUES (1,'El Viajano',6,0),(2,'Mejor Esquina',6,0),(3,'Mejor Esquina_ Bellavista',6,0),(4,'Mejor Esquina_ La Linea',6,0),(5,'Mejor Esquina_ Las Barras',6,0),(6,'Villa Fatima',6,0),(7,'Villa Fatima-Manzanare',6,0),(8,'Belén (Casco Poblado)',6,0),(9,'Belén_Calle Larga',6,0),(10,'Tierra Santa',6,0),(11,'Coyongo',6,0),(12,'Campo Alegre',1,0),(13,'La Balsa',1,0),(14,'El Retorno y La Florida',1,0),(15,'Divino Niño',1,0),(16,'El Oriente',1,0),(17,'Tierra Santa',1,0),(18,'24 de Noviembre',1,0),(19,'Córdoba - Margarita',3,0),(20,'El Anclar',2,0),(21,'El Anclar_ Caracoles',2,0),(22,'Pica-Pica Nuevo',2,0),(23,'Pica-Pica Nuevo_Las Arañas',2,0),(24,'Pica-Pica Nuevo_El Rosario',2,0),(25,'Pica-Pica Nuevo_Cruces Nuevas',2,0),(26,'Pica-Pica Nuevo_Calle Larga',2,0),(27,'Porvenir II Inurbe',2,0),(28,'Porvenir la Unión',2,0),(29,'No Hay Como Dios (Tierradentro)',2,0),(30,'Cgto. El Palmar',2,0),(31,'26 de Octubre (Tierradentro)',2,0),(32,'Alcides Fernández (Tierradentro)',2,0),(33,'Campo Bello',3,0),(34,'Centro Alegre',3,0),(35,'Marañonal',3,0),(36,'Marañonal_Guarica',3,0),(37,'Marañonal_Marimba',3,0),(38,'Marañonal_Primavera',3,0),(39,'Marañonal_Guayabo',3,0),(40,'Plaza Bonita - Centro Poblado',3,0),(41,'Arenoso',3,0),(42,'El Almendro',3,0),(43,'Primero Planeta',3,0),(44,'Pica-Pica Viejo',4,0),(45,'Pica-Pica Viejo_Moralito ',4,0),(46,'Pica-Pica Viejo_Nuevo Montevideo',4,0),(47,'Rioverde Santafé de Las Claras',4,0),(48,'Nueva Esperanza y Santa Isabel',4,0),(49,'Ramón Rubio',4,0),(50,'Siete de Septiembre',4,0),(51,'Cgto. La Rica',4,0),(52,'Cgto. La Rica_Iraca',4,0),(53,'Cgto. Villanueva',4,0),(54,'La Dorada',5,0),(55,'Parcelas de Campamento sectores Miami ',5,0),(56,'Parcelas de Campamento sectores  El Brillante',5,0),(57,'Parcelas de Campamento sectores Alto Don Pio',5,0),(58,'Parcelas de Campamento sectores Santa Marta',5,0),(59,'Versalles',5,0),(60,'Pueblo Nuevo',5,0),(61,'San José',5,0),(62,'Rabo Largo',5,0);

#
# Structure for table "cronograma"
#

DROP TABLE IF EXISTS `cronograma`;
CREATE TABLE `cronograma` (
  `id_cronograma` int(11) NOT NULL AUTO_INCREMENT,
  `id_comunidad` varchar(250) CHARACTER SET utf8 NOT NULL DEFAULT '0',
  `fecha` date NOT NULL,
  `hora_i` varchar(10) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `hora_f` varchar(10) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `id_actividad` int(11) NOT NULL,
  `id_operador` int(11) NOT NULL,
  `descripcion` varchar(500) CHARACTER SET utf16 COLLATE utf16_bin NOT NULL,
  `id_estado` int(11) NOT NULL,
  `activo` int(11) NOT NULL,
  `id_anterior` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `idpoblacion` int(10) NOT NULL,
  `lugar` varchar(120) CHARACTER SET utf8 NOT NULL DEFAULT '0',
  `realizada` int(11) NOT NULL DEFAULT '0',
  `aval` int(11) NOT NULL DEFAULT '0',
  `casco` varchar(25) CHARACTER SET utf8 DEFAULT '1',
  PRIMARY KEY (`id_cronograma`)
) ENGINE=InnoDB AUTO_INCREMENT=200 DEFAULT CHARSET=latin1;

#
# Data for table "cronograma"
#

INSERT INTO `cronograma` VALUES (1,'25','2015-08-05','20:30','10:40',1,1,'prueba 1',0,0,1,1,1,'',0,0,NULL),(2,'30','2015-09-01','02:30','16:00',1,1,'fffgffgfgfgfgfgffgfgfgfgffgfgfgfgfgfgfgfgfgfgf   fgfgf gfg fgfg fg',1,1,1,2,2,'3',1,1,'1'),(3,'16','2015-08-05','09:00','12:00',7,11,'Grupo productivo marimba',0,0,1,16,2,'',0,0,NULL),(4,'36','2015-08-05','09:00','13:00',7,11,'evento eca',0,0,1,16,2,'',1,0,NULL),(5,'35','2015-09-01','08:00','12:00',7,11,'Evento ECA',0,0,1,16,2,'',0,1,NULL),(6,'36','2015-09-01','08:00','12:00',7,11,'evento eca',0,0,1,16,2,'',0,1,NULL),(7,'5','2015-08-01','09:00','01:00',7,11,'Asociatividad',0,0,0,16,2,'',0,0,NULL),(8,'16','2015-09-01','9:00 am','12:00 pm',7,5,'Evento ECA, Daicy Alvarez, Ricario Santana',0,0,0,7,2,'',0,1,NULL),(9,'22','2015-09-01','09:00','12:00',7,11,'Asistencia tÃ©cnica, Jorge Montiel',0,0,0,16,2,'',0,1,NULL),(10,'36','2015-09-01','13:00','16:00',7,11,'evento eca',0,0,1,16,2,'',0,1,NULL),(11,'10','2015-09-03','13:00','17:00',7,11,'William Romero, Evento ECA',0,0,0,16,2,'',0,1,NULL),(12,'24','2015-09-02','09:00','12:00',7,11,'Asistencia tÃ©cnica',0,0,0,16,2,'',0,1,NULL),(13,'9','2015-09-02','11:00','14:00',7,11,'Asistencia TÃ©cnica',0,0,0,16,2,'',0,1,NULL),(14,'2','2015-09-04','08:00','12:00',7,11,'evento eca',0,0,0,16,1,'',0,1,NULL),(15,'1','2015-09-04','13:00','16:00',7,11,'evento eca Francia pinilla',0,0,0,16,1,'',0,1,NULL),(16,'15','2015-09-01','09:00','13:00',7,11,'Evento ECA',0,0,0,16,1,'',0,1,NULL),(17,'22','2015-09-02','14:00','17:30',7,11,'Evento ECA James Caro',0,0,0,16,2,'',1,1,NULL),(18,'15','2015-09-09','13:00','17:00',7,11,'Evento ECA',0,0,1,16,3,'',0,1,NULL),(19,'22','2015-09-02','09:00','15:00',7,11,'Evento de formaciÃ³n ECA, Facilitador: Pedro Gonzales.',0,0,0,16,2,'',0,1,NULL),(20,'31','2015-09-09','09:00','13:00',7,11,'Dupla Humberto PeÃ±ate',0,0,0,16,1,'',0,1,NULL),(21,'8','2015-09-02','09:00','15:00',7,11,'Evento de formaciÃ³n ECA, Facilitador: Pedro Gonzales.',0,0,0,16,2,'',0,1,NULL),(22,'13','2015-09-08','09:00','15:00',7,11,'William Romero - Daicy Alvarez, Evento ECA',0,0,0,16,2,'',0,1,NULL),(23,'7','2015-09-09','08:00','12:00',7,11,'Alcides Montiel-Comunidad Cruces Nuevas',0,0,0,16,3,'',0,1,NULL),(24,'18','2015-09-05','9:00 am','1:00 pm',7,5,'Evento ECA, Alcides Montiel',0,0,0,7,3,'',0,1,NULL),(25,'19','2015-09-10','09:00','15:00',7,11,'evento eca Dayci Alvarez - William Romero\r\n                Orlando Marin - Humberto PeÃ±ate\r\n                 Ricario Santana - Monica Avila\r\n                 Nelissa Bentacur - Ana Maria Calvo\r\n                 Jorge Montiel - Pedro Gonzales\r\n                 Misael Hernandez - James Caro ',0,0,0,16,2,'',0,1,NULL),(26,'31','2015-09-09','09:00','13:00',7,11,'Evento ECA',0,0,0,16,3,'',0,1,NULL),(27,'37','2015-09-09','09:00','13:00',7,11,'ASPHAS',0,0,0,16,2,'',0,1,NULL),(28,'29','2015-08-07','08:00','12:00',7,11,'ECA avÃ­cola, Melissa Restrepo y Francia Pinilla\r\n',0,0,0,16,3,'',0,0,NULL),(29,'35','2015-09-02','09:00','15:00',7,11,'Evento de formacion ECA: Facilitador: Misael Hernadez y Nelisaa Betancurt.',0,0,0,16,2,'',1,1,NULL),(30,'18','2015-09-09','09:00','15:00',7,11,'Evento ECA\r\nRicario Santana\r\nOrlando Marin\r\nAna Calvo\r\nDaicy Alvarez\r\nFrancia Pinilla',0,0,0,16,2,'',0,1,NULL),(31,'9','2015-09-08','08:00','12:00',7,11,'Francia Pinilla - Melissa Restrepo, Evento Eca.',0,0,0,16,3,'',0,1,NULL),(32,'20','2015-09-04','13:00','16:00',7,11,'ECA\r\nResponsable Misael Otero\r\nDupla Orlando',0,0,0,16,2,'',0,1,NULL),(33,'30','2015-09-05','9:00 am','1:00 pm',7,5,'Evento de FormaciÃ³n Unidad Avicola, Facilitador Melissa Restrepo',0,0,0,7,3,'',0,1,NULL),(34,'15','2015-09-02','09:00','03:00',7,11,'Evento de formacion: Facilitador: Orlando Marin',0,0,0,16,2,'',0,1,NULL),(35,'9','2015-09-08','13:00','17:00',7,11,'Los Caracoles; Melissa Restrepo - Francia Pinilla, Evento ECA.',0,0,0,16,3,'',0,1,NULL),(36,'29','2015-09-07','08:00','12:00',7,11,'ECA Avicola, Melissa Restrepo y Francia P.',0,0,0,16,3,'',0,1,NULL),(37,'37','2015-09-09','09:00','13:00',7,11,'Evento ECA\r\nNelissa Restrepo\r\nMonica Avila',0,0,0,16,2,'',0,1,NULL),(38,'25','2015-09-02','09:00','15:00',7,11,'Evento de formacion: Facilitador: James Caro',0,0,0,16,2,'',0,1,NULL),(39,'16','2015-09-03','08:00','12:00',7,11,'James Caro - Seguimiento transformaciÃ³n de cÃ¡rnicos - SENA',0,0,0,16,14,'',0,1,NULL),(40,'40','2015-09-04','08:00','14:00',7,11,'Responsable Daicy Alvarez\r\nDupla Monica Avila',0,0,0,16,2,'',0,1,NULL),(41,'24','2015-09-02','09:00','15:00',7,11,'Evento de formacion: Facilitador: Jorge Montiel',0,0,0,16,2,'',0,1,NULL),(42,'30','2015-09-25','08:00','12:00',7,11,'eca seguridad alimentaria William Romero ',0,0,0,16,15,'',0,1,NULL),(43,'16','2015-09-03','09:00','12:00',7,11,'Orlando y Humberto - Seguimiento SENA',0,0,0,16,14,'',0,1,NULL),(44,'25','2015-09-09','13:00','17:00',7,11,'CÃ¡rnicos SENA',0,0,0,16,2,'',0,1,NULL),(45,'5','2015-09-04','14:00','16:00',7,11,'RESPONSABLE JAMES CARO \r\nDUPLA HUMBERTO PEÃ‘ATE',0,0,0,16,2,'',0,1,NULL),(46,'29','2015-09-07','13:00','16:00',7,11,'Evento ECA, Francia P. y Roselys L.',0,0,0,16,1,'',0,1,NULL),(47,'7','2015-09-08','13:00','17:00',7,11,'Vereda El Rosario; Alcides Montiel - Ana Calvo, evento ECA.',0,0,0,16,3,'',0,1,NULL),(48,'3','2015-09-02','09:00','15:00',7,11,'Evento de formacion: Facilitador: Willian Barreto',0,0,0,16,2,'',0,1,NULL),(49,'36','2015-09-01','08:00','12:00',7,11,'evento eca, james caro y francia pinilla, bellavista',0,0,0,16,2,'',0,1,NULL),(50,'16','2015-09-03','01:00','05:00',7,11,' y Humberto - Eca en hortalizas',0,0,0,16,2,'',0,1,NULL),(51,'26','2015-09-09','13:00','17:00',7,11,'Pedro Gonzalez',0,0,0,16,2,'',0,1,NULL),(52,'36','2015-09-01','08:00','12:00',7,11,'Evento ECA James Caro - Francia Pinilla ',0,0,0,16,2,'',0,1,NULL),(53,'7','2015-09-08','08:00','12:00',7,11,'Vereda Calle Larga, Ana Calvo - Alcides Montiel, Evento ECA.',0,0,0,16,3,'',0,1,NULL),(54,'29','2015-09-07','08:00','12:00',7,11,'Evento ECA, Pedro G, y Ana M.',0,0,0,16,2,'',0,1,NULL),(55,'5','2015-09-01','13:00','16:00',7,11,'evento eca Pedro Gonzalez y Humberto PeÃ±ate',0,0,0,16,14,'',0,1,NULL),(56,'28','2015-09-02','09:00','15:00',7,11,'Evento de formacion ECA: Facilitador : Jorge Montiel',0,0,0,16,2,'',0,1,NULL),(57,'16','2015-09-03','02:00','05:00',7,11,'Misael y Monica - Preparacion feria socioempresarial',0,0,0,16,14,'',0,1,NULL),(58,'10','2015-09-08','13:00','17:00',7,11,'Roselys Llorente - Pedro Gonzalez, Evento ECA.',0,0,0,16,1,'',0,1,NULL),(59,'15','2015-09-04','09:00','12:00',7,11,'ECA\r\nMARAÃ‘ONAL GUAYABO \r\nRESPONSABLE GLORIA AVILA',0,0,0,16,2,'',0,1,NULL),(60,'21','2015-09-08','13:00','17:00',7,11,'Gloria Avila - Humberto PeÃ±ate, Evento ECA.',0,0,0,16,3,'',0,1,NULL),(61,'12','2015-09-07','08:00','17:00',1,11,'OrganizaciÃ³n de Indicadores, Proyectos hortÃ­colas, Ricario, Misael, Orlando, MÃ³nica, Daicy, Nelissa.',0,0,0,16,5,'',0,1,NULL),(62,'24','2015-09-08','08:00','12:00',7,11,'Jorge Montiel, Evento ECA.',0,0,0,16,2,'',0,1,NULL),(63,'8','2015-09-03','01:00','17:00',7,11,'Alcides Montiel - Asistencia Tecnica',0,0,0,16,3,'',0,1,NULL),(64,'6','2015-08-14','09:00','15:00',7,11,'Grupo productivo 24 de noviembre Misael Hernandez y Ana Maria Calvo',0,0,0,16,2,'',0,0,NULL),(65,'1','2015-09-04','13:00','17:00',8,11,'ECA PISICOLA\r\nRESPONSABLE FRANCIA PINILLA\r\nDUPLA ROSELYS LLORENTE',0,0,0,16,1,'',0,1,NULL),(66,'32','2015-09-07','08:00','13:00',7,11,'Evento ECA, James, Humberto',0,0,0,16,2,'',0,1,NULL),(67,'39','2015-09-08','08:00','12:00',7,11,'Nelissa Betancur - James Caro, Evento ECA.',0,0,0,16,2,'',0,1,NULL),(68,'8','2015-09-03','08:00','12:00',7,11,'Roselys y Pedro - Eca piscicola',0,0,0,16,1,'',0,1,NULL),(69,'39','2015-09-08','13:00','17:00',7,11,'Nelissa Betancur - James Caro, Evento ECA.',0,0,0,16,14,'',0,1,NULL),(70,'6','2015-08-14','09:00','15:00',7,11,'Grupo productivo tierra santa Ricario Santana y Nelissa Betancurd',0,0,0,16,2,'',0,0,NULL),(71,'3','2015-09-07','08:00','17:00',1,11,'Reporte de Indicadores, Ricario, Misael, Orlando, Monica, Daicy, Nelissa.',0,0,0,16,5,'',0,1,NULL),(72,'12','2015-09-08','08:00','17:00',1,11,'Reporte de indicadores; Orlando Marin, Misael Hernandez, Ricario Santana y Monica Avila.',0,0,0,16,6,'',0,1,NULL),(73,'23','2015-09-04','09:00','17:00',7,11,'RESPONSABLE ORLANDO MARÃN\r\nVISITA CON ANGELA',0,0,0,16,2,'',0,1,NULL),(74,'26','2015-09-23','13:00','17:00',7,11,'Pedro Gonzalez, Evento ECA.',0,0,0,16,2,'',0,1,NULL),(75,'8','2015-09-03','08:00','12:00',7,11,'Ricario y Nelissa - Asistencia tecnica',0,0,0,16,2,'',0,1,NULL),(76,'18','2015-09-18','08:00','17:00',5,11,'FERIA EMPRESARIAL',0,0,0,16,4,'',0,1,NULL),(77,'6','2015-09-14','09:00','15:00',7,11,'grupo productivo 24 de noviembre Misael Hernandez y Ana Calvo',0,0,0,16,2,'',0,1,NULL),(78,'18','2015-09-23','08:00','12:00',7,11,'Orlando Marin, Monica Avila y Ricario Santana,  Evento ECA.',0,0,0,16,2,'',0,1,NULL),(79,'6','2015-09-14','09:00','15:00',7,11,'grupo productivo tierra santa Ricario santana y Nelissa Betancurd',0,0,0,16,2,'',0,1,NULL),(80,'16','2015-09-03','02:00','05:00',7,11,'Pedro - Formacion de nuevo grupo',0,0,0,16,2,'',0,1,NULL),(81,'8','2015-09-03','08:00','12:00',7,11,'Alcides - Comunidad Las MArgaritas - Asistencia Tecnica',0,0,0,16,3,'',0,1,NULL),(82,'25','2015-09-14','08:00','12:00',7,11,'evento eca James caro y Pedro Gonzalez',0,0,0,16,2,'',0,1,NULL),(83,'30','2015-08-17','07:00','17:00',7,11,'FERIA EMPRESARIAL \r\nRESPONSABLES: MONICA. MISAEL, ORLANDO, NELISSA, RICARIO, HUMBERTO',0,0,0,16,0,'',0,0,NULL),(84,'10','2015-08-17','09:00','13:00',7,11,'RESPONSABLE WILLIAM ROMERO-JAMES CARO',0,0,0,16,2,'',1,0,NULL),(85,'19','2015-08-14','08:00','04:00',10,4,'AtenciÃ³n mÃ©dica y servicios complementarios dirigida a toda la comunidad',0,0,0,5,6,'',0,0,NULL),(86,'19','2015-08-14','08:00','16:00',10,4,'Servicios de salud y oferta institucional para toda la poblaciÃ³n de la comunidad. ',0,0,0,5,6,'',0,0,NULL),(87,'4','2015-08-21','08:00','16:00',10,4,'Servicios de salud y servicios complementarios dirigidos a toda la poblaciÃ³n de la comunidad.',0,0,0,5,6,'',0,0,NULL),(88,'25','2015-08-28','08:00','16:00',10,4,'Servicio de Salud y Servicios complementarios a Comunidad en General',0,0,0,5,6,'',0,0,NULL),(89,'33','2015-09-04','08:00','16:00',10,4,'Servicio de Salud y Servicios complementarios para la poblaciÃ³n de la comunidad',0,0,0,5,6,'',0,0,NULL),(90,'14','2015-09-11','08:00','16:00',10,4,'Servicios de Salud y servicios complementarios para la poblaciÃ³n de toda la comunidad',0,0,0,5,6,'',0,0,NULL),(91,'34','2015-09-01','10:00','16:00',2,14,'Asamblea de entrega PACE Confianza y SocializaciÃ³n del Plan de Desarrollo Comunitario',0,0,0,6,6,'',0,0,NULL),(92,'5','2015-09-01','09:00','13:00',7,11,'Actividad socioempresarial, taller DOFA, titular Pedro Gonzalez',0,0,0,16,2,'',0,1,NULL),(93,'27','2015-08-31','08:00','17:00',7,9,'El colectivo de ComunicaciÃ³n de la comunidad recibirÃ¡ su proceso de formaciÃ³n contenidos escritos, digitales y sonoros. El evento es en MONTELÃBANO, con 6 personas de la comunidad, 2 de ComitÃ© de GestiÃ³n y uno de Junta de AcciÃ³n Comunal, por lo que si alguien tiene actividades en paralelo no creo que sea limitante para avanzar. ',0,0,0,12,10,'',0,0,NULL),(94,'27','2015-09-01','08:00','15:00',0,9,'El colectivo de ComunicaciÃ³n de la comunidad recibirÃ¡ su proceso de formaciÃ³n contenidos escritos, digitales y sonoros. El evento es en MONTELÃBANO, con 6 personas de la comunidad, 2 de ComitÃ© de GestiÃ³n y uno de Junta de AcciÃ³n Comunal, por lo que si alguien tiene actividades en paralelo no creo que sea limitante para avanzar.',0,0,0,12,0,'',0,1,NULL),(95,'27','2015-09-01','08:00','15:00',7,9,'Segundo dÃ­a del proceso de formaciÃ³n. A las 3 de la tarde el colectivo regresa a su corregimiento. ',0,0,0,12,10,'',0,1,NULL),(96,'28','2015-08-31','08:00','17:00',7,9,'El colectivo de ComunicaciÃ³n de la comunidad recibirÃ¡ su proceso de formaciÃ³n contenidos escritos, digitales y sonoros. El evento es en MONTELÃBANO. ',0,0,0,12,10,'',0,0,NULL),(97,'28','2015-09-01','08:00','15:00',7,9,'Segundo dÃ­a del evento de formaciÃ³n. Al finalizar cada colectivo regresa a su corregimiento. ',0,0,0,12,10,'',0,1,NULL),(98,'26','2015-08-31','08:00','17:00',7,9,'El colectivo de ComunicaciÃ³n de la comunidad recibirÃ¡ su proceso de formaciÃ³n contenidos escritos, digitales y sonoros. El evento es en MONTELÃBANO',0,0,0,12,10,'',0,0,NULL),(99,'26','2015-09-01','08:00','15:00',7,9,'Segundo dÃ­a de la formaciÃ³n. Al terminar, el colectivo regresa a su corregimiento. ',0,0,0,12,10,'',0,1,NULL),(100,'26','2015-09-01','08:00','15:00',7,9,'Al finalizar el proceso de formaciÃ³n, los colectivos regresan a sus corregimientos. ',0,0,0,12,10,'',0,1,NULL),(101,'25','2015-08-31','08:00','17:00',7,9,'El colectivo de ComunicaciÃ³n de la comunidad recibirÃ¡ su proceso de formaciÃ³n contenidos escritos, digitales y sonoros. El evento es en MONTELÃBANO',0,0,0,12,10,'',0,0,NULL),(102,'19','2015-09-01','08:00','15:00',0,9,'Al terminar la capacitaciÃ³n, el colectivo regresa a su corregimiento',0,0,0,12,0,'',0,1,NULL),(103,'25','2015-09-01','08:00','15:00',7,9,'Al terminar la jornada el colectivo regresa a su corregimiento. ',0,0,0,12,10,'',0,1,NULL),(104,'32','2015-09-02','08:00','05:00',7,9,'El colectivo de ComunicaciÃ³n de la comunidad recibirÃ¡ su proceso de formaciÃ³n contenidos escritos, digitales y sonoros. El evento es en MONTELÃBANO',0,0,0,12,10,'',0,1,NULL),(105,'32','2015-09-03','08:00','03:00',0,9,'Al terminar la jornada los colectivos regresan a sus corregimientos',0,0,0,12,0,'',0,1,NULL),(106,'34','2015-09-02','08:00','05:00',7,9,'El colectivo de ComunicaciÃ³n de la comunidad recibirÃ¡ su proceso de formaciÃ³n contenidos escritos, digitales y sonoros. El evento es en MONTELÃBANO',0,0,0,12,10,'',0,1,NULL),(107,'34','2015-09-03','08:00','15:00',7,9,'Al terminar la capacitaciÃ³n el colectivo regresa al corregimimento',0,0,0,12,10,'',0,1,NULL),(108,'33','2015-09-02','08:00','17:00',7,9,'El colectivo de ComunicaciÃ³n de la comunidad recibirÃ¡ su proceso de formaciÃ³n contenidos escritos, digitales y sonoros. El evento es en MONTELÃBANO',0,0,0,12,10,'',0,1,NULL),(109,'33','2015-09-03','08:00','15:00',7,9,'Al terminar la jornada el colectivo regresa a su corregimiento',0,0,0,12,10,'',0,1,NULL),(110,'10','2015-09-02','08:00','17:00',7,9,'El colectivo de ComunicaciÃ³n de la comunidad recibirÃ¡ su proceso de formaciÃ³n contenidos escritos, digitales y sonoros. El evento es en MONTELÃBANO',0,0,0,12,10,'',0,1,NULL),(111,'10','2015-09-03','08:00','15:00',7,9,'Al terminar la jornada el colectivo regresa a su barrio. ',0,0,0,12,10,'',0,1,NULL),(112,'6','2015-09-04','08:00','17:00',7,9,'El colectivo de ComunicaciÃ³n de la comunidad recibirÃ¡ su proceso de formaciÃ³n contenidos escritos, digitales y sonoros. El evento es en MONTELÃBANO',0,0,0,12,10,'',0,1,NULL),(113,'6','2015-09-05','08:00','15:00',7,9,'Al terminar la jornada el colectivo regresa a su corregimiento. ',0,0,0,12,10,'',0,1,NULL),(114,'4','2015-09-04','08:00','17:00',7,9,'El colectivo de ComunicaciÃ³n de la comunidad recibirÃ¡ su proceso de formaciÃ³n contenidos escritos, digitales y sonoros. El evento es en MONTELÃBANO',0,0,0,12,10,'',0,1,NULL),(115,'4','2015-09-05','08:00','15:00',7,9,'Al terminar la jornada el colectivo regresa a su corregimiento. ',0,0,0,12,10,'',0,1,NULL),(116,'5','2015-09-04','08:00','17:00',7,9,'El colectivo de ComunicaciÃ³n de la comunidad recibirÃ¡ su proceso de formaciÃ³n contenidos escritos, digitales y sonoros. El evento es en MONTELÃBANO',0,0,0,12,10,'',0,1,NULL),(117,'5','2015-09-05','08:00','15:00',7,9,'Al terminar la capacitaciÃ³n el colectivo regresa a su corregimiento',0,0,0,12,10,'',0,1,NULL),(118,'17','2015-09-07','08:00','10:00',1,9,'ReuniÃ³n con los medios de comunicaciÃ³n del San Jorge en busca de alianzas y cubrimientos para el programa y visibilidad para la marca',0,0,0,12,31,'',0,1,NULL),(119,'4','2015-09-07','08:00','10:00',1,9,'ReuniÃ³n de articulaciÃ³n con periodistas del San Jorge. ',0,0,0,12,31,'',0,1,NULL),(120,'7','2015-09-17','08:00','12:00',12,9,'Lanzamiento MonterÃ­a Emprende + Feria Empresarial asociaciones GeneraciÃ³n de Ingresos y Desarrollo EconÃ³mico. ',0,0,0,12,31,'',0,1,NULL),(121,'7','2015-08-08','09:09','09:09',7,17,'1111',0,0,0,18,6,'',0,1,NULL),(122,'36','2015-08-05','02:02','02:02',7,5,'saddfs<fsgfasdfgsdafgasrftwrawerfawfaewrfeafaesdgfe',0,0,0,7,14,'6',1,0,NULL),(123,'18','2015-08-12','09:09','09:09',10,15,'vbnm,.kjhgfdfghjkl',0,0,0,19,7,'8',1,1,NULL),(124,'6','2015-08-19','06:06','06:06',8,17,'kijuhygtfrdeswqzxsxdcfvgbg',0,0,0,18,15,'7',1,1,NULL),(125,'12','2015-08-18','07:07','07:07',18,17,'scasdfsdgsdhgfhsdag aergsegs strhrst rt udtrysrtareta rta ertawta',0,0,0,20,17,'7',1,1,NULL),(126,'6','2015-07-07','09:09','08:08',16,5,'12121',0,0,0,7,7,'8',0,0,NULL),(127,'5','2015-07-16','00:12','11:11',16,5,'123456789987654321',0,0,0,7,7,'8',0,0,NULL),(128,'2','2015-07-23','09:09','06:06',7,5,'14654654S6D5F4SD65F4S65F4S65DF46S5DF456SDFSDFSDFSDFSDFSDFSDF',0,0,0,7,16,'2',0,0,NULL),(150,'16','2015-09-15','21:09','21:09',10,1,'111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111',1,0,0,2,8,'7',0,1,'1'),(151,'42','2015-08-13','18:06','18:06',16,1,'query_eventosquery_eventosquery_eventosquery_eventosquery_eventosquery_eventosquery_eventosquery_eventosquery_eventosquery_eventosquery_eventosquery_eventosquery_eventosquery_eventosquery_eventosquery_eventosquery_eventosquery_eventosquery_eventosque',1,1,1,2,7,'8',0,1,'1'),(152,'15','2015-08-20','07:07','07:07',5,1,'sdfffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff',0,0,0,2,18,'7',1,1,'2'),(153,'14','2015-10-09','20:08','16:44',7,15,'cccccccccccccccvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv',0,0,0,19,16,'1',0,0,'2'),(154,'13','2015-08-26','21:09','20:08',6,15,'EDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE',0,0,0,19,20,'6',0,1,'1'),(155,'15','2015-08-23','08:08','08:08',6,1,'SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS',0,0,0,2,18,'4',0,1,'1'),(156,'15','2015-08-22','00:00','20:05',5,1,'sdfsfsdfsdf  sdf sdfsdfdsdf sd fsf sdf sdsdf sds ssf dsdfsdfsdf sdf sdfsdf sdsdsdfsdfssdfsdfsd  sdfsdfsdf',0,0,0,2,24,'6',0,1,'1'),(157,'15','2015-08-06','20:08','20:08',17,1,'22222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222',0,0,0,2,24,'8',1,1,'1'),(158,'59','2015-08-04','17:55','17:55',7,15,'sdsdsdfsfzasdfdfgadsfgas a as fas fas f saf sf a fasd f f asf asf as f asfsf sf s f sf sd fsd fsd f s f asdfasdfasdfasdfasdfasfsdfasf',0,0,0,19,16,'1',0,1,'2'),(159,'34','2015-09-16','21:09','21:09',14,1,'sdsdsdsdsasdasdasdasdasdasdadadasdasdasdasdasdfsdfasdfasdfasdfasdfas',0,0,0,2,7,'8',0,1,'1'),(160,'34','2015-09-17','21:09','21:09',2,1,'555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555',0,0,0,2,27,'8',0,1,'2'),(161,'23','2015-09-22','15:03','17:55',2,1,'asssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss',0,0,0,2,9,'1',0,1,'2'),(162,'42,19,33,','2015-09-16','21:09','18:06',2,1,'sdsddddddddddddddddddddddddddddddddddddddddddddddddddddddddssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss',0,0,0,2,16,'8',1,1,'2'),(163,'cen,21,30,20,','2015-09-29','21:09','08:08',14,1,'gfghdfghfsghfghfghdfghdfghhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh',0,0,0,2,27,'1',0,1,'2'),(164,'14,15,cen,','2015-09-30','10:15','03:16',16,1,'jhgtfreeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee',0,0,0,2,7,'6',1,1,'2'),(165,'12,13,16,cen,18,','2015-10-28','21:09','19:07',11,1,'gtfdfdfffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff',0,0,0,2,9,'7',0,0,'2'),(166,'cen,12,14,15,18,','2015-10-14','09:09','20:08',14,1,'ssssssssssssssssssssssssssssss sssssssssssssssssssssssssssssssssssssssssssssssssssssdddddddddddddddddddddd',0,0,0,2,7,'7',0,0,'1'),(167,'41,19,33,cen,','2015-09-09','09:09','09:09',10,1,'swdqdfwewrgsgsdfgawefaWERFawefavferwAWEFAwefwaefWAEFAwefERFAWERFW',0,0,0,2,12,'8',0,1,'1'),(168,'58,56,57,cas,cas,','2015-10-28','20:08','21:09',16,1,'fdghjcdfdafvzdfvzdvdvzdbdgbddsgsdgdgdsdfgsdfgdsgdsgdsgsdgdgadfgzsdfgzsdfgsdghaedrfgzdfbvdzfgsadegsdgbdbdzsgaeghafdgasdfgaergaerg',1,1,1,2,2,'1',0,0,'1'),(169,'2,3,1,11,8,','2015-09-03','21:09','21:09',7,1,'gggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg',0,0,0,2,9,'8',1,1,'2'),(170,'50,49,46,45,44,48,53,52,cen,51,cas,7,3,4,10,6,5,8,11,2,1,9,cen,','2015-09-12','21:09','20:08',14,1,'1321313131132132131321321313132132132132146546542165416841684316513654654651651321651616581681651651961691651656164695',0,0,0,2,7,'6',0,1,'1'),(171,'4,2,11,8,','2015-09-19','02:01','08:08',16,1,'',0,0,0,2,10,'6',0,1,'2'),(172,'cen,41,19,34,','2015-09-24','21:09','21:09',2,1,'dsacfsdghdtjfdhgrweratsrydmnxfdsahszfgbzadgfhhrshsfghsfhstregsghsetrgsergshgahjaetrhsatghrs',0,0,0,2,27,'1',0,1,'2'),(173,'cen,30,31,','2015-10-02','21:09','21:09',2,1,'212121212121212222222222222222222222222221111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111',0,0,0,2,24,'6',0,0,'2'),(174,'53','2015-09-26','21:09','21:09',1,1,'',0,0,0,2,7,'2',1,1,'2'),(175,'7','2015-09-30','18:06','18:06',13,1,'dsdfs df sdf sf sf s dsfg dsgsd g g sdfgd g df g d gd gd g dg dfgdg dgd gd gd gd gd gd sgeageqa gadsgag eag ae gae gagad gdafg d fg dsfg ds fg sdfg sdf gds fg dg dg d g dfg dfg d g dfg',0,0,0,2,9,'5',0,1,'1'),(176,'31,32,30,','2015-10-16','20:08','20:08',13,1,'nvokdngjndjnbadgnbagjaBNSKGBFASGBSAGAHDGFHABJDFGBAFBGAHGFAJDGBADJGBDGBJSFGNHDKJGHDFGHDFJHAJHhJHKJDFHGKJhkjhgkjdhgkjdfhgdhfgdfgdg',1,0,0,2,8,'2',0,0,'1'),(177,'16,10,57,62,undefined','2015-11-27','09:09','21:09',7,1,'DEFDFSFDGSDGSSTGRHSRGTHSRHBHJIVGBJHVHV HVH JYHGHGG GGJKhjhvjhJHJHG JHGJH  JHGJHGJHGHJHGJHG JHGJHG JHGJHGJGJH J',0,0,0,2,9,'6',0,0,'1'),(178,'53,48,52,','2015-11-13','21:09','09:09',8,16,'SDFGDFGDGDFGF DFG DGDGD GDFG DD GD DGDG DG  D G GFD GDFGDG GDG DGDGDG REGD GD FGDFGDRDERG EG ERGERGEGERGEGEGEGEGEG EGEGEGERGERGERG',0,0,0,21,12,'1',0,0,'2'),(179,'14,16,15,18,','2015-11-14','21:09','20:08',14,10,'DFVDFD DF D   D D DF DDFD DFVDFDFDFBDFDF D D DGD D D D D D D D D DF DGFGF DDD D DF D D D GGDD DDDF',1,1,1,13,27,'1',0,0,'1'),(180,'41,19,35,33,34,','2015-11-11','05:59','10:10',10,2,'dfertydjhdrtyber y6yr6y 6y6 y556y e5656e 7e57 e57e57e5ww46w45 6w45 635 645w6e46e456w46w46w46w456 w46w456w4 w 3w6 4w5 4 6q6 4w56 w46w w6 w4 rudhdd hdfhfdhfgh',0,0,0,3,16,'3',0,0,'2'),(181,'16,12,','2015-11-21','20:08','08:08',14,9,'sdfghxfcjghgdzrghfdjfh srt hrhrttyr yryr ry rsy rtsy rt  try r  r ryrr rysrt s str srt yrtsyrty rsysr ysr ysr yrs s ysr ystr ysr yryrd ydr trty srty r  r rsy sry  yrt rrrhxgfgh hdr h ydrydryry  thfghfghjgf',0,0,0,12,7,'7',0,0,'1'),(182,'14,15,18,','2015-11-19','20:08','06:06',11,16,' jhgfytvgjvcyktdro8iugvgon ggiyg uyfyfuy f  utfg byf dtd uyg fkfut fi t dytryro86 r76r7  5 r r76r76r 76r 75r7ft fytgdtr dytfk',1,1,1,21,15,'4',0,0,'2'),(183,'19,33,','2015-11-19','08:08','07:07',18,17,'xvbn vbhgdbnvhgzdgdxbgfgdhftdgxdgdrgxdfgxdgdfhxdfhxdyxrybey se y  yys se e tjjjtyjtyjyuytututyutudtyudtyudtrudrtyrdtydrty rty dryrty ry rtytry ',0,0,0,20,3,'5',0,0,'1'),(184,'30,20,','2015-11-25','07:07','07:07',2,11,'XFGHERYRYTHYGTHFGDTSRTETJSERTJSERJTJRJTSERTS  T R T  YRT Y RY RTYRD YDRT YTRY RTYT RTD YTRY TRYRT  YRTD YRTY RTY RTY RD RY RDYDRY RT  YRYDR Y RTD DHT Y6  3 Y54',0,0,0,16,27,'8',0,0,'1'),(185,'14,15,18,','2015-11-20','08:08','09:09',7,2,'jdjdjdjdjdjdjdfjfsdifjsifnvndoivnsvojson<sovisjnoin oivnaroeijarweoi',0,0,0,26,16,'8',0,0,'1'),(186,'44,48,52,','2015-11-15','09:09','09:09',10,1,'skskkkkskk  k skd  s f sdf  sdf  s  s fg sfsd fs df sd f sf s d f sdfs sd fs fsf s  fs f sd fsdf sf s fs f s f sfs df sd fs df sd fsffdf ',1,0,0,2,3,'3',0,0,'1'),(187,'32,30,20,','2015-10-15','09:09','09:09',7,1,'jjdjjdjjdjjjjd d d    sd s d sd s dsd s s d sd s sd sd  sd  sd  sd  sd  sd  sd  sd sd sd  sd s d sd s d s d sd  s s  sd sd  sd sd s d sd s d sd sd s d',1,1,1,2,12,'5',0,0,'1'),(188,'18,undefined','2015-10-01','09:09','09:09',13,1,'sdsdsdsdsdsdasddsdfsdvffafqefq efdf w f wf f d fw ef wef fwef wef  wef w ef wef wef  w fw f we fw ef wef we f we fw ef we f wef we fw ef wef w ef we fw ewe',0,0,0,2,8,'6',0,0,'1'),(189,'8,9,','2015-09-29','09:09','09:00',2,1,'kjhkjkjkjkjkjllihoioihoinoioihihoihinoihoihoinoihohoihoihoihoihoih h oiohohoihoihoihoihoiiohoihoi ih oio ho ihoioig iugkjggkjgkjgkgkjgkjgkjgkjgkjgkjgk',0,0,0,2,8,'1',0,1,'2'),(190,'21,20,30,cen,cas,','2015-09-10','09:09','09:09',10,1,'jojojojojohihguyfuyfghfyfjhfchgfk uy f uyfuoyf tf uyfu tfky t dytd ytdytdkyuf uyfuyf uyfutdytdytdy ktfdydktfkytduy dfluyfuyfuyjtfut dfoytfotf t foty futfu o',1,1,1,2,9,'8',0,0,'1'),(191,'16,12,','2015-11-26','09:09','09:09',2,1,'jkkjkjkj j j j j jnj j jiojjo j jojojojojmoiioniuni on n oinoi noi oin oin ',1,1,1,2,27,'4',0,0,'1'),(192,'62,60,56,','2015-11-07','09:09','08:08',7,10,'jgpaojfoajsfoajsdoivjdogiajifavnaokhreaoginrigoreajsdjfisdjfijpsdjgpaojfoajsfoajsdoivjdogiajifavnaokhreaoginrigorea',1,1,1,13,9,'6',0,0,'1'),(193,'16,12,cen,','2015-09-20','09:09','09:09',10,10,'prueba 4prueba 4prueba 4prueba 4prueba 4prueba 4prueba 4prueba 4prueba 4prueba 4prueba 4prueba 4prueba 4prueba 4prueba 4prueba 4prueba 4',0,0,0,13,9,'1',0,1,'1'),(194,'11,8,','2015-11-06','09:09','09:09',2,2,' prueba 15 prueba 15 prueba 15 prueba 15 prueba 15 prueba 15 prueba 15 prueba 15 prueba 15 prueba 15 prueba 15 prueba 15 prueba 15 prueba 15 prueba 15 prueba 15',0,0,0,26,9,'8',0,0,'1'),(195,'48,44,52,','2015-11-07','09:09','09:09',7,2,'prueba 34 prueba 34 prueba 34 prueba 34prueba 34prueba 34prueba 34prueba 34prueba 34prueba 34prueba 34prueba 34prueba 34prueba 34prueba 34prueba 34prueba 34prueba 34prueba 34prueba 34prueba 34prueba 34prueba 34prueba 34prueba 34',1,1,1,26,12,'6',0,0,'2'),(196,'56,57,9,2,1,11,','2015-10-08','08:08','09:09',6,1,'llllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll',0,0,0,2,25,'6',0,0,'2'),(197,'3,1,11,','2015-10-02','20:08','21:09',16,2,'Casco UrbanoCasco UrbanoCasco UrbanoCasco UrbanoCasco UrbanoCasco UrbanoCasco UrbanoCasco UrbanoCasco UrbanoCasco UrbanoCasco UrbanoCasco UrbanoCasco Urbano',0,0,0,26,27,'1',0,0,'1'),(198,'11,8,','2015-09-30','08:08','09:09',16,2,'Casco UrbanoCasco UrbanoCasco UrbanoCasco UrbanoCasco UrbanoCasco UrbanoCasco UrbanoCasco UrbanoCasco UrbanoCasco UrbanoCasco UrbanoCasco UrbanoCasco UrbanoCasco UrbanoCasco UrbanoCasco UrbanoCasco UrbanoCasco UrbanoCasco UrbanoCasco Urbano',0,0,0,26,27,'6',1,1,'1'),(199,'44,51,cen,54,57,19,33,','2015-11-14','19:07','20:08',14,2,'Casco UrbanoCasco UrbanoCasco UrbanoCasco UrbanoCasco UrbanoCasco UrbanoCasco UrbanoCasco UrbanoCasco UrbanoCasco UrbanoCasco Urbano',1,1,1,26,9,'1',0,0,'2');

#
# Structure for table "estado"
#

DROP TABLE IF EXISTS `estado`;
CREATE TABLE `estado` (
  `id_estado` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_est` varchar(100) NOT NULL,
  `activo` int(11) NOT NULL,
  PRIMARY KEY (`id_estado`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "estado"
#


#
# Structure for table "municipio"
#

DROP TABLE IF EXISTS `municipio`;
CREATE TABLE `municipio` (
  `id_municipio` int(11) NOT NULL AUTO_INCREMENT,
  `municipio` varchar(60) NOT NULL,
  `activo` int(11) NOT NULL,
  PRIMARY KEY (`id_municipio`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

#
# Data for table "municipio"
#

INSERT INTO `municipio` VALUES (1,'LA APARTADA',0),(2,'MONTELIBANO',0),(3,'PLANETA RICA',0),(4,'PUERTO LIBERTADOR',0),(5,'SAN JOSE DE URE',0),(6,'BUENAVISTA',0),(7,'MONTERIA',0),(8,'CARTAGENA',0),(9,'VALLEDUPAR',0);

#
# Structure for table "notifica"
#

DROP TABLE IF EXISTS `notifica`;
CREATE TABLE `notifica` (
  `Id` int(2) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `id_cronograma` varchar(255) DEFAULT NULL,
  `hi` varchar(255) DEFAULT NULL,
  `hf` varchar(255) DEFAULT NULL,
  `activo` varchar(255) DEFAULT '0',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

#
# Data for table "notifica"
#

INSERT INTO `notifica` VALUES (01,'130','08:08','09:09','0'),(02,'150','06:06','06:08','0'),(03,'164','10:15','03:16','0'),(04,'164','10:15','03:16','0'),(05,'180','17:40','20:08','0'),(06,'180','17:40','20:08','0'),(07,'180','09:59','10:10','0'),(08,'180','09:59','10:10','0'),(09,'180','05:59','10:10','0'),(10,'180','05:59','10:10','0'),(11,'162','21:09','18:06','0'),(12,'192','09:09','08:08','0'),(13,'177','09:09','21:09','0'),(14,'177','09:09','21:09','0'),(15,'177','09:09','21:09','0'),(16,'177','09:09','21:09','0'),(17,'177','09:09','21:09','0'),(18,'177','09:09','21:09','0'),(19,'177','09:09','21:09','0'),(20,'177','09:09','21:09','0'),(21,'177','09:09','21:09','0'),(22,'177','09:09','21:09','0');

#
# Structure for table "operador"
#

DROP TABLE IF EXISTS `operador`;
CREATE TABLE `operador` (
  `id_operador` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_op` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `sigla` varchar(20) NOT NULL,
  `telefono` bigint(11) NOT NULL,
  `direccion` varchar(60) NOT NULL,
  `email` varchar(60) NOT NULL,
  `activo` int(11) NOT NULL,
  PRIMARY KEY (`id_operador`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

#
# Data for table "operador"
#

INSERT INTO `operador` VALUES (1,'Fundacíon Cerro Matoso','FCM',300,'Montelibano','cerromatoso@correo.com',0),(2,'Global Communities','GC',320,'Monteria','',0),(3,'Programa ANDA','ANDA',0,'MONTERIA','0',0),(4,'SENA-MonterÃ­a','SENA',0,'MONTERIA','SENA-MonterÃ­a@correo.com',0),(5,'Fundación Universitaria Agraria de Colombia','UNIAGRARIA',0,'MONTERIA','0',0),(6,'Secretariado Diocesano de Pastoral Social - Diakonía de la Paz.','DIAKONIA DE LA PAZ',0,'MONTERIA','0',0),(7,'Fundación Amanecer','FUNDACION AMANECER',0,'CARTAGENA','direccion@fundacionamanecer.org',0),(8,'Diócesis de Montelíbano (Pastoral Social).','PASTORAL SOCIAL-MONT',0,'MONTELIBANO','0',0);

#
# Structure for table "perfil"
#

DROP TABLE IF EXISTS `perfil`;
CREATE TABLE `perfil` (
  `id_perfil` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(40) NOT NULL,
  `cod` varchar(20) NOT NULL,
  `activo` int(11) NOT NULL,
  PRIMARY KEY (`id_perfil`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "perfil"
#


#
# Structure for table "persona"
#

DROP TABLE IF EXISTS `persona`;
CREATE TABLE `persona` (
  `id_persona` int(11) NOT NULL AUTO_INCREMENT,
  `cedula` varchar(20) COLLATE utf8_bin NOT NULL,
  `nombre` varchar(60) COLLATE utf8_bin NOT NULL,
  `apellido` varchar(60) COLLATE utf8_bin NOT NULL,
  `sexo` varchar(10) COLLATE utf8_bin NOT NULL,
  `telefono` varchar(15) COLLATE utf8_bin NOT NULL,
  `etnia` varchar(10) COLLATE utf8_bin NOT NULL,
  `condicion` varchar(10) COLLATE utf8_bin NOT NULL,
  `ruv` varchar(10) COLLATE utf8_bin NOT NULL,
  `discapacitado` varchar(10) COLLATE utf8_bin NOT NULL,
  `participante` varchar(10) COLLATE utf8_bin NOT NULL,
  `rango_edad` varchar(10) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id_persona`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

#
# Data for table "persona"
#

INSERT INTO `persona` VALUES (1,'cedula','nombre','apellido','sexo','rol','direccion','0','email','telefono','usuario','password'),(2,'cedula','nombre','apellido','sexo','rol','direccion','0','email','telefono','usuario','password'),(3,'cedula','nombre','apellido','sexo','rol','direccion','0','email','telefono','usuario','password'),(4,'cedula','nombre','apellido','sexo','rol','direccion','0','email','telefono','usuario','password');

#
# Structure for table "poblacion"
#

DROP TABLE IF EXISTS `poblacion`;
CREATE TABLE `poblacion` (
  `idpoblacion` int(25) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(60) NOT NULL,
  `nombre_c` varchar(120) NOT NULL,
  `estado` varchar(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`idpoblacion`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;

#
# Data for table "poblacion"
#

INSERT INTO `poblacion` VALUES (1,'ECA-Piscicolas','ESCUELA DE CAMPO DE AGRICULTORES','0'),(2,'ECA-Hortalizas','ESCUELA DE CAMPO DE AGRICULTORES - HORTALIZAS','0'),(3,'ECA-Avicola','ESCUELA DE CAMPO DE AGRICULTORES - AVICOLA','0'),(4,'Sembrando Paz','ESCUELA DE CAMPO DE AGRICULTORES - SEMBRANDO PAZ','0'),(5,'Operador y/o Contratista','OPERADOR Y/O CONTRATISTAS','0'),(6,'Poblacion General','ASAMBLEA COMUNITARIA','0'),(7,'Comite de Gestion','COMITÉ DE GESTIÓN COMUNITARIO ','0'),(8,'Comite Infraestructura.','COMITÉ DE GESTIÓN COMUNITARIO - INFRAESTRUCTURA','0'),(9,'Comite de Obras','COMITÉ DE GESTIÓN COMUNITARIO - OBRAS','0'),(10,'Colectivo de Comunicaciones','COMITÉ DE GESTIÓN COMUNITARIO - COMUNICACIÓN ','0'),(11,'Junta de Accion Comunal','JUNTA DE ACCIÓN COMUNAL','0'),(12,'Comite Piscicola','COMITÉ PSICOSOCIAL ','0'),(13,'Gobiernos Locales','GOBIERNOS LOCALES','0'),(14,'Hogares - Genero','FORMACION SENA','0'),(15,'ECA - Seguridad Alimentaria','ESCUELA DE CAMPO DE AGRICULTURES - SEGURIDAD ALIMENTAARIA','0'),(16,'Comite de Salud','','0'),(17,'Docentes - Estudiantes - Padre de Familia','','0'),(18,'Grupo Tics -SENA','','0'),(19,'Grupo Transformacion de Alimento -SENA','','0'),(20,'Grupo Piscicola -SENA','','0'),(21,'Grupo Cultivos Transitorios - SENA','','0'),(22,'Grupo Modisteria -  SENA','','0'),(23,'Grupo Avicola -SENA','','0'),(24,'Grupo Ovino - SENA','','0'),(25,'Jovenes','','0'),(26,'Hogares - Vivienda Saludable','','0'),(27,'Comite de Aguas','','0'),(28,'Nodos Municipales','','0'),(29,'Red de Comites','','0'),(31,'Varias','','0');

#
# Structure for table "tipo_lugar"
#

DROP TABLE IF EXISTS `tipo_lugar`;
CREATE TABLE `tipo_lugar` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `tipo_lugar` varchar(255) DEFAULT NULL,
  `activo` int(2) DEFAULT '0',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

#
# Data for table "tipo_lugar"
#

INSERT INTO `tipo_lugar` VALUES (1,'Casco Urbano',0),(2,'Centro Poblado',0);

#
# Structure for table "usuario"
#

DROP TABLE IF EXISTS `usuario`;
CREATE TABLE `usuario` (
  `id_usuario` int(11) NOT NULL AUTO_INCREMENT,
  `cedula` varchar(20) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `nombre_u` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `usuario` varchar(45) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `password` varchar(40) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `id_operador` int(12) NOT NULL,
  `Idcargo` int(20) NOT NULL,
  `estado` int(11) NOT NULL,
  `idcoordinacion` int(30) NOT NULL,
  PRIMARY KEY (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;

#
# Data for table "usuario"
#

INSERT INTO `usuario` VALUES (1,'98656677','JOVANNI ANDRES GIRALDO FRANCO','98656677','98656677',2,1,0,0),(2,'1065570806','JORGE LUIS ROMERO','1065570806','0806 ',2,1,0,0),(3,'52495210','DIANA PATRICIA GUZMAN GOMEZ','52495210','5210',2,2,0,0),(4,'4403652','JOHN JAIRO RIOS TORO','4403652','3652',2,4,0,0),(5,'52813516','SANDRA MILENA ARDILA TELLEZ','52813516','3516',2,4,0,0),(6,'23029388','ILDA MILETH CASTELLANOS HERNANDEZ','23029388','9388',2,14,0,0),(7,'25913254','ANGELA MARIA PINEDA BARCENAS','25913254','3254',2,5,0,0),(8,'73141648','AMARANTO ZABALETA AREVALO','73141648','1648',2,6,0,0),(9,'34571162','LUZ MARINA BEDOYA IDROBO','34571162','1162',2,1,0,0),(10,'79120990','DANIEL FRANCISCO BERMEO PENAGOS','79120990','0990',2,7,0,0),(11,'91072745','JOSE ZHAITTER GOMEZ GARCIA','91072745','2745',2,8,0,0),(12,'80196486','CAMILO ANDRES VELASQUEZ RUIZ','80196486','6486',2,9,0,0),(13,'52770887','LINA ANDREA GUZMAN CASTAÃ‘EDA','52770887','0887',2,10,0,0),(14,'12119550','LUIS CARLOS PROHAÃ‘OS ORTIZ','12119550','9550',2,1,0,0),(15,'34567234','CAROLINA DEL CAIRO SILVA','34567234','7234',2,11,0,0),(16,'999999','USUARIO DE PRUEBA','002','002 ',2,11,0,7),(18,'0009','MyE Usuario','0001','0001 ',1,1,0,2),(19,'9999','OTRO MAS','9999','99',4,15,0,2),(20,'9','CONTRATISTA MYE','9','9',3,17,0,2),(21,'123456','JJ3','2525','0088        ',5,16,1,2),(24,'qqqq','qqqq','qqqq','qqqq',7,7,0,2),(25,'ooo','ooo','ooo','oo',7,7,1,2),(26,'1066','Thamara Romero Navarro','thami','thami',2,2,0,2);
