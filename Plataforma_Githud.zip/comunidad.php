 <?php 
 require_once("config.php"); 
 //header('Content-Type: text/html; charset=utf-8');
 $query_eventos=$db->query("SELECT * FROM comunidad where id_municipio='".$_POST["elegido"]."' order by comunidad asc");
	while ($eventos=$query_eventos->fetch_array())
 		{ 	echo "<option  value='".$eventos[0]."'>".utf8_encode($eventos[1])."</option>";
		
		 } 
		
												
 
 ?>