		<?php @session_start();   if($_SESSION['opera']=='1' or $_SESSION['opera']=='2'){ ?>
                     	<div  id="content" align="center">
                          	<p>Aqui presenta las coordinaciones que no hayan registrado sus actividades del siguiente mes.</p>
                           			  <?php
@session_start();  require("config.php");
?>
<h5 class="color_azul">Coordinador con Actividad Registradas.</h5>
  <table cellspacing="0" cellpadding="0">
	<tr>
		<th >Coordinacion</th>
        <th >Nombre</th>
   	</tr> 
<?php
$ano_mes = substr($_SESSION['fecha'],0,7);
				$ano_mes=$ano_mes."-30";
				//echo $ano_mes; 
				$qls="SELECT	  usuario.nombre_u,
						  usuario.id_usuario,
						  usuario.Idcargo
					from 
								  cronograma
								  RIGHT OUTER JOIN usuario ON cronograma.id_usuario =
									usuario.id_usuario
					where   
								  (cronograma.fecha > '".$ano_mes."' AND
								  cronograma.activo ='0' AND cronograma.aval='0')and  estado='0' and idcoordinacion='0'";
		  	    
					  $resultado=mysql_query($qls);
	while($rw=mysql_fetch_array($resultado))
		{		echo "<tr>"; 
					$sql3="SELECT * from cargo where    idcargo='".$rw['2']."'";
						$resulta=mysql_query($sql3);		
		 		while ($row2=mysql_fetch_array($resulta))
					{ echo "<td style='text-align:right;  padding-right: 12px;'>".utf8_encode($row2['1'])."</td>";}	
					 		echo "<td style='text-align:left;padding-left: 12px;' >".$rw['0']."</td>";	echo "</tr>";
 	
		}?>
  	
</table>
<h5 class="color_azul">Coordinador sin Actividad Registradas.</h5>
 <table cellpadding="0" cellspacing="0">
	<tr>
		<th >Coordinacion</th>
        <th >Nombre</th>
	</tr> 
<?php

	$ano_mes = substr($_SESSION['fecha'],0,7);
				$ano_mes=$ano_mes."-30";
				//echo $ano_mes; 
				$qls="select usuario.nombre_u, usuario.id_usuario, usuario.Idcargo  from usuario LEFT JOIN 
							(select usuario.nombre_u,
								  usuario.id_usuario,
								  usuario.Idcargo
							from cronograma
									  left join usuario ON cronograma.id_usuario = usuario.id_usuario
							where   
							     (cronograma.fecha > '".$ano_mes."' AND 
							      cronograma.activo ='0' AND cronograma.aval='0')) AS USU ON 
					USU.id_usuario=usuario.id_usuario
					where    USU.id_usuario is NULL AND estado='0' AND idcoordinacion='0' order by  usuario.Idcargo asc";
					
		$resultado=mysql_query($qls);
	while ($rw=mysql_fetch_array($resultado))
		{		echo "<tr >"; 
						$sql3="SELECT * from cargo where idcargo='".$rw['2']."'";
						$resulta=mysql_query($sql3);
		 		while ($row2=mysql_fetch_array($resulta))
					{ echo "<td style='text-align:right; padding-right: 12px;'>".utf8_encode($row2['1'])."</td>";}
					 		echo "<td style='text-align:left; padding-left: 12px;' >".$rw['0']."</td>";
							echo "</tr>";
								}?>
  	
</table>
                        </div>
                  	<?php  } ?>