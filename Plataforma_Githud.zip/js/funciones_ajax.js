// JavaScript Document
       $().ready(function()
		{	var	 concatena;
			$('.pasar').click(function() { 
			$('#comunidad option:selected').remove().appendTo('#destino');
			$('#comunidad11 option:selected').remove().appendTo('#destino');
			   combo();
		});
		$('.quitar').click(function(){ 
			$('#destino option:selected').remove().appendTo('#comunidad');
			$('#destino option:selected').remove().appendTo('#comunidad11');
			   combo();
		});					
		function combo(){
						  $("#destino option").each(function()
							{ concatena=$(this).val()+","+concatena;});
						  $('#com').val(concatena);
							concatena='';	
						}
		$('.quitartodos').click(function() {  $('#com').val('');
											$('#destino option').each(function() {
							
																					$(this).remove().appendTo('#comunidad');  
																				});
										 });
		$('.submit').click(function() { $('#destino option').prop('selected', 'selected'); });
	});
	/***************************////////////////////////////////////////////////////////////////**********************************************************************************
$(document).ready(function()
		{	jQuery.validator.addMethod("valida",function (value, element){
													if ($(element).find(":selected").val() == 0) {return false;} else return true; },"<p class='ko'>Campo Requerido.</>");
								$('#lugar').change(function() { $("#lu").val($("#lugar option:selected").html());})
								$('#casco').change(function() { $("#lu1").val($("#casco option:selected").html());})
								$('#destino option:selected').removeAttr("selected");
								$('#lugar2').change(function() { $("#lup").val($("#lugar2 option:selected").html());
																 $("#lu6").val($("#lugar2").val()); 
																})
								$('#casco2').change(function() {$("#lup1").val($("#casco2 option:selected").html());
																$("#lu7").val($("#casco2").val()); 
																})
							}); 
$(document).ready(function()
		{	$("#municipio").change(function () { 
												  $("#municipio option:selected").each(function (){ elegido=$(this).val(); llena(elegido);  });
										       })
			$("#municipio2").change(function () {	
												  $("#municipio2 option:selected").each(function (){elegido=$(this).val(); comu=$('#comunidad2').val();
												  $.post("comunidad.php", { elegido: elegido ,comu:comu}, function(data){ $("#comunidad11").html(data);});
												 												   }); 
												 })
function llena(elegido){
							comu=$('#comunidad2').val();
							$.post("comunidad.php", { elegido: elegido ,comu:comu}, function(data){ $("#comunidad").html(data);});		
						}
			$("form.datos").validate();
		});