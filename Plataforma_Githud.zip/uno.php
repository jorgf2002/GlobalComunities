<?php header('Content-Type: text/html; charset=utf-8'); 
require_once("config.php"); @session_start(); 
$s=0;
          
							$query_eventos=$db->query(" SELECT COUNT(*) FROM 
                                ((SELECT cronograma.id_usuario,
                                          cronograma.id_estado,
                                          cronograma.fecha,
                                          cronograma.id_cronograma,
                                          cronograma.id_comunidad,
                                          cronograma.hora_i,
                                          cronograma.hora_f,
                                          cronograma.id_actividad,
                                          cronograma.id_operador,
                                          cronograma.descripcion,
                                          cronograma.activo,
                                          cronograma.id_anterior,
                                          cronograma.idpoblacion,
                                          cronograma.lugar,
                                          cronograma.realizada,
                                          cronograma.aval,
                                          cronograma.casco,
                                          cronograma.municipio,
                                          usuario.id_usuario AS id_usuario1,
                                          usuario.cedula,
                                          usuario.nombre_u,
                                          usuario.usuario,
                                          usuario.password,
                                          usuario.id_operador AS id_operador1,
                                          usuario.Idcargo,
                                          usuario.estado,
                                          usuario.idcoordinacion 
                                FROM cronograma 
                               INNER JOIN usuario on usuario.id_usuario=cronograma.id_usuario 
                               WHERE cronograma.id_usuario='".$_SESSION['usua']."'   AND id_estado =0 
                                AND (year(fecha)=YEAR(NOW()) and month(fecha)=(MONTH (NOW())-1) ) or (year(fecha)>YEAR(NOW()) and month(fecha)>(MONTH (NOW())) )
                              )
                               UNION
                                (SELECT cronograma.id_usuario,
                                          cronograma.id_estado,
                                          cronograma.fecha,
                                          cronograma.id_cronograma,
                                          cronograma.id_comunidad,
                                          cronograma.hora_i,
                                          cronograma.hora_f,
                                          cronograma.id_actividad,
                                          cronograma.id_operador,
                                          cronograma.descripcion,
                                          cronograma.activo,
                                          cronograma.id_anterior,
                                          cronograma.idpoblacion,
                                          cronograma.lugar,
                                          cronograma.realizada,
                                          cronograma.aval,
                                          cronograma.casco,
                                          cronograma.municipio,
                                          usuario.id_usuario AS id_usuario1,
                                          usuario.cedula,
                                          usuario.nombre_u,
                                          usuario.usuario,
                                          usuario.password,
                                          usuario.id_operador AS id_operador1,
                                          usuario.Idcargo,
                                          usuario.estado,
                                          usuario.idcoordinacion  FROM cronograma 
                                INNER JOIN usuario on usuario.id_usuario=cronograma.id_usuario 
                                WHERE  idcoordinacion='".$_SESSION['usua']."' AND id_estado =0 
                                  AND (year(fecha)=YEAR(NOW()) and month(fecha)=(MONTH (NOW())-1) ) or (year(fecha)>YEAR(NOW()) and month(fecha)>(MONTH (NOW())) ) ))as t ORDER BY nombre_u ASC");									
  									
                    $query_e=$db->query("(SELECT * FROM cronograma 
            															 INNER JOIN usuario on usuario.id_usuario=cronograma.id_usuario 
            															 WHERE cronograma.id_usuario='".$_SESSION['usua']."'  AND id_estado =0
            													       AND (year(fecha)=YEAR(NOW()) and month(fecha)=(MONTH (NOW())-1) ) or (year(fecha)>YEAR(NOW()) and month(fecha)>(MONTH (NOW())) )
            															 ORDER BY fecha DESC )
          															 UNION
          															 (SELECT * FROM cronograma 
            															  INNER JOIN usuario on usuario.id_usuario=cronograma.id_usuario 
            															  WHERE  idcoordinacion='".$_SESSION['usua']."'   AND id_estado =0 
            											             AND (year(fecha)=YEAR(NOW()) and month(fecha)=(MONTH (NOW())-1) ) or (year(fecha)>YEAR(NOW()) and month(fecha)>(MONTH (NOW())) )
            															  ORDER BY fecha DESC  )");
									while($ev=$query_e->fetch_array()){ $s=$s+$ev['aval'];}
  									if ($query_eventos) 
  									{	$tos=$query_eventos->fetch_array();	$_SESSION['cuanto']=$tos[0]; $_SESSION['cuantas']=$s; echo $_SESSION['cuantas']."-".$_SESSION['cuanto'];
  									}else{ echo "<p class='ko'>Se ha producido un error modificando el evento.'".intval($_POST["act"])."'</p>";}
					
				
					
						
						?>