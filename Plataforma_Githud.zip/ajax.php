<?php require_once("config.php"); 
@session_start();
?>
<!DOCTYPE html>
<html>
<meta charset="UTF-8">
	<head>
		<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
		<script src="js/jquery.validate.min.js"></script>
		<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/localization/messages_es.js "></script>
        <script src="http://jqueryvalidation.org/files/dist/additional-methods.min.js"></script>
        <script src="js/funciones_ajax.js"></script> 
		<link href="css/calendar.min.css" rel="stylesheet">
		<script type="text/javascript">

                     $(document).ready(function(){
           $('#motivo').focusout(function(){
            if ($(this).val()!="") { 
              $('#motiv').html('<input type="submit" value="Eliminar Actividad.">');}
                 });            
      
                      });
    </script>
	</head>
	<body>
		<?php
		function fecha($fecha,$forma)
		{
			$trim=explode("-",$fecha);
			if (intval($trim[2])<10) $trim[2]="0".$trim[2];
			if ($forma=="es") return $trim[2]."-".$trim[1]."-".$trim[0];
			elseif ($forma=="en") return $trim[0]."-".$trim[1]."-".$trim[2];
		}
		switch ($_GET["accion"])
		{
			case "insertar":
					?>
                   <div align="center"> 
				<h1>Crear Actividad el <?php echo fecha($_GET["dia"],"es"); ?></h1><?php
					if (isset($_POST) && count($_POST)>0)
					{ if($_POST['actividad']==0)
						{ echo "<p class='ko'>Seleccione alguna actividad.</p>";
						}else{
							if($_POST['poblacion']==0)
								{ echo "<p class='ko'>Seleccione alguna poblacion.</p>";
								}else{ 
									if($_POST['com']=='')
									{ echo "<p class='ko'>Seleccione alguna Comunidad.</p>";
									}else{
													$query_eventos=$db->query("insert into cronograma (id_comunidad,fecha,hora_i,hora_f,
														   id_actividad,id_operador,descripcion,id_estado,
														   activo,id_anterior,id_usuario,idpoblacion,lugar,
														   casco,municipio)
															values ('".$_POST["com"]."','".$_POST["fecha"]."',
																	 '".$_POST["hora_i"]."','".$_POST["hora_f"]."',
																	 '".$_POST['actividad']."','".$_SESSION['opera']."',
																	 '".$_POST['evento']."',0,0,0,'".$_SESSION['usua']."',
																	 '".$_POST['poblacion']."','".$_POST['lugar']."',
																	 '".$_POST['casco']."','".$_POST['municipio']."')");
									if ($query_eventos){ $_SESSION['fec']=$_POST["fecha"]; 
													 echo "<p class='ok'>El evento se ha guardado correctamente.</p>";	
																		
												   }else{ echo "<p class='ko'>Se ha producido un error guardando el evento.</p>";}
									}
									}
							  }
					}
					if (isset($_GET["dia"]) && !isset($_POST["evento"]))
					{
						?>
                        <div id='container'>
                        	<form action="" method="post" class="datos">
                       			 <fieldset>
                                    <table width="100%" >
                                              <tr>
                                                <td width="519" rowspan="2" align="right">Lugar de Encuentro</td>
                                                <td width="269">
                                                  <select id='lugar' class="valida" name='lugar' style="width:20px;" >
                                                    <option value='0'>Elija Una Opcion: </option>
                                                   		 <?php 	$query_eventos=$db->query("SELECT * FROM municipio order by municipio asc ");
                                                                while ($eventos=$query_eventos->fetch_array()){ echo "<option value='".$eventos[0]."'>".$eventos[1]."</option>";} 
                                                          ?>
                                                  </select>
                                                  <input id="lu" type="text" class="required" readonly value="" placeholder='Municipio' size="35" disabled/>
                                                </td>
                                              </tr>
                                              <tr>
                                                <td>
                                                  <select id='casco' name='casco' style="width:20px;" class="valida">
                                                    <option value='0'>Elija Una Opcion: </option>
                                                    	<?php 	$query_eventos=$db->query("SELECT * FROM tipo_lugar order by tipo_lugar asc ");
                                                            while ($eventos=$query_eventos->fetch_array()){ echo "<option value='".$eventos[0]."'>".$eventos[1]."</option>";} 
                                                         ?>
                                                  </select> 
                                                  <input id="lu1" type="text" placeholder='Sitio' class="required" readonly value="" size="35" disabled/>
                                                 </td>
                                              </tr>
                                       </table>
                                       <table width="100%" >
                                              <tr>
                                                <td width="130" rowspan="2" align="right">Hora de Actividad:</td>
                                                <td width="404">Inicial:
                                                  <input id="hora_i" name="hora_i" type="time" class="required" size="10" />
                                                </td>
                                              </tr>
                                              <tr>
                                                <td>Final:
                                                  <input id="hora_f" name="hora_f" type="time" class="required" size="10" />
                                                </td>
                                              </tr>
                                       </table>
                                       <table width="100%" >
                                              <tr>
                                                <td width="271" align="right">Tipo de Actividad      </td>
                                                <td width="517" align="left">
                                                    <select id='actividad' name='actividad' class="valida">
                                                      <option value='0'>Elija Una Opcion: </option>
                                                              <?php 	$query_eventos=$db->query("SELECT * FROM actividad order by  nombre_act asc");
                                                                         while ($eventos=$query_eventos->fetch_array())
                                                                          { echo "<option value='".$eventos[0]."'>".utf8_encode($eventos[1])."</option>"; }
                                                               ?>
                                                    </select>
                                                </td>
                                              </tr>
                                              <tr>
                                                <td align="right">Poblacion Objeto:      </td>
                                                <td align="left"><select id='poblacion' name='poblacion' class="valida">
                                                  <option value="0">Elija Una Opcion:</option>
                                                  <?php $query_eventos=$db->query("SELECT * FROM poblacion order by nombre asc ");
                                                                                        while ($eventos=$query_eventos->fetch_array())
                                                                                            {    echo "<option value='".$eventos[0]."'>".$eventos[1]."</option>"; }
                                                                                    ?>
                                                </select></td>
                                                </tr>
                                              <tr>
                                                <td align="right">
                                            Municipio:  </td>
                                                <td align="left"><select id='municipio' name='municipio' class="valida">
                                                  <option value='0'>Elija Una Opcion: </option>
                                                  <?php 	$query_eventos=$db->query("SELECT * FROM municipio order by municipio asc ");
                                                                                                    while ($eventos=$query_eventos->fetch_array())
                                                                                                    { echo "<option value='".$eventos[0]."'>".$eventos[1]."</option>";} 
                                                                                            ?>
                                                </select></td>
                                                </tr>
                                            </table>
                                            <table width="100%" >
                                              <tr>
                                                <td align="center"><input name="com" type="text" style="visibility:hidden"  class="submit required" id="com" size="12" /></td>
                                                </tr>
                                              <tr>
                                                <td align="center">Seleccione La Comunidad (es): 
                                                  <input type="button" class="quitar der" value="« Quitar Uno" />
                                                  <input type="button" class="quitartodos der" value="« Quitar Todos" /></td>
                                              </tr>
                                              <tr>
                                                <td align="center"><select name="comunidad[]2"  multiple="multiple" size="6" class="valida pasar" id="comunidad">
                                                  </select>      <select name="destino[]" id="destino" multiple="multiple" size="6">
                                                  </select>      </td>
                                              </tr>
                                              <tr>
                                                <td align="center">
                                                  Descripcion de Actividad: 
                                                  <textarea name="evento" minlength="60" cols="50"  rows="4" class="required"></textarea>
                                                  </td>
                                              </tr>
                                            </table>                                      
                                                                             <div class="tabl5" style="width:'120px';"></div>
                                                                                  <input type="hidden" name="fecha" value="<?php echo fecha($_GET["dia"],"en"); ?>">
                                                                                    <?php if(!empty($_SESSION['login_user']))
                                                                                                { ?>
                                                                                    <input type="submit" value="Guardar Actividad">
                                                                                    <?php
                                                                                                } ?>
	  						             </fieldset>
						              </form>		
                        </div>
                        </div>	                    
	      <?php
					}
			break;
			
			case "edicion":
              					?>
           <div align="center">
                    <h1>Editar una Actividad </h1>
              				<?php              				
              				if (isset($_POST) && count($_POST)>0)
              				{ //lugar
              						if (!empty($_POST["lugara"]))
              						{		$query_eventos=$db->query("UPDATE  cronograma SET lugar='".$_POST["lugara"]."' WHERE  cronograma.id_cronograma ='".intval($_POST["idevento"])."'");							}
              						//lugar
              						if (!empty($_POST["casca"]))
              						{		$query_eventos=$db->query("UPDATE  cronograma SET casco='".$_POST["casca"]."' WHERE  cronograma.id_cronograma ='".intval($_POST["idevento"])."'");		}
              						//municipio2
              						if (!empty($_POST["municipio2"]))
              						{		$query_eventos=$db->query("UPDATE  cronograma SET municipio='".$_POST["municipio2"]."' WHERE  cronograma.id_cronograma ='".intval($_POST["idevento"])."'");		}              						
              				  //comunidad
              				  	if (($_POST["comunidad2"])!=($_POST["com"]))
              						{		$query_eventos=$db->query("UPDATE  cronograma 
              						SET id_comunidad='".$_POST["com"]."' WHERE  cronograma.id_cronograma ='".intval($_POST["idevento"])."'");							}              				  //hora I //hora F
              				  		if ((!empty($_POST["hora_i"]))&&(!empty($_POST["hora_f"])))
              						{		$query_eventos=$db->query("UPDATE  cronograma 
              						SET hora_i ='".$_POST["hora_i"]."',hora_f ='".$_POST["hora_f"]."' WHERE  cronograma.id_cronograma ='".intval($_POST["idevento"])."'");							
              								$query_eventos=$db->query("insert into notifica (id_cronograma,hi,hf) values('".$_POST["idevento"]."','".$_POST['hora_i']."','".$_POST['hora_f']."')");
              						}		
              				  //tipo acti
              				  		if (!empty($_POST["actividad"]))
              						{		$query_eventos=$db->query("UPDATE  cronograma 
              						SET id_actividad = '".$_POST["actividad"]."' WHERE  cronograma.id_cronograma ='".intval($_POST["idevento"])."'");							}
              				  //Pob. Obj.
              				  		if (!empty($_POST["poblacion"]))
              						{		$query_eventos=$db->query("UPDATE  cronograma 
              						SET idpoblacion='".$_POST["poblacion"]."' WHERE  cronograma.id_cronograma ='".intval($_POST["idevento"])."'");							}
              				  //Descripcion
              				  		if (!empty($_POST["evento"]))
              						{		$query_eventos=$db->query("UPDATE  cronograma 
              						SET descripcion='".$_POST["evento"]."' WHERE  cronograma.id_cronograma ='".intval($_POST["idevento"])."'");							}
              				  
              						
              					if ($query_eventos) echo "<p class='ok'>El evento se ha modificado correctamente.</p>";
              					else echo "<p class='ko'>Se ha producido un error modificando el evento.</p>";
              				}
              							if (isset($_GET["idevento"]) && !isset($_POST["idevento"]))
              				{
              					$query_eventos=$db->query("select * from cronograma where id_cronograma='".intval($_GET["idevento"])."' limit 1");
              					if ($evento=$query_eventos->fetch_array())
              					{
              					?>
                                    <div id='container'>
                				<form action="" method="post" class="datos">
              					  <fieldset>
                
                                  <table width="100%" >
                                  <tr>
                                    <td width="224" rowspan="2"><label>Lugar de Encuentro:</label>
                                      <?php 	
                                	$query_e=$db->query("SELECT municipio FROM municipio 
                                						INNER JOIN comunidad ON municipio.id_municipio = comunidad.id_municipio 
                                						WHERE id_comunidad ='".$evento['id_comunidad']."'");
                                						$e=$query_e->fetch_array();
                                						 	$query_ee1=$db->query("select * from cronograma
                                													 inner join tipo_lugar on cronograma.casco=tipo_lugar.Id 
                                                         							 inner join municipio on municipio.id_municipio=cronograma.lugar  
                                													 where cronograma.id_cronograma='".$evento['id_cronograma']."'");
                                									$ee1=$query_ee1->fetch_array();?></td>
                                    <td width="25"><select id='lugar2' class='' name='lugar2' style='width:20px;' >
                                      <option value='0'>Elija Una Opcion: </option>
                                      <?php 	$query_eventos=$db->query("SELECT * FROM municipio order by municipio asc ");
                                													while ($eventos=$query_eventos->fetch_array())
                                													{ echo "<option value='".$eventos[0]."'>".$eventos[1]."</option>";} 
                                											?>
                                    </select></td>
                                    <td width="279"><input id='lu6' class='required' style="visibility:hidden"  type='text' name='lugara' size='13px'  readonly value='<?php echo utf8_encode($evento['lugar'])?>' /></td>
                                  </tr>
                                  <tr>
                                    <td><select id='casco2' name='casco2' style="width:20px;" class="">
                                      <option value='0'>Elija Una Opcion: </option>
                                      <?php 	$query_eventos=$db->query("SELECT * FROM tipo_lugar order by tipo_lugar asc ");
                                													while ($eventos=$query_eventos->fetch_array())
                                													{ echo "<option value='".$eventos[0]."'>".$eventos[1]."</option>";} 
                                											?>
                                    </select></td>
                                    <td><input id='lu7' type='text' style="visibility:hidden" name='casca' size='13px'  class='required' readonly value='<?php echo utf8_encode($evento['casco'])?>' /></td>
                                  </tr>
                                </table>
                  <table width="100%" >
                     <tr>
                         <td><input id="lu9" type="text"  class="required" readonly value='<?php echo utf8_encode($ee1['municipio'])?>' disabled="disabled"/></td>
                        <td rowspan="2"><label>Cambiar a &rArr;</label>
                                       &hArr;
                             <?php 	$query_eventos=$db->query("SELECT * FROM comunidad where id_comunidad='".$evento['id_comunidad']."'");
                                	$eventos=$query_eventos->fetch_array();
                               ?>
                            <input size='2px' id='comunidad2'  name='comunidad2' hidden="true" type='text' readonly value=' <?php echo $evento[1]; ?>' /></td>
                        <td><input id="lup" type="text" class="required" readonly value="" size="15" disabled="disabled"/></td>
                                   </tr>
                                   <tr>
                                     <td><input id="lu"  type="text" class="required" readonly value='<?php echo $ee1['tipo_lugar']?>' disabled="disabled"/></td>
                                     <td><input id="lup1" type="text" class="required" readonly value="" size="15" disabled="disabled"/></td>
                                   </tr>
                                  </table>
                                 <table width="100%" >
                                   <tr>
                                     <td width="424" rowspan="2" align="right">Hora de la Actividad:</td>
                                     <td width="97" align="right">Inicial</td>
                                     <td width="263"><input name="hora_i" type="time" class="required" value="<?php echo $evento["hora_i"]; ?>" size="10" /></td>
                                   </tr>
                                   <tr>
                                     <td align="right">Final:</td>
                                     <td><input name="hora_f" type="time" class="required" value="<?php echo $evento["hora_f"]; ?>" size="10" /></td>
                                   </tr>
                                   </table>
                                 <table width="100%" >
                                   <tr>
                                     <td align="center"><label>Tipo Actividad:</label></td>
                                     <td align="center"><label>Poblacion Objeto:</label></td>
                                    </tr>
                                   <tr>
                                     <td align="center"><select name='actividad' >
                                       <option value='0'>Seleccione un Tipo de Act. </option>
                                      				 <?php 					$query_eventos=$db->query("SELECT * FROM actividad");
                                										while ($eventos=$query_eventos->fetch_array())
                                										{ if ($evento["id_actividad"]==$eventos[0])
                                											{	echo "<option selected value='".$eventos[0]."'>".utf8_encode($eventos[1])."</option>"; 
                                											 } else{ echo "<option value='".$eventos[0]."'>".utf8_encode($eventos[1])."</option>"; }
                                									     }
                                										 ?>
                                       </select></td>
                                     <td align="center"><select id='poblacion' name='poblacion'>
                                       <option value='0'>Seleccione una Poblacion </option>
                                         <?php 	$query_eventos=$db->query("SELECT * FROM poblacion ");
                                										while ($eventos=$query_eventos->fetch_array())
                                 											{  if ($evento["idpoblacion"]==$eventos[0])
                                													{	   echo "<option selected value='".$eventos[0]."'>".$eventos[1]."</option>"; 
                                													}else{ echo "<option  value='".$eventos[0]."'>".$eventos[1]."</option>"; }
                                											 }
                                									?>
                                       </select></td>
                                   </tr>
                                   </table>
                                 
                                 <table width="100%" >
                                   <tr>
                                    <td width="88">&nbsp;</td>
                                    <td width="243">Municipio:
                                <select id='municipio2' name='municipio2' class="">
                                      <option value='0'>Elija Una Opcion: </option>
                                      <?php 	$query_eventos=$db->query("SELECT * FROM municipio order by municipio asc ");
                                						while ($eventos=$query_eventos->fetch_array())
                                							{  
                                							if($evento['municipio']==$eventos['id_municipio'])
                                							{echo "<option selected value='".$eventos[0]."'>".utf8_encode($eventos[1])."</option>";
                                							}else{	echo "<option value='".$eventos[0]."'>".$eventos[1]."</option>";}
                                							} 
                                											?>
                                    </select></td>
                                    <td width="197"><input name="com"  type="text" hidden="true" class="required" id="com" value=' <?php echo $evento[1]; ?>'  size="20" /></td>
                                  </tr>
                                </table>
                                 <table width="100%" >
                                  <tr>
                                    <td>Seleccione la(s) Comunidad(es):
                                      <input type="button" class="quitar der" value="« Quitar Uno" />
                                      <input type="button" class="quitartodos der" value="« Quitar Todos" /></td>
                                  </tr>
                                  <tr>
                                    <td align="center"><span class="clear"><strong><p>
                                      <?php
                                									  $cnt=0;$comnuni="";	
                                                                      $piezas = explode(",", $evento["id_comunidad"]);
                                					while (count($piezas)>$cnt){
                                						$sql=$db->query("SELECT comunidad, municipio,id_comunidad FROM municipio 
                                										INNER JOIN comunidad ON municipio.id_municipio=comunidad.id_municipio 
                                										where id_comunidad='".$piezas[$cnt]."'");
                                							$comn=$sql->fetch_array();
                                									//echo $comn[0]."-".$comn[1];
                                								
                                									if($piezas[$cnt]=='cen'){$comnuni='Centro Poblado'.','.$comnuni;}else{	
                                										if($piezas[$cnt]=='cas'){$comnuni='Casco Urbano'.','.$comnuni;}
                                												else
                                												 {$comnuni=$comn[0].','.$comnuni;}
                                																	
                                									}	$cnt=$cnt+1;
                                					}
                                					?>
                                      <?php $comnuni = trim($comnuni, ','); echo utf8_encode($comnuni); ?></p></strong></span></td>
                                    </tr>
                                  <tr>
                                    <td align="center"><select name="comunidad[]" size="6" multiple="multiple"  class="valida pasar" id="comunidad11">
                                      </select> <select name="destino[]" id="destino" multiple="multiple" size="6">
                                        <?php
                                									  $cnt=0;$comnuni="";	
                                                                      $piezas = explode(",", $evento["id_comunidad"]);
                                					while (count($piezas)>$cnt){
                                						$sql=$db->query("SELECT comunidad, municipio,id_comunidad FROM municipio 
                                										INNER JOIN comunidad ON municipio.id_municipio=comunidad.id_municipio 
                                										where id_comunidad='".$piezas[$cnt]."'");
                                							$comn=$sql->fetch_array();
                                									//echo $comn[0]."-".$comn[1];
                                												if($piezas[$cnt]=='cen'){$comnuni='Centro Poblado'.','.$comnuni;
                                											 echo"<option value='cen'>Centro Poblado</option>";
                                										}else{	
                                										if($piezas[$cnt]=='cas'){
                                											 echo"<option value='cas'>Casco Poblado</option>";
                                											$comnuni='Casco Urbano'.','.$comnuni;}
                                												else
                                												 {$comnuni=$comn[0].','.$comnuni; 
                                												 if($comn[0]<>''){
                                													 echo"<option value='$comn[2]'>".utf8_encode($comn[0])."</option>";}}
                                																	
                                									}	$cnt=$cnt+1;
                                					}
                                					?>
                                        <?php $comnuni = trim($comnuni, ','); //echo $comnuni; ?>    
                                      </select></td>
                                    </tr>
                                  <tr>
                                    <td align="center">Descripcion de Actividad:
                                      <textarea name="evento" maxlength="250" minlength="60" cols="60" rows="4" class="required"><?php echo $evento["descripcion"]; ?></textarea></td>
                                    </tr>
                                  <tr>
                                    <td><p>
                                      <input type="hidden" name="idevento" value="<?php echo $evento["id_cronograma"]; ?>" />
                                    </p>
                                      <?php
                                										if(!empty($_SESSION['usua']))
                                										{	if($result = $db->query("SELECT id_usuario FROM cronograma where id_cronograma='".intval($_GET["idevento"])."' and id_usuario='".$_SESSION['usua']."'"))
                                											{ $row_cnt = $result->num_rows;
                                												if($row_cnt>0){
                                														echo "<input type='submit' value='Modificar Evento'>";
                                													}else{
                                														echo "<p class='ko'>Usted No Tiene Permiso para Modificar Pongase en Contacto con el Usuario para Coordinar Su Actividad.</p>";
                                														}}
                                											}else{
                                											echo "<p class='ko'>Usted es Invitado no Tiene Permiso para Modiicar.</p>";
                                											}
                                								?></td>
                                    </tr>
                                </table>

                                 
                                						
                                					 	
                                						 	
                                					   
                                					  </fieldset>
                                </form>
                                </div></div>
                                          <?php
                                					}
                                				}
			 break;
			
			case "eliminar":
							?>
                   <h1>Eliminar un Actividad
					  </h1>
					<?php
				if (isset($_POST) && count($_POST)>0)
				{	if($_SESSION['coord']==0){
						$query_eventos=$db->query("UPDATE cronograma SET  id_estado ='1', id_anterior='1', activo='1' where id_cronograma='".intval($_POST["idevento"])."'");
				}else{ $query_eventos=$db->query("UPDATE cronograma SET  id_anterior ='1' where id_cronograma='".intval($_POST["idevento"])."'");}
					if ($query_eventos) echo "<p class='ok'>El evento se ha eliminado correctamente.</p>";
					else echo "<p class='ko'>Se ha producido un error eliminando el evento.</p>";
				}
				if (isset($_GET["idevento"]) && !isset($_POST["idevento"]))
				{
					$query_eventos=$db->query("select * from cronograma where id_cronograma='".intval($_GET["idevento"])."' limit 1");
					if ($evento=$query_eventos->fetch_array())
					{
					?><div id='container'>
 
					<form action="" method="post" class="datos">
						<fieldset>
						 	<div> 
						 	<table width="auto" border="0" align="center" cellspacing="-5px">
						 	  <tr>
						 	    <td align="left"><label>Lugar de Encuentro:</label>
                                  <?php 	
	                   $query_e=$db->query("SELECT * FROM municipio 
                      INNER JOIN comunidad ON municipio.id_municipio = comunidad.id_municipio 
                      inner join cronograma on cronograma.id_comunidad=comunidad.id_comunidad
                      WHERE cronograma.id_cronograma ='".$evento['id_cronograma']."'");
											$e=$query_e->fetch_array();
											?>
                                  <label>
                                    <input id='lu8' class='required' style="visibility:hidden"  type='text' name='lu' size='3px'  readonly value='<?php echo utf8_encode($e['lugar'])?>' />
                                    <input id='lu9' type='text' name='lu' style="visibility:hidden" size='3px'  class='required' readonly value='<?php echo utf8_encode($e['casco'])?>' />
                                  </label></td>
					 	      </tr>
						 	  <tr>
						 	    <td align="left" >
                                <?php 	$query_e=$db->query("SELECT * FROM cronograma
                      INNER JOIN tipo_lugar ON tipo_lugar.Id = cronograma.casco
                      inner join municipio on municipio.id_municipio= lugar 
					     inner join comunidad on comunidad.id_municipio=comunidad.id_municipio 
                     
                      WHERE cronograma.id_cronograma ='".$evento['id_cronograma']."'");
											$e1=$query_e->fetch_array();
								 ?>
 <input id="lu5" type="text"  class="required" readonly value='<?php echo utf8_encode($e1['municipio']);?>' />
 <input id="lu4"  type="text" class="required" readonly value='<?php echo $e1['tipo_lugar'];?>' />
                                   <br />
                                   </td>
					 	      </tr>
						 	  <tr>
						 	    <td align="left"><label>Municipio:
                                
                                   <?php 
								   echo "<strong>".utf8_encode($e[1])."</strong>";
										?>
                             </label></td>
					 	      </tr>
						 	  <tr>
						 	    <td align="left"><label>
                                 Comunidad
						 	        <?php
									  $cnt=0;$comnuni="";	
									//  echo $evento["id_comunidad"];
                                      $piezas = explode(",", $evento["id_comunidad"]);
					while (count($piezas)>$cnt){
						$sql=$db->query("SELECT comunidad, municipio,id_comunidad FROM municipio INNER JOIN comunidad ON municipio.id_municipio=comunidad.id_municipio where id_comunidad='".$piezas[$cnt]."'");
							$comn=$sql->fetch_array();
									//echo $comn[0]."-".$comn[1];
				if($piezas[$cnt]=='cen'){
					$comnuni='Centro Poblado'.','.$comnuni;
					}else{	if($piezas[$cnt]=='cas')
								{$comnuni='Casco Urbano'.','.$comnuni;
								}else{$comnuni=$comn[0].','.$comnuni;}
									}	$cnt=$cnt+1;
					}
					?>
      <?php  echo utf8_encode(trim($comnuni, ','));  ?></label></td>
					 	      </tr>
						 	  <tr>
						 	    <td align="left">Hora del Evento:(Inicial &rArr; <?php echo "<strong>".$evento["hora_i"]."</strong>"; ?>    &hArr;   Final &rArr; <?php echo "<strong>".$evento["hora_f"]."</strong>"; ?>)</td>
					 	      </tr>
						 	  
						 	  <tr>
						 	    <td align="left"><label>Tipo Actividad &rArr;
						 	      <?php 						 
									$query_eventos=$db->query("SELECT * FROM actividad");
										while ($eventos=$query_eventos->fetch_array())
										{ if ($evento["id_actividad"]==$eventos[0])
											{	echo "<strong>".utf8_encode($eventos[1])."</strong>"; 
											 } 
									     }?>
					 	        </label></td>
					 	      </tr>
						 	  <tr>
						 	    <td align="left"><label>Poblacion Objeto:&rArr;
						 	      
						 	      <?php 	$query_eventos=$db->query("SELECT * FROM poblacion ");
										while ($eventos=$query_eventos->fetch_array())
 											{  if ($evento["idpoblacion"]==$eventos[0])
													{
												 echo "<strong>".$eventos[1]."</strong>"; 
													}
											 }
									?>
					 	        </select></label></td>
					 	      </tr>
						 	  <tr>
						 	    <td><label>Descripcion de Actividad: </label>

                 
                             
								<?php echo "<p align='justify' style='background:#ffd; border-color:#cbb; with:300px;'>".$evento["descripcion"]."</p>"; ?>
						 	     
					 	       </td>
					 	      </tr>
						 	 
					 	  </table>
						 	<div/>
       		            
								<input type="hidden" name="idevento" value="<?php echo $evento["id_cronograma"]; ?>">
								<?php
										if(!empty($_SESSION['usua']))
										{	if($result = $db->query("SELECT id_usuario FROM cronograma where id_cronograma='".intval($_GET["idevento"])."' and id_usuario='".$_SESSION['usua']."'"))
											{ $row_cnt = $result->num_rows;
												if($row_cnt>0){ 
                                      if (($evento["motivo"]==Null)||($evento["motivo"]=="")) {
                                     echo ' <p class="aler">
                                                 Por favor Explique, Motivo de la Eliminacion:
                                                    </p>
      
                      <textarea id="motivo" maxlength="250" minlength="60" cols="60" rows="4" class="required">'.$evento["motivo"].'</textarea>';
                      ?>
                      <div id="motiv"></div>
                      <?php
                                      }else{echo "<input type='submit' value='Eliminar Actividad.'>";}
                  
                  
														
													}else{
														echo "<p class='ko'>Usted No Tiene Permiso para Modificar Pongase en Contacto con el Usuario para Coordinar Su Actividad.</p>";
														}}
											}else{
											echo "<p class='ko'>Usted es Invitado no Tiene Permiso para Modiicar.</p>";
											}
								?>
							</div>
  </fieldset>
</form>
					<?php
					}
				}
			break;
		
		}
		?>
	</body>
</html>