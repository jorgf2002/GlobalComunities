<html>
	<head>
 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />    
    <link href='http://fonts.googleapis.com/css?family=Roboto:500,300,400' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" type="text/css" href="../../css/menu_bene.css">
 
 </head>
 <script>
 $(document).ready(function() {	
				   
                           $("a").on("click", function(){
                           var url_ins=$(this).attr('data'); 
                            if(url_ins!='undefined'){
                            $(".calendar").load(url_ins);
                                }else{ return false; }
                        });
				
});</script>
 <body>
<div > 

  <div id='menuppal'>
 <ul class="nav nav-pills">
              <li class='has-sub' class="active"><a id="capa" href="#"><span>Capacitacion</span></a></li>
              <li class='has-sub'><a id="briga" href="#" class="">Brigagas</a></li>  
              <li class='has-sub'><a id="disabeld"  href="#">Disabled</a></li>
            </ul>
</div>
           
</div>
<div class="panel panel-warning">
  <div class="panel-heading">
    <h1 class="panel-title">Capacitacion</h1>
  </div>
  <div id="cap" class="panel-body">  
  </div>
</div>
 
</body>