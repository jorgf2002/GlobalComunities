
<div id="divContenedor">
<?php
	if(@$_FILES['archivo']['name'] != null && @$_FILES['archivo']['size'] > 0 )
			{	//subir la imagen del articulo
				$nameEXCEL = $_FILES['archivo']['name'];

				$tmpEXCEL = $_FILES['archivo']['tmp_name'];
				$extEXCEL = pathinfo($nameEXCEL);
				$urlnueva = "xls/Archivo_temporal.xlsx";			
				if(is_uploaded_file($tmpEXCEL)){
					copy($tmpEXCEL,$urlnueva);	
					echo '<div align=""><h1>Datos Actualizados con Exito</h1></div>';
											}
			} 
		if(@$_FILES['archivo']['name'] != null && @$_FILES['archivo']['size'] > 0 )
		{
			require_once '../lib/PHPExcel/PHPExcel/IOFactory.php';
				$objPHPExcel = PHPExcel_IOFactory::load('../Beneficia/xls/Archivo_temporal.xlsx');
        		$objWorksheet = $objPHPExcel->setActiveSheetIndexByName('Capacitación para sistematizar');  
				$objHoja=$objPHPExcel->getActiveSheet()->toArray('Capacitación para sistematizar',null,true,true,true,true,true,true); 
			 ?>

			 <h3>INFORMACION DE CAPACITADOR / ENTIDAD</h3>
			 <table border="0" cellpadding="0" cellspacing="0">
				<thead>
					<tr>						
						<th>Capacitador</th>
						<th>Correo</th>
						<th>Entidad Capacitadora</th>
						<th>Direccion Entidad Capacitadora</th>
						<th>Tel. Entidad Capacitadora</th>
						<th>Tel. contacto Entidad Capacitadora</th>
					</tr>
				</thead>
				<tbody>
                		<td><input name="capacitador2"  type="text" value="<?php echo $objPHPExcel->getActiveSheet()->getCell('AD8')->getFormattedValue(); ?>" /></td>
                        <td><input name="capacitador3"  type="text" value="<?php echo $objPHPExcel->getActiveSheet()->getCell('AE8')->getFormattedValue(); ?>" /> </td>
                        <td> <input name="capacitador2"  type="text" value="<?php echo $objPHPExcel->getActiveSheet()->getCell('AF8')->getFormattedValue(); ?>"/></td>
                        <td><input name="capacitador3"  type="text" value="<?php 
                              $AG=$objPHPExcel->getActiveSheet()->getCell('AG8')->getFormattedValue(); 
                              $AH=$objPHPExcel->getActiveSheet()->getCell('AH8')->getFormattedValue(); 
                              echo $AG." / ".$AH 
                            ?>"/></td>
                          <td><input name="capacitador2"  type="text" value="<?php echo $objPHPExcel->getActiveSheet()->getCell('AI8')->getFormattedValue(); ?>" /></td>
                          <td><input name="capacitador2"  type="text" value="<?php echo $objPHPExcel->getActiveSheet()->getCell('AJ8')->getFormattedValue(); ?>"/>
                          </td>
                </tbody>
             </table>           
             	<!-- tabla 2 -->
             	<h3>DATOS DE DE CONTRATO</h3>
			 <table border="0" cellpadding="0" cellspacing="0">
				<thead>
					<tr>
						<th>Año</th>
						<th>Trimestre</th>
						<th>Cod Convenio/Contrato</th>
						<th>Nombre Entidad Ejecutora</th>
					</tr>
				</thead>
				<tbody>
                	<td><input name="capacitador"  type="text" value="<?php echo $objPHPExcel->getActiveSheet()->getCell('B8')->getFormattedValue(); ?>"/></td>
                	<td><input name="capacitador"  type="text" value="<?php echo $objPHPExcel->getActiveSheet()->getCell('C8')->getFormattedValue(); ?>"/></td>
                    <td><input name="capacitador2"  type="text" value="<?php echo $objPHPExcel->getActiveSheet()->getCell('D8')->getFormattedValue(); ?>"/></td>
                    <td><input name="capacitador3"  type="text" value="<?php echo $objPHPExcel->getActiveSheet()->getCell('E8')->getFormattedValue(); ?>"/></td>
                </tbody>
             </table>             
             	<!-- tabla 3 -->
             	 <h3>CAPACITACION</h3>
             <table border="0" cellpadding="0" cellspacing="0">
				<thead>
					<tr>
						<th>Nombre de Capacitacion</th>
						<th>Dpto/Municipio</th>
						<th>Lugar de Capacitacion</th>
						<th>Fecha(Inicio-Fin)</th>
						<th>Horas de Duracíon</th>
						<th>Entrenamiento (Metodo-Tipo)</th>
						<th>Campo de Estudio / Area Tematica </th>	
					</tr>
				</thead>
				<tbody>
                <td><input name="capacitador3"  type="text" value="<?php echo $objPHPExcel->getActiveSheet()->getCell('S8')->getFormattedValue(); ?>"/>
                </td>
                <td><input name="capacitador2"  type="text" value="<?php $T=$objPHPExcel->getActiveSheet()->getCell('T8')->getFormattedValue();$U=$objPHPExcel->getActiveSheet()->getCell('U8')->getFormattedValue();
                        			echo $T."/".$U ; ?>"/>
                                    </td>
                <td><input name="capacitador2"  type="text" value="<?php echo $objPHPExcel->getActiveSheet()->getCell('V8')->getFormattedValue(); ?>"/></td>
                <td><input name="capacitador2"  type="text" value="<?php $W=$objPHPExcel->getActiveSheet()->getCell('W8')->getFormattedValue();$X=$objPHPExcel->getActiveSheet()->getCell('X8')->getFormattedValue(); 
                        			echo $W."//".$X; ?>"/>
                                    </td>
                <td><input name="capacitador2"  type="text" value="<?php echo $objPHPExcel->getActiveSheet()->getCell('Y8')->getFormattedValue(); ?>"/></td>
                <td><input name="capacitador2"  type="text" value="<?php $Z=$objPHPExcel->getActiveSheet()->getCell('Z8')->getFormattedValue();$AA=$objPHPExcel->getActiveSheet()->getCell('AA8')->getFormattedValue(); 
                        			echo $Z." / ".$AA; ?>"/>
                                    </td>
                                    <td><input name="capacitador2"  type="text" value="<?php $AB=$objPHPExcel->getActiveSheet()->getCell('AB8')->getFormattedValue();$AC=$objPHPExcel->getActiveSheet()->getCell('AC8')->getFormattedValue(); 
                        			echo $AB."//".$AC; ?>"/>
                                    </td>			
                </tbody>
             </table>        
             <!-- tabla 4 -->
              <h3>DATOS DEL BENEFICIARIOS</h3>
                <!--DATOS BENEFICIARIOS -->
			<table border="0" cellpadding="0" cellspacing="0">
				<thead width="auto">
					<tr>
						<th>Tipo de Doc.</th>
						<th># de ID</th>
						<th>Nombre Completo</th>
						<th>Telefono</th>
						<th>Sexo</th>
						<th>Etnia</th>
						<th>Condicíon</th>
						<th>Inscrito</th>
						<th>Discapacitado</th>
						<th>Tipo de Participacntes</th>
						<th>Edad</th>
					</tr>
				</thead>
					<tbody>
						<?php		//recorremos las filas obtenidas
						$cn=8;$coon=0;	  
						$J=$objPHPExcel->getActiveSheet()->getCell('J'.$cn)->getFormattedValue();
                   	foreach ($objHoja as $iIndice=>$objCelda) {
							//imprimimos el contenido de la celda utilizando la letra de cada columna
								if($J!=""){
									$F=$objPHPExcel->getActiveSheet()->getCell('F'.$cn)->getFormattedValue();
									$G=$objPHPExcel->getActiveSheet()->getCell('G'.$cn)->getFormattedValue();
									$H=$objPHPExcel->getActiveSheet()->getCell('H'.$cn)->getFormattedValue();
									$I=$objPHPExcel->getActiveSheet()->getCell('I'.$cn)->getFormattedValue();
									$J=$objPHPExcel->getActiveSheet()->getCell('J'.$cn)->getFormattedValue();
									$K=$objPHPExcel->getActiveSheet()->getCell('K'.$cn)->getFormattedValue();
									$L=$objPHPExcel->getActiveSheet()->getCell('L'.$cn)->getFormattedValue();
									$M=$objPHPExcel->getActiveSheet()->getCell('M'.$cn)->getFormattedValue();
									$N=$objPHPExcel->getActiveSheet()->getCell('N'.$cn)->getFormattedValue();
									$O=$objPHPExcel->getActiveSheet()->getCell('O'.$cn)->getFormattedValue();
									$P=$objPHPExcel->getActiveSheet()->getCell('P'.$cn)->getFormattedValue();
									$Q=$objPHPExcel->getActiveSheet()->getCell('Q'.$cn)->getFormattedValue();
									$R=$objPHPExcel->getActiveSheet()->getCell('R'.$cn)->getFormattedValue();
							echo '<tr>
									<td ><input name="capacitador" type="text" value="'.$F.'"/></td>
									<td ><input name="capacitador2" type="text" value="'.$G.' "/> </td>
									<td ><input name="capacitador3" type="text" value="'.$J.' '.$I.' '.$H.'"/></td>
									<td ><input name="capacitador2" type="text" value="'.$K.'" /> </td>
									<td ><input name="capacitador" type="text" value="'.$L.'" /> </td>
									<td ><input name="capacitador" type="text" value="'.$M.'" /> </td>
									<td ><input name="capacitador" type="text" value="'.$N.'" /> </td>
									<td><input name="capacitador" type="text" value="'.$O.' "/> </td>
									<td><input name="capacitador" type="text" value="'.$P.'" /> </td>
									<td><input name="capacitador" type="text" value="'.$Q.'" /> </td>
									<td><input name="capacitador" type="text" value="'.$R.'" /> </td>
								</tr>'; 							$cn++; 					
						}
					}		
					?>
					</tbody>
				<tfoot>
					<td colspan="11">Hogares</td>
				</tfoot>
			</table><?php }		
					?></div>