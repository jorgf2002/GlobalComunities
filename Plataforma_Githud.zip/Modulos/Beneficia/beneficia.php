<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />    
    <link href='http://fonts.googleapis.com/css?family=Roboto:500,300,400' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" type="text/css" href="./css/excel.css"> 
    <script src="./js/jquery.min.js"></script>
    
     	<title>Plataforma de Hogares-Beneficiarios Directos</title>
    <script>
		 	$(document).ready(function() {	
        $('#barra_p').hide();
					$('body').on('click', '#capa', function(){$("#cap").load('./Modulos/Beneficia/beneficia.php');});
          $( '#form1' )
              .submit( function( e ) {
                $.ajax( {
                  url: './Modulos/Beneficia/beneficia_sub.php',
                  type: 'POST',
                  data: new FormData( this ),
                  processData: false,
                  contentType: false,
                  beforeSend: function(){ $("#barra_p").show();},
                  success: function(data) {
                    $("#archiv").html(data); $("#barra_p").hide(350);}
                      } );
                e.preventDefault();
              } );

			           });
   
    </script>
	</head>
	<body>
    <div id="barra_p">  <div class="preloader-wrapper big active">
      <div class="spinner-layer spinner-blue">
        <div class="circle-clipper left">
          <div class="circle"></div>
        </div><div class="gap-patch">
          <div class="circle"></div>
        </div><div class="circle-clipper right">
          <div class="circle"></div>
        </div>
      </div>

      <div class="spinner-layer spinner-red">
        <div class="circle-clipper left">
          <div class="circle"></div>
        </div><div class="gap-patch">
          <div class="circle"></div>
        </div><div class="circle-clipper right">
          <div class="circle"></div>
        </div>
      </div>

      <div class="spinner-layer spinner-yellow">
        <div class="circle-clipper left">
          <div class="circle"></div>
        </div><div class="gap-patch">
          <div class="circle"></div>
        </div><div class="circle-clipper right">
          <div class="circle"></div>
        </div>
      </div>

      <div class="spinner-layer spinner-green">
        <div class="circle-clipper left">
          <div class="circle"></div>
        </div><div class="gap-patch">
          <div class="circle"></div>
        </div><div class="circle-clipper right">
          <div class="circle"></div>
        </div>
      </div>
    </div></div>
			<div align="center" >
        <form method="POST" action="" id="form1" enctype="multipart/form-data" name="form1">
                                    <strong>Agregar Archivo de Excel [Capacitaciones o Brigadas]</strong>  
                                <div class="file-field input-field ">
                                  <div class="btn orange darken-2">
                                    <span>File</span>
                                     <input type="file" class="btn-success " name="archivo" accept=".xlsx" id="archivo">
                                  </div>
                                  <div class="file-path-wrapper">
                                    <input class="file-path validate " type="text" placeholder="Upload one or more files">
                                  </div>
                                </div>
                                 <input name="button" type="submit" class="btn-primary" id="envi_archiv"  value="Revisar Archivo Excel">
                                 <div id="cargador">
                                    </div>
                  
                               <div id="archiv">
                               </div>
  
      </div>
</body>
</html>