  <!-- LISTA DE CHEQUEO --> 
                       <div class="pestana" id="tab-2" align="center" style="display:block;">
                        <h2>Lista de Chequeo</h2>
                       			<div id="men"><h2>Las Actividades que estan no marcadas, Es porque no se ejecutaron.</h2> </div>
                   					  <?php    @session_start();  require("config.php");  
									 
									  @$fecha=$_GET['fecha'];
  	    	                                                  $query_e=$db->query(" SELECT * FROM 
															  ((SELECT cronograma.id_usuario,
															cronograma.id_estado,
															cronograma.fecha,
															cronograma.id_cronograma,
															cronograma.id_comunidad,
															cronograma.hora_i,
															cronograma.hora_f,
															cronograma.id_actividad,
															cronograma.id_operador,
															cronograma.descripcion,
															cronograma.activo,
															cronograma.id_anterior,
															cronograma.idpoblacion,
															cronograma.lugar,
															cronograma.realizada,
															cronograma.aval,
															cronograma.casco,
															cronograma.municipio,
															usuario.id_usuario AS id_usuario1,
															usuario.cedula,
															usuario.nombre_u,
															usuario.usuario,
															usuario.password,
															usuario.id_operador AS id_operador1,
															usuario.Idcargo,
															usuario.estado,
															usuario.idcoordinacion 
															  FROM cronograma 
															 INNER JOIN usuario on usuario.id_usuario=cronograma.id_usuario 
															 WHERE cronograma.id_usuario='".$_SESSION['usua']."'  AND id_estado =0
															AND (fecha BETWEEN  DATE_SUB( CURDATE( ) , INTERVAL (DAY(NOW())+30) DAY ) AND date_sub(NOW(), INTERVAL (DAY(NOW())) day)) 
															)
															 UNION
															  (SELECT cronograma.id_usuario,
															cronograma.id_estado,
															cronograma.fecha,
															cronograma.id_cronograma,
															cronograma.id_comunidad,
															cronograma.hora_i,
															cronograma.hora_f,
															cronograma.id_actividad,
															cronograma.id_operador,
															cronograma.descripcion,
															cronograma.activo,
															cronograma.id_anterior,
															cronograma.idpoblacion,
															cronograma.lugar,
															cronograma.realizada,
															cronograma.aval,
															cronograma.casco,
															cronograma.municipio,
															usuario.id_usuario AS id_usuario1,
															usuario.cedula,
															usuario.nombre_u,
															usuario.usuario,
															usuario.password,
															usuario.id_operador AS id_operador1,
															usuario.Idcargo,
															usuario.estado,
															usuario.idcoordinacion  FROM cronograma 
															  INNER JOIN usuario on usuario.id_usuario=cronograma.id_usuario 
															  WHERE  idcoordinacion='".$_SESSION['usua']."'   AND id_estado =0 
																	AND fecha BETWEEN  DATE_SUB( CURDATE( ) , INTERVAL (DAY(NOW())+30) DAY ) AND date_sub(NOW(), INTERVAL (DAY(NOW())) day)  ))as t
 
ORDER BY nombre_u ASC");
                                            echo '<div class=""><table cellspacing="0" cellpadding="0">
                                                         <thead>
                                                          <tr>
                                                          <th width="70px" >Fecha</th>
                                                            <th width="90px" >Hora</th>
                                                            <th width="auto" align="justify" >Comunidad</th>
                                                            <th >Pob. Objeto</th>
                                                            <th >Tipo de Act.</th>
                                                            <th >Cargo</th>
                                                            <th width="170px">Nombre</th>
                                                            <th >'; 
											   ?></th>
                                
                              </tr>
                              </thead>
                            <tbody><?php $num=0; $sum=0; /**/
                                                        $band=0;
                                                    $row_cnt = $query_e->num_rows; 
                                                        $cont=0;
                                            if($ev=$query_e->fetch_array()){
                                            do{ $sum=$ev["aval"]+$sum; 
                                            $cont++;$cnt=0;$comnuni="";	
											  $piezas = explode(",", $ev["id_comunidad"]);
                                                while (count($piezas)>$cnt){
                                                    $sql=$db->query("SELECT comunidad, municipio,id_comunidad FROM municipio 
                                                    INNER JOIN comunidad ON municipio.id_municipio=comunidad.id_municipio WHERE id_comunidad='".$piezas[$cnt]."'");
                                                        $comn=$sql->fetch_array(); 
														   if($piezas[$cnt]=='cen'){$comnuni='Centro Poblado'.','.$comnuni;}else{	
                                                                    if($piezas[$cnt]=='cas'){$comnuni='Casco Urbano'.','.$comnuni;}
                                                                            else
                                                                             {$comnuni=$comn[0].','.$comnuni;}                                                                                                
                                                                }	$cnt=$cnt+1;
                                                }                                            
                                                $comnuni = trim($comnuni, ','); 
                                            /////////////////////////////////////////////////
                                            $query_pb=$db->query("SELECT cargo.nombre,
                                                                      usuario.nombre_u,
                                                                      cronograma.id_cronograma
                                                                    FROM
                                                                      municipio
                                                                      INNER JOIN comunidad ON comunidad.id_municipio = municipio.id_municipio
                                                                      INNER JOIN cronograma ON comunidad.id_comunidad =cronograma.id_comunidad
                                                                      INNER JOIN usuario ON usuario.id_usuario = cronograma.id_usuario
                                                                      INNER JOIN cargo ON usuario.Idcargo = cargo.idcargo
                                                                     WHERE
                                                                      id_cronograma ='".$ev["id_cronograma"]."' ;");
                                                        $evp=$query_pb->fetch_array();
                                                        $query_ac=$db->query("SELECT * FROM actividad WHERE id_actividad='".$ev["id_actividad"]."';");
                                                        $evac=$query_ac->fetch_array();
                                                        $query_pbp=$db->query("SELECT * FROM poblacion WHERE idpoblacion='".$ev["idpoblacion"]."';");
                                                        $evpp=$query_pbp->fetch_array();
                                    
                                    if($cont==$row_cnt)
                                            {
                                    if($sum==$row_cnt)
                                            {      echo "<div id='mens'> <p  class='ok'>Haga Clic <a href='crono.php' class=''>aqui<img src='images/check.png' width='32' height='32'></a>y continuar programando, las actividades del Proximo mes. </p></div>";
                                             }else{if($_SESSION['coord']<>0){
                                                 echo "<div id='mens'><p  class='ko'><img src='images/check1.png' width='32' height='32'></a>pongase en contacto con su coordinador para poder continuar programando las actividades.</p></div>";
                                                 }else{
                                                 echo "<div id='mens'><p  class='ko'>Haga Clic<a href='#' class='av'>aqui<img src='images/check1.png' width='32' height='32'></a>para Dar VoBo a estas actividades y 	continuar programando sus actividades.</p></div>";}
                                            }	 }
                                            if($num==0){$num=1;   ?>
                                                  <tr>
                                                  <td><?php  echo $ev["fecha"]; ?></td>
                                                    <td><?php  echo "(".$ev["hora_i"]."-".$ev["hora_f"].")"; ?></td>
                                                    <td><?php echo utf8_encode($comnuni); ?></td>
                                                    <td><?php echo $evpp["nombre"]; ?></td>
                                                    <td><?php echo utf8_decode($evac["nombre_act"]); ?></td>
                                                    <td><?php echo $evp["nombre"]; ?></td>
                                                    <td><?php echo $ev["nombre_u"]; ?></td>
                                                    <td ><label class="toggle" id="<?php echo $ev["id_cronograma"]; ?>" oper="realizada" > 
                                                    <input  <?php if($ev['realizada']==1){ echo "checked ";} ?> class="<?php echo $ev["id_cronograma"]; ?>" type="checkbox"> 
                                                    <span  data-unchecked="No" data-checked="Ok"> </span>
                                                    </label></td>
                                                 </tr>
                                                <?php   }else{$num=0;?> 
                                                 <tr class="alt" bgcolor="#3dc">
                                                 <td><?php echo $ev["fecha"]; ?></td>
                                                 <td><?php echo "(".$ev["hora_i"]."-".$ev["hora_f"].")"; ?></td>
                                                <td><?php echo utf8_encode($comnuni); ?></td>
                                                <td><?php echo $evpp["nombre"]; ?></td>
                                                <td><?php echo utf8_encode($evac["nombre_act"]); ?></td>
                                                <td><?php echo $evp["nombre"]; ?></td>
                                                <td><?php echo $ev["nombre_u"]; ?></td>
                                                    <td ><label class="toggle" id="<?php echo $ev["id_cronograma"]; ?>" oper="realizada"  > <input <?php if($ev['realizada']==1){ echo "checked ";} ?> class="<?php echo $ev["id_cronograma"]; ?>" type="checkbox"> <span  data-unchecked="No" data-checked="Ok"> </span></label></td>
                                                 </tr>
                                            <?php }
                                            }while($ev=$query_e->fetch_array());}
                                    echo '</tbody></table> </div>'; 
             ?>
                       </div>   
         <!-- FIN LISTA DE CHEQUEO --> 