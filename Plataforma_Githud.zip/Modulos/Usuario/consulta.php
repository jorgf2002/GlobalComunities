<?php
   require_once("../../conexion.class.php"); 

 
//consulta todos los empleados
$sql=mysql_query("SELECT * FROM usuario where idcoordinacion='0'",$con);
?>
 <script language="JavaScript" type="text/javascript" src="./Modulos/RegUsuario/ajax_usuario.js"></script>


<table style="color:#f3f3f3;width:auto;">
	<tr style="background:#f08603;">
		<td>Cedula</td>
        <td style='width:120px;'>Nombre</td>
        <td>Usuario</td>
         <td>Perfil</td>
		<td>Operador</td>
        <td></td>
		
        <td>
        
</td>

	</tr> 
    
<?php
  while($row = mysql_fetch_array($sql)){
	  $sql2=mysql_query("SELECT * FROM operador where id_operador='".$row['5']."'",$con);
	   $sql3=mysql_query("SELECT * FROM cargo where idcargo='".$row['6']."' ",$con);
    echo "<tr>";
  	echo "<td>".utf8_encode($row['1'])."</td>";
  	echo "<td >".$row['2']."</td>";
  	echo "<td>".utf8_encode($row['3'])."</td>";
	while($row2 = mysql_fetch_array($sql3)){echo "<td style='width:auto;'>".utf8_encode($row2[1])."</td>";}
    while($row1 = mysql_fetch_array($sql2)){echo "<td style='width:200px;'>".$row1[2]."( ".utf8_encode($row1[1]).")</td>";}
	echo "<td>boton</td>"; 
  	echo "</tr>";
  }
?>

</table>

</form>
