<?php require_once("../../config.php"); 
	@session_start();

?>

		<!--	<link href="../../css/calendar.min.css" rel="stylesheet">
		
				<script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>	-->
       <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
		<script src="../../js/jquery.validate.min.js"></script>
		<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/localization/messages_es.js "></script>
        <script src="http://jqueryvalidation.org/files/dist/additional-methods.min.js"></script>
        <link rel="stylesheet" type="text/css" href="../../css/bootstrap.min.css">
	
			<script language="javascript" type="text/javascript">
					$(document).ready(function(){
						$('#res').hide(); var txt1,txt2;
						$(".datos").validate();
						$("#ced").focusout(
							function(e) {txt1=$(this).val();busqueda1();					        
					    				});
					    $("#us").focusout(
							function(e) { txt2=$(this).val();busqueda1();					        
					    });
						jQuery.validator.addMethod("valida",
												function (value, element)
													{ if ($(element).find(":selected").val() == 0) {
																return false; 
														 }
														else return true;
													 },
												 "Campo Requerido."
										);
					   	function busqueda1(){
												$.ajax({
													type: 'POST',
													url: '../admon/Usuarios/usuarios_op.php',
													data:'ced=' + txt1+'&usua=' + txt2+'&accion=encontro',
													success: function(data){
													if(data!=""){	
														$('#gua').hide(1500);						
														$('#res').show(1500);
														setTimeout(function(){$('#res').hide(1500); },3000);
														}else{$('#gua').show(1000);}}
															
													});
													}	
					});

			
		
		</script>

    
		<div id="">
		<?php
		switch (@$_GET["accion"])
		{
			case "insertar":
				?>
			<h1>Crear usuario</h1><?php
				if (isset($_POST) && count($_POST)>0)
				{	/////////////////////////////////////
	 $cedula=$_POST["cedu"];
	 $nombre=$_POST["nomb"];
	 $usuario=$_POST["usuario"];
	 $contra=$_POST["password"];
	 $operador=$_POST['oper'];
	 $cargo=$_POST['carg'];
			$query_eventos=$db->query("INSERT INTO usuario (cedula,nombre_u,usuario,password,id_operador,idcargo,estado,idcoordinacion) VALUES ('".$cedula."','".$nombre."','".$usuario."', '".$contra."', '".$operador."','".$cargo."',0,'".$_SESSION['usua']."')");
			
				if ($query_eventos){ echo "<p class='ok'>El evento se ha guardado correctamente.</p>";
										//$_SESSION['fec']=$_POST["fecha"];
									}else{ echo "<p class='ko'>Se ha producido un error guardando el evento.</p>";}
				}
				if (!isset($_POST["evento"]))
				{
					?>
				
 <div >
					<form action="" method="post" class="datos">
                        <fieldset>
	<h2>Registro de Usuarios</h2>
     <div id="res" ><p >Esta Cedula o Usuario, aparece registrado, Esta Registrado.</p>
     </div>
		  <table  >
            <tr >
              <td align="right">Cedula:</td>
              <td align="left"><input id="ced" name="cedu" type="text" class="required" value="" /></td>
            </tr>
            <tr>
              <td align="right">Nombre:</td>
              <td align="left"><input name="nomb" type="text" value="" class="required"  /></td>
            </tr>
            <tr>
               	<td align="right">Usuario:</td>
               	<td align="left"><input id="us" name="usuario" type="text" class="required" value="" /></td>
       	    </tr>
            <tr>
				<td align="right">Contraseña:</td>
				<td align="left"><label align="left"><input name="password" type="password" class="required" value=""></label></td>
		    </tr>
            <tr>
              <td align="right">Operadaor:</td>
              <td align="left"> <select name='oper' class="valida" style="width:'50px'" id='operador'>
                                      <option value="0">Seleccione un Operador:</option>
                                      <?php 	$query_eventos=$db->query("SELECT * FROM operador ORDER BY nombre_op ASC");
										while ($eventos=$query_eventos->fetch_array())
 											{ echo "<option value='".$eventos[0]."'>".utf8_encode($eventos[1])."</option>"; 
											 }
									?>
              </select></td>
            </tr>
            <tr>
                
                <td align="right">Perfil:</td>
                <td align="left"><select id='cargo' class="valida" name='carg' style="width:'50px'">
                                      <option value="0">Seleccione un Cargo: </option>
                                      <?php 	$query_eventos=$db->query("SELECT * FROM cargo where perfil=2 order by nombre asc ");
										while ($eventos=$query_eventos->fetch_array())
 											{ 
												 echo "<option value='".$eventos[0]."'>".utf8_encode($eventos[1])."</option>"; 
											 }
									?>
                                  </select></td>
                   
		    </tr>
            <tr>
               	<td>&nbsp;</td>
               	<td align="left"><input id="gua" class="waves-effect waves-light btn" style="width:120px;" type='submit' value='Guardar Usuario'></td>
            </tr>
          </table></fieldset>
  </form>
                    </div>				
			<?php
				}
			break;
			
			case "edicion":
						?>
                <h1>Editar un Actividad </h1>
				<?php
				
				if (isset($_POST) && count($_POST)>0)
				{
					$query_eventos=$db->query("UPDATE usuario SET cedula='".$_POST["cedu"]."',nombre_u='".$_POST["nomb"]."',usuario='".$_POST["usua"]."',password='".$_POST["pass"]."',id_operador='".$_POST['oper']."',Idcargo='".$_POST['carg']."'  WHERE  id_usuario ='".$_GET["idusuario"]."'");
					if ($query_eventos) echo "<p class='ok'>El evento se ha modificado correctamente.</p>";
					else echo "<p class='ko'>Se ha producido un error modificando el evento.</p>";
				}
							if (isset($_GET["idusuario"]) && !isset($_POST["idusuario"]))
				{
					$query_eventos=$db->query("SELECT * FROM usuario  where idcoordinacion<>'0' and id_usuario='".$_GET["idusuario"]."' limit 1");
					if ($evento=$query_eventos->fetch_array())
					{
					?>
                   
                    <div id="content" align="center">
					<form action="" method="post" class="datos">
	<h2>Registro de Usuarios</h2>
		  <table>
            <tr>
              <td align="right">Cedula:</td>
              <td align="left"><input id="ced" name="cedu" type="text" class="required" value="<?php echo $evento["cedula"];?>"  /></td>
            </tr>
            <tr>
              <td align="right">Nombre:</td>
              <td align="left"><input name="nomb" type="text" value="<?php echo $evento['nombre_u']?>" class="required"  /></td>
            </tr>
            <tr>
               	<td align="right">Usuario:</td>
               	<td align="left"><input id="us" name="usua" type="text" class="required" value="<?php echo $evento["usuario"];?>" /></td>
       	    </tr>
            <tr>
				<td align="right">Contraseña:</td>
				<td><label align="left"><input name="pass" type="password" class="required" value="<?php echo $evento["password"];?>"></label></td>
		    </tr>
            <tr>
              <td align="right">Operadaor:</td>
              <td> <select name='oper' style="width:'80px'" id='operador'>
                                      <option value="0">Seleccione una Poblacion</option>
                                      <?php 	$query_eventos=$db->query("SELECT * FROM operador ORDER BY nombre_op ASC");
										while ($eventos=$query_eventos->fetch_array())
 											{ if($eventos[0]==$evento["id_operador"])
											{ echo "<option selected value='".$eventos[0]."'>".utf8_encode($eventos[1])."</option>"; 
											}echo "<option value='".$eventos[0]."'>".utf8_encode($eventos[1])."</option>"; 
											 }
									?>
              </select></td>
            </tr>
            <tr>
                
                <td>Perfil:</td>
                <td><select id='cargo' name='carg' style="width:'80px'">
                                      <option value="0">Seleccione una Cargo</option>
                                      <?php echo $evento['6'];	$query_eventos=$db->query("SELECT * FROM cargo where perfil=2 order by nombre asc ");
										while ($eventos=$query_eventos->fetch_array())
 											{  if($eventos[0]==$evento['6'])
											{ echo "<option selected value='".$eventos[0]."'>".utf8_encode($eventos[1])."</option>"; 
											}
												 echo "<option value='".$eventos[0]."'>".utf8_encode($eventos[1])."</option>"; 
											 }
									?>
                                  </select></td>
                   
		    </tr>
            <tr>
               	<td>&nbsp;</td><td align="left"><input id="gua" style="width:120px;" type='submit' value='Modificar Usuario'></td>
            </tr>
          </table>
  </form>
                    </div>
					<?php
					}
				}
			break;
			
			case "eliminar":
							?><h1>Eliminar un Actividad</h1><?php
							
				
				if (isset($_POST) && count($_POST)>0)
				{
				
					$query_eventos=$db->query("UPDATE usuario SET estado=1 WHERE  id_usuario ='".$_GET["idusuario"]."'");
					if ($query_eventos) echo "<p class='ok'>El usuario se ha eliminado correctamente.</p>";
					else echo "<p class='ko'>Se ha producido un error eliminando  el usuario.</p>";
				}
							if (isset($_GET["idusuario"]) && !isset($_POST["idusuario"]))
				{
					$query_eventos=$db->query("SELECT * FROM usuario  where idcoordinacion<>'0' and id_usuario='".$_GET["idusuario"]."' limit 1");
					if ($evento=$query_eventos->fetch_array())
					{
					?>
                   
                    <div  id="content" align="center">
							<form action="" method="post" class="datos">
	<h2>Registro de Usuarios</h2>
		  <table>
            <tr>
              <td align="right">Cedula:</td>
              <td align="left"><input id="ced" name="cedu" type="text" class="" value="<?php echo $evento["cedula"];?>"  /></td>
            </tr>
            <tr>
              <td align="right">Nombre:</td>
              <td align="left"><input name="nomb" type="text" value="<?php echo $evento['nombre_u']?>" class="required"  /></td>
            </tr>
            <tr>
               	<td align="right">Usuario:</td>
               	<td align="left"><input id="us" name="usua" type="text" class="" value="<?php echo $evento["usuario"];?>" /></td>
       	    </tr>
            <tr>
				<td align="right">Contraseña:</td>
				<td><label align="left"><input name="pass" type="password" class="" value="<?php echo $evento["password"];?>"></label></td>
		    </tr>
            <tr>
              <td align="right">Operadaor:</td>
              <td> <select name='oper' style="width:'80px'" id='operador'>
                                      <option value="0">Seleccione una Poblacion</option>
                                      <?php 	$query_eventos=$db->query("SELECT * FROM operador ");
										while ($eventos=$query_eventos->fetch_array())
 											{ if($eventos[0]==$evento["id_operador"])
											{ echo "<option selected value='".$eventos[0]."'>".utf8_encode($eventos[1])."</option>"; 
											}echo "<option value='".$eventos[0]."'>".utf8_encode($eventos[1])."</option>"; 
											 }
									?>
              </select></td>
            </tr>
            <tr>
                
                <td>Perfil:</td>
                <td><select id='cargo' name='carg' style="width:'80px'">
                                      <option value="0">Seleccione una Poblacion</option>
                                      <?php 	$query_eventos=$db->query("SELECT * FROM cargo ");
										while ($eventos=$query_eventos->fetch_array())
 											{  if($eventos[0]==$evento["Idcargo"]){
												{ echo "<option selected value='".$eventos[0]."'>".utf8_encode($eventos[1])."</option>"; 
												} echo "<option value='".$eventos[0]."'>".utf8_encode($eventos[1])."</option>"; 
											 }}
									?>
                                  </select></td>
                   
		    </tr>
            <tr>
               	<td>&nbsp;</td><td align="left"><input id="gua" style="width:120px;" type='submit' value='Eliminar Usuario'></td>
            </tr>
          </table>
  </form>
                    </div>
					<?php
					}
				}
			break;
		
		}
		?>
    
		</div>


  
	