<?php
   require_once("../../conexion.class.php"); 

 
//consulta todos los empleados
$sql=mysql_query("SELECT * FROM municipio",$con);
?>
<table style="color:#f3f3f3;width:auto;">
	<tr style="background:#f08603;">
		<td>sele</td>
        <td style='width:120px;'>Nombre</td>
        <td>editar</td>
        <td>elimar</td>
	</tr> 
    
<?php
  while($row = mysql_fetch_array($sql)){
    echo "<tr>";
	  	echo "<td><a href='#'><img src='./Modulos/imagenes/seleccion.png' width='22' height='22' /></a></td>"; 
  	echo "<td >".utf8_encode($row['1'])."</td>";
  	  	echo "<td><a href='#'><img src='./Modulos/imagenes/editar.png' width='22' height='22' /></a></td>"; 
	  	echo "<td><a href='#'><img src='./Modulos/imagenes/elimina.png' width='22' height='22' /></a></td>"; 
  	echo "</tr>";
  }
?>

</table>