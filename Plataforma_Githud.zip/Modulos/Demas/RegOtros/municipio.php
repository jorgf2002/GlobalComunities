 <?php header('Content-Type: text/html; charset=utf-8');
 require_once("../../config.php"); 
 $query_eventos=$db->query("SELECT * FROM municipio where activo='".$_POST["elegido"]."0'");
	while ($eventos=$query_eventos->fetch_array())
 		{  echo utf8_encode("<option value='".$eventos[0]."'>".$eventos[1]."</option>"); } 
												
 
 ?>
