<?php
  require_once("../../conexion.class.php"); 
  
  $cedula=$_POST['cedula'];
  $nombre=$_POST['nombre'];
  $usuario=$_POST['usuario'];
  $contra=$_POST['contra'];
  $cargo=$_POST['cargo'];
  $operador=$_POST['operador'];

//registra los datos del empleados
  $sql="INSERT INTO usuario (cedula,nombre_u,usuario,password,id_operador,idcargo,estado) VALUES ('$cedula','$nombre','$usuario', '$contra', '$operador','$cargo','0')";
mysql_query($sql,$con) or die('Error. '.mysql_error());
 
include('consulta.php');
?>