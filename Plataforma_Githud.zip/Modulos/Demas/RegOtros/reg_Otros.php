<?php
    require_once("../../conexion.class.php"); 
?>
<html>
<meta charset="utf-8" />
  <head>
  <title>Registro de Persona</title>
   <script language="JavaScript" type="text/javascript" src="./Modulos/RegOtros/ajax_otros.js"></script>
    <script>
		$(document).ready(function()
		{			elegido=0;
			$.post("./Modulos/RegOtros/municipio.php", { elegido: elegido }, function(data){
            $("#municipio").html(data); });         
			
			
			
			
			
			function recoje(){
								$('#uno').hide();
								$('#dos').hide();
								$('#tres').hide();
								$('#cuatro').hide();
							}
			
			recoje();
		$('#op1').click(function(){
			$('#uno').show(250);
			$('#dos').hide();$('#tres').hide();$('#cuatro').hide();
								});
		$('#op2').click(function(){
			$('#dos').show(250);
			$('#uno').hide();$('#tres').hide();$('#cuatro').hide();
								});
		$('#op3').click(function(){
			$('#tres').show(250);
			$('#dos').hide();$('#uno').hide();$('#cuatro').hide();
								});
		$('#op4').click(function(){
			$('#cuatro').show(250);
			$('#dos').hide();$('#tres').hide();$('#uno').hide();
								});
		});
		</script>
 	<script language="javascript">
			/*function fAgrega()
			/	{
					document.getElementById("usuario1").value = document.getElementById("cedula").value;
			// onKeyUp="fAgrega();"
					}*/
</script>
  </head>
  <body>
  <h1>Administrador</h1>
  <!-- Inicio Operadores -->
  <a id="op1" href="#"><h2>Operadores</h2></a>
  <div id="uno">
		  <div id="frm" class="cuadro">
  <form name="nuevo_empleado" action="" onSubmit="enviarDatosEmpleado(); return false">
	
		  <table>
            <tr>
              <td align="right">Nombre:</td>
              <td><input id="operador" name="operador" type="text" class="input" /></td>
              <td><input type="submit" name="Submit" value="Agregar" /></td>
            </tr>
          </table>
  </form>
 </div>
		<div id="resultado" class="tabla">
					<?php include('consulta_operadores.php');?>
        </div>
        </div>
  <!-- Fin Operadores -->
   <!-- Inicio municipio -->
    <a id="op2" href="#"><h2>Municipio</h2></a>
  <div id="dos">
  		<div id="frm" class="cuadro">
 		 <form name="nuevo_empleado" action="" onSubmit="enviarDatosEmpleado(); return false">
			<h2>Municipio</h2>
		  		<table>
           			 <tr>
              			<td align="right">Nombre:</td>
              			<td><input id="operador" name="operador" type="text" class="input" /></td>
             			<td><input type="submit" name="Submit" value="Agregar" /></td>
            			</tr>
          		</table>
  		</form>
 </div>
		<div id="resultado" class="tabla">
				<?php include('consulta_municipio.php');?>
        </div>
        </div>
  <!-- Fin Municipio -->
   <!-- Inicio Comunidad -->
    <a id="op3" href="#"><h2>Comunidad</h2></a>
  <div id="tres">
		  <div id="frm" class="cuadro">
    <form name="nuevo_empleado" action="" onSubmit="enviarDatosEmpleado(); return false">
	  <h2>Comunidad</h2>
  		   <table>
   			    <tr>
   			      <td colspan="2" align="right">Seleccione Municipio Correspondiente</td>
   			      <td><select id="municipio" name="municipio">
                        </select>
   	         </td>
		     </tr>
   			    <tr>
       			   <td align="right">Nombre:</td>
       			   <td><input id="operador" name="operador" type="text" class="input" /></td>
       			   <td><input type="submit" name="Submit" value="Agregar" /></td>
       			   </tr>
   		   </table>
	  </form>
 </div>
		<div id="resultado" class="tabla">
				<?php include('consulta_comunidad.php');?>
        </div>
        </div>
  <!-- Fin Comunidad -->
     <!-- Inicio perfiles -->
      <a id="op4" href="#"><h2>Perfiles</h2></a>
  <div id="cuatro">
		  <div id="frm" class="cuadro">
    <form name="nuevo_empleado" action="" onSubmit="enviarDatosEmpleado(); return false">
	  <h2>Perfiles:</h2>
  		   <table>
   		    <tr>
       			 <td align="right">Nombre:</td>
       			 <td><input id="operador" name="operador" type="text" class="input" /></td>
       			 <td><input type="submit" name="Submit" value="Agregar" /></td>
       			 </tr>
   		   </table>
	  </form>
 </div>
		<div id="resultado" class="tabla">
				<?php include('consulta_perfiles.php');?>
        </div>
        </div>
  <!-- Fin perfiles -->
 
 
 
 
    </body>
</html>