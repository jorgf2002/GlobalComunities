<?php require_once("../../config.php"); 
@session_start();
?>
<!DOCTYPE html>
<html>
<meta charset="UTF-8">
	<head>
		<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
		<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
		<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/localization/messages_es.js "></script>
		<link href='http://fonts.googleapis.com/css?family=Ubuntu:300,400,500,700' rel='stylesheet' type='text/css'>
		<link href="css/calendar.min.css" rel="stylesheet">
	</head>
	<body>
    
		<div class="formulario">
		<?php

		$_GET["accion"]="insertar";
		switch ($_GET["accion"])
		{
			case "insertar":
				?>
			<h1>Crear usuario el <?php echo "fff"; ?></h1><?php
				if (isset($_POST) && count($_POST)>0)
				{
					$query_eventos=$db->query("insert into cronograma (id_comunidad,fecha,hora_i,hora_f,
id_actividad,id_operador,descripcion,id_estado,activo,id_anterior,id_usuario,idpoblacion) values ('".$_POST["comunidad"]."','".$_POST["fecha"]."','".$_POST["hora_i"]."','".$_POST["hora_f"]."','".$_POST["actividad"]."','".$_SESSION['opera']."','".$_POST["evento"]."',0,0,0,'".$_SESSION['usua']."','".$_POST["poblacion"]."')");
					if ($query_eventos){ echo "<p class='ok'>El evento se ha guardado correctamente.</p>";
					$_SESSION['fec']=$_POST["fecha"];
					}else{ echo "<p class='ko'>Se ha producido un error guardando el evento.</p>";}
				}
				if (!isset($_POST["evento"]))
				{
					?>
				
<form action="" method="post" class="datos">
						<fieldset>
							<div align="center">
							
							  <table width="402" border="0"  cellspacing="8px">
							    <tr>
							      <td width="222"><label>Municipio:</label>
                                    <select id='municipio' name='municipio' >
                                      <option value='0'>Seleccione una municipio </option>
                                      <?php 	$query_eventos=$db->query("SELECT * FROM municipio ");
												while ($eventos=$query_eventos->fetch_array())
 												{ echo "<option value='".$eventos[0]."'>".$eventos[1]."</option>";} 
										?>
                                  </select></td>
							      <td width="164"><label for="select">Comunidad</label>
                                    <select name="comunidad" id="comunidad"  style="width:120px">
                                  </select></td>
						        </tr>
							    <tr>
							      <td>Hora Inicial:
						          <input id="hora_i" name="hora_i" type="time" class="required" value="" size="10" /></td>
							      <td>Hora Final
                                  <input id="hora_f" name="hora_f" type="time" class="required"  size="10" /></td>
						        </tr>
							    <tr>
							      <td><label>Tipo Actividad:</label>
                                    <select id='actividad' name='actividad'>
                                      <option value='0'>Seleccione una Actividad </option>
                                      <?php 	$query_eventos=$db->query("SELECT * FROM actividad ");
										while ($eventos=$query_eventos->fetch_array())
 											{ 
												 echo "<option value='".$eventos[0]."'>".$eventos[1]."</option>"; 
											 }
									?>
                                  </select></td>
							      <td><label>Poblacion Objeto:</label>
                                    <select id='poblacion' name='poblacion'>
                                      <option value="0">Seleccione una Poblacion</option>
                                      <?php 	$query_eventos=$db->query("SELECT * FROM poblacion ");
										while ($eventos=$query_eventos->fetch_array())
 											{ 
												 echo "<option value='".$eventos[0]."'>".$eventos[1]."</option>"; 
											 }
									?>
                                  </select></td>
						        </tr>
							    <tr>
							      <td colspan="2"><label>Descripcion de Actividad: 
							        <textarea name="evento" cols="60" rows="4" class="required"></textarea>
							      </label></td>
						        </tr>
						      </table>
							 
          					  </div>
                            
                            
<div></div>          
				<div>
					<input type="hidden" name="fecha" value="<?php  ?>">
                    <?php if(!empty($_SESSION['login_user']))
{ ?>
<input type="submit" value="Guardar Actividad">
<?php
} ?>
					
				</div>
					</fieldset>
					</form>
					<?php
				}
			break;
			
			case "edicion":
						?>
                <h1>Editar un Actividad </h1>
				<?php
				
				if (isset($_POST) && count($_POST)>0)
				{
					$query_eventos=$db->query("UPDATE  cronograma SET hora_i ='".$_POST["hora_i"]."',hora_f ='".$_POST["hora_f"]."',id_actividad = '".$_POST["actividad"]."',descripcion='".$_POST["evento"]."',id_comunidad='".$_POST["comunidad2"]."',idpoblacion='".$_POST["poblacion"]."' WHERE  cronograma.id_cronograma ='".intval($_POST["idevento"])."'");
					if ($query_eventos) echo "<p class='ok'>El evento se ha modificado correctamente.</p>";
					else echo "<p class='ko'>Se ha producido un error modificando el evento.</p>";
				}
							if (isset($_GET["idevento"]) && !isset($_POST["idevento"]))
				{
					$query_eventos=$db->query("select * from cronograma where id_cronograma='".intval($_GET["idevento"])."' limit 1");
					if ($evento=$query_eventos->fetch_array())
					{
					?>
                   
                    <div align="center">
					<form action="" method="post" class="datos">
						<fieldset>
						 	<div> 
						 	<table width="326" border="0" cellspacing="8px">
						 	  <tr>
						 	    <td width="186"><label>Municipio:</label>
                                  <select id='municipio' name='municipio' >
                                    <option value='0'>Seleccione una municipio </option>
                                    <?php 	$query_e=$db->query("SELECT municipio FROM municipio INNER JOIN comunidad ON municipio.id_municipio = comunidad.id_municipio WHERE id_comunidad ='".$evento['id_comunidad']."'");
											$e=$query_e->fetch_array();
											
											$query_e1=$db->query("SELECT * FROM municipio");
											
											while ($e1=$query_e1->fetch_array())
												{		if($e1[1]==$e[0]){echo utf8_encode("<option selected value='".$e1[0]."'>".$e1[1]."</option>");
														 }
														 echo utf8_encode("<option value='".$e1[0]."'>".$e1[1]."</option>");
												}
													 
										?>
                                </select></td>
						 	    <td width="185"><label>
                                  <?php 						 
									$query_eventos=$db->query("SELECT * FROM comunidad where id_comunidad='".$evento['id_comunidad']."'");
										while ($eventos=$query_eventos->fetch_array())
										{ ?> <input id='comunidad2' name='comunidad2' style="visibility:hidden" type'text' readonly value=' <?php echo $eventos[0]; ?>' >
                                  <?php }
								?>
                                </label>
						 	      <label for="select" >Comunidad</label>
						 	      <input id='comunidad3' name='comunidad3' type'text' readonly value=' <?php echo utf8_encode($eventos[1]); ?>' />
<select name="comunidad" id="comunidad"  style="width:25px" onChange="getdata();">
</select></td>
					 	      </tr>
						 	  <tr>
						 	    <td>Hora Inicial:
                                <input name="hora_i" type="time" class="required" value="<?php echo $evento["hora_i"]; ?>" size="10" /></td>
						 	    <td>Hora Final
                                <input name="hora_f" type="time" class="required" value="<?php echo $evento["hora_f"]; ?>" size="10" /></td>
					 	      </tr>
						 	  <tr>
						 	    <td><label>Tipo Actividad:</label>
                                  <select name='actividad' >
                                    <?php 						 
									$query_eventos=$db->query("SELECT * FROM actividad");
										while ($eventos=$query_eventos->fetch_array())
										{ if ($evento["id_actividad"]==$eventos[0])
											{	echo "<option selected value='".$eventos[0]."'>".$eventos[1]."</option>"; 
											 } else{ echo "<option value='".$eventos[0]."'>".$eventos[1]."</option>"; }
									     }
												
 
 								?>
                                  </select></td>
						 	    <td><label>Poblacion Objeto:</label>
                                  <select id='poblacion' name='poblacion'>
                                    <option value='0'>Seleccione una Poblacion </option>
                                    <?php 	$query_eventos=$db->query("SELECT * FROM poblacion ");
										while ($eventos=$query_eventos->fetch_array())
 											{  if ($evento["idpoblacion"]==$eventos[0])
													{
												 echo "<option selected value='".$eventos[0]."'>".$eventos[1]."</option>"; 
													}else{ echo "<option  value='".$eventos[0]."'>".$eventos[1]."</option>"; }
											 }
									?>
                                </select></td>
					 	      </tr>
						 	  <tr>
						 	    <td colspan="2"><label>Descripcion de Actividad:
						 	      <textarea name="evento" cols="60" rows="4"  class="required"><?php echo $evento["descripcion"]; ?></textarea>
					 	        </label></td>
					 	      </tr>
						 	 
					 	  </table>
						 	<div/>
       		              <div></div>
       		              <div></div>   
 								 <div>
								<input type="hidden" name="idevento" value="<?php echo $evento["id_cronograma"]; ?>">
								<?php
										if(!empty($_SESSION['usua']))
										{	if($result = $db->query("SELECT id_usuario FROM cronograma where id_cronograma='".intval($_GET["idevento"])."' and id_usuario='".$_SESSION['usua']."'"))
											{ $row_cnt = $result->num_rows;
												if($row_cnt>0){
														echo "<input type='submit' value='Modificar Evento'>";
													}else{
														echo "<p class='ko'>Usted No Tiene Permiso para Modificar Pongase en Contacto con el Usuario para Coordinar Su Actividad.</p>";
														}}
											}else{
											echo "<p class='ko'>Usted es Invitado no Tiene Permiso para Modiicar.</p>";
											}
								?>
							</div>
  </fieldset>
</form>
                    </div>
					<?php
					}
				}
			break;
			
			case "eliminar":
							?><h1>Eliminar un Actividad</h1><?php
				if (isset($_POST) && count($_POST)>0)
				{
					$query_eventos=$db->query("UPDATE  cronograma.cronograma SET  id_estado ='1' where id_cronograma='".intval($_POST["idevento"])."'");
					if ($query_eventos) echo "<p class='ok'>El evento se ha eliminado correctamente.</p>";
					else echo "<p class='ko'>Se ha producido un error eliminando el evento.</p>";
				}
				if (isset($_GET["idevento"]) && !isset($_POST["idevento"]))
				{
					$query_eventos=$db->query("select * from cronograma where id_cronograma='".intval($_GET["idevento"])."' limit 1");
					if ($evento=$query_eventos->fetch_array())
					{
					?>
					<form action="" method="post" class="datos">
						<fieldset>
							<div> 						     		    
							   <?php 						 
									$query_eventos=$db->query("SELECT comunidad FROM comunidad where id_comunidad='".$evento['id_comunidad']."'");
										while ($eventos=$query_eventos->fetch_array())
										{ echo " Comunidad: <strong>".$eventos[0];}
								?> </strong>
                                </label>  
                            <div/>
                		            <div>   
						  					  
							  Hora Inicial:
							    <input name="hora_i" type="time" readonly class="required" value="<?php echo $evento["hora_i"]; ?>" size="10">
							  Hora Final
							    <input name="hora_f" type="time" readonly class="required" value="<?php echo $evento["hora_f"]; ?>" size="10">
                                
							        </div>   
							    <label>Tipo Actividad:</label>
  							     <?php 						 
									$query_eventos=$db->query("SELECT * FROM actividad");
										while ($eventos=$query_eventos->fetch_array())
										{ if ($evento["id_actividad"]==$eventos[0])
											{	echo " <label><strong>".$eventos[1]."</strong></option>"; 
											 }
									     }
												
 
 								?></select>
					      <div><br />
 								 <label>Descripcion de Actividad:
  								  <textarea name="evento" cols="80" rows="6" readonly   class="required"><?php echo $evento["descripcion"]; ?></textarea>
 								 </label>
  								</div>   
						<input type="hidden" name="idevento" value="<?php echo $evento["id_cronograma"]; ?>">
								<?php
										if(!empty($_SESSION['usua']))
										{	if($result = $db->query("SELECT id_usuario FROM cronograma where id_cronograma='".intval($_GET["idevento"])."' and id_usuario='".$_SESSION['usua']."'"))
											{ $row_cnt = $result->num_rows;
												if($row_cnt>0){
														echo "<input type='submit' value='Eliminar Evento'>";
													}else{
														echo "<br /><p class='ko'>Usted No Tiene Permiso para Eliminar Pongase en Contacto con el Usuario para Coordinar Su Actividad.</p>";
														}}
											}else{
											echo "<p class='ko'>Usted es Invitado no Tiene Permiso para Eliminar.</p>";
											}
								?> 
							</div>
						</fieldset>
					</form>
					<?php
					}
				}
			break;
		
		}
		?>
    
		</div>


     <script type="text/javascript">   

function restarHoras() {

  inicio = document.getElementById("hora_i").value;
  fin = document.getElementById("hora_f").value;
  inicioMinutos = parseInt(inicio.substr(3,2));
  inicioHoras = parseInt(inicio.substr(0,2));
  finMinutos = parseInt(fin.substr(3,2));
  finHoras = parseInt(fin.substr(0,2));
 transcurridoMinutos = finMinutos - inicioMinutos;
  transcurridoHoras = finHoras - inicioHoras;
  if (transcurridoMinutos < 0) {
    transcurridoHoras--;
    transcurridoMinutos = 60 + transcurridoMinutos;
  }
  
  horas = transcurridoHoras.toString();
  minutos = transcurridoMinutos.toString();
  
  if (horas.length < 2) {
    horas = "0"+horas;
  }
  
  if (horas.length < 2) {
    horas = "0"+horas;
  }
  
  document.getElementById("dura").value = horas+":"+minutos;

}


function getdata() {
document.getElementById('comunidad2').value = document.getElementById('comunidad').value;

 var combo = document.getElementById("comunidad"); 
		document.getElementById('comunidad3').value  = combo.options[combo.selectedIndex].text; 


}
function val()
{
		
	
	}
</script>

		<script>
		$(document).ready(function()
		{		
	
		 $("#municipio").change(function () {
           				$("#municipio option:selected").each(function () {
           					 elegido=$(this).val();
							  comu=$('#comunidad2').val();
			$.post("comunidad.php", { elegido: elegido ,comu:comu}, function(data){
            $("#comunidad").html(data);
            });            
        });
		
		
		
   })
			
			$("form.datos").validate();
		});
		</script>
	</body>
</html>