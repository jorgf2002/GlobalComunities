<?
   require_once("../../conexion.class.php"); 
if(isset($_POST['ced']))
{	$sql="SELECT *FROM usuario where ced='".$_POST['ced']."'";
		if($resultado=mysql_query($sql))
		{	echo"<h1>existe este valor</h1>";	}
}
