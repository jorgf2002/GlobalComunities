<?php
    require_once("../../conexion.class.php"); 
$sqlq=mysql_query("SELECT * FROM operador where activo=0",$con);
$sqlr=mysql_query("SELECT * FROM cargo where activo=0",$con);
?>
<html>
<meta charset="utf-8" />
  <head>
  <title>Registro de empleados</title>

  <script language="javascript" type="text/javascript">
$(document).ready(function(){
	$("#cedula").focusout(function(e) {busqueda1($(this).val());
        
    });
					function busqueda1(txt1){
						$.ajax({
								type: 'POST',
								url: 'Modulos/RegUsuario/consul_usuarios.php',
								data:'ced=' + txt1,
								success: function(data){
									alert(repetido);
								
										}
								});
								}
});
</script>
 	<script language="javascript">
function fAgrega()
{
document.getElementById("usuario1").value = document.getElementById("cedula").value;
}
</script>
  </head>
  <body>
  <div id="frm">
  <form name="nuevo_empleado" action="" onSubmit="enviarDatosEmpleado(); return false">
	<h2>Registro de Usuarios</h2>
		  <table>
            <tr>
              <td align="right">Cedula:</td>
              <td><input id="cedula" name="cedula" type="text" class="input" onKeyUp="fAgrega();" /></td>
            </tr>
            <tr>
              <td align="right">Nombre:</td>
              <td><input name="nombre" type="text" onKeyUp="this.value = this.value.toUpperCase();" class="input" /></td>
            </tr>
            <tr>
               	<td align="right">Usuario:</td>
               	<td><input id="usuario1" name="usuario1" type="text" class="input" /></td>
       	    </tr>
            <tr>
				<td align="right">Contraseña:</td>
				<td><label><input name="contra" type="password" class="input"></label></td>
		    </tr>
            <tr>
              <td align="right">Operadaor:</td>
              <td><select name="operador" >
                <?	while($fila=mysql_fetch_array($sqlq)){
						echo "<option value='".$fila[0]."'>".$fila[2]."( ".utf8_encode($fila[1]).")</option>";
									}
					?>
              </select></td>
            </tr>
            <tr>
                
                <td>Perfil:</td>
                <td><select name="cargo" >
                  <?	while($fila=mysql_fetch_array($sqlr)){
						echo "<option value='".$fila[0]."'>".utf8_encode($fila[1])."</option>";
									}
					?>
                </select></td>
                   
		    </tr>
            <tr>
               	<td>&nbsp;</td><td><label><input type="submit" name="Submit" value="Grabar" /></label></td>
            </tr>
          </table>
  </form>
 </div>
 <div id="mens" >dfsdfs</div>
		<div id="resultado"><?php include('consulta.php');?></div>
 
    </body>
</html>