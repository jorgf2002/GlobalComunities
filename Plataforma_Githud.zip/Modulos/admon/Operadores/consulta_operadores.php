   
<table style="width:auto; alignment-adjust:central">
                    <tr >
                     <th style='width:120px;'>Nombre de Operador</th>
                        <th>Editar</th>
                        <th>Elimar</th>
                    </tr> 
                     <?php 
				require_once("../conexion/conexion.php");
					//consulta todos los operadores
					$sql=mysql_query("SELECT * FROM operador where activo=0",$con);
                  while($row = mysql_fetch_array($sql)){ ?>
              
                    <tr>
                    <td ><?php echo $row['1'];?></td>
                    <td><a id='edi' href='#' ided='<?php echo $row['0'];?>'>
                    <img src='../configuracion/img/editar.png' width='22' height='22' /></a></td> 
                    <td><a id='eli' href='#' idel='<?php echo $row['0'];?>'>
                    <img src='../configuracion/img/elimina.png' width='22' height='22' /></a></td> 
                    </tr>
                <?php  } ?>
                 </table>