<?php
 session_start();
   require_once("../conexion/conexion.php"); 
 switch ($_POST['accion'])
		{
			case "insertar":
			{ /*
			Para grabar datos:
<? $variable=utf8_encode($_POST['variable']); ?>

Para mostrar datos
<? echo utf8_decode($registro['campo']); ?>*/
			$nombre = utf8_encode($_POST['nombre']);
			$sigla = utf8_encode($_POST['sigla']);
			$telefono = utf8_encode($_POST['telefono']);
			$direccion = utf8_encode($_POST['direccion']);
			$email = utf8_encode($_POST['email']);
			$res = mysql_query("INSERT INTO operador (nombre_op,sigla,telefono,direccion,email) VALUES ('".$nombre."','".$sigla."','".$telefono."','".$direccion."','".$email."')");
		if(mysql_affected_rows()>0)
			{	echo "1";}else{	echo "2";}
			}
 			break;
			case "editar":
			{ 
			$nombre = $_POST['nombre'];
			$sigla = utf8_encode($_POST['sigla']);
			$telefono = utf8_encode($_POST['telefono']);
			$direccion = utf8_encode($_POST['direccion']);
			$email = utf8_encode($_POST['email']);
			$ide=$_POST['ide'];
			$res = mysql_query("UPDATE  operador SET nombre_op='".$nombre."',sigla='".$sigla."',telefono='".$telefono."',direccion='".$direccion."',email='".$email."' WHERE id_operador ='$ide'");
		if(mysql_affected_rows()>0)
			{	echo "1";}else{	echo "2";}
			}
 			break;
			
			case "eliminar":
			{ 
	
			$ide=$_POST['ide'];
			$res = mysql_query("delete from operador WHERE id_operador ='$ide'");
		if(mysql_affected_rows()>0)
			{	echo "1";}else{	echo "2";}
			}
 			break;
			
			case "busca":
			{
				$ide=$_POST['ide'];
				$sql="SELECT  * FROM  operador WHERE id_operador ='$ide'";
				$qc=mysql_query($sql,$con);
				$fil=mysql_fetch_array($qc);
				$jsondata = array();
				$i = 0;
							$jsondata['c0'] = $fil[0];  
							$jsondata['c1'] = $fil[1];   
							$jsondata['c2'] = $fil[2];    
							$jsondata['c3'] = $fil[3];   
							$jsondata['c4'] = $fil[4];  
							$jsondata['c5'] = $fil[5];   
							$jsondata['c6'] = $fil[6];   
				echo json_encode($jsondata);
			}
 			break;
 		}
?>