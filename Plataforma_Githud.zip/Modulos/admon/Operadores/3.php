	<?php @session_start(); 
         if((@$_SESSION['opera'])==2 or (@$_SESSION['opera'])==1)  {  ?>
<html>
	<head>
  <meta charset="utf-8"> 
       <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
    <link rel="stylesheet" type="text/css" href="../configuracion/css/jquery-ui.css"> 
		<script src="../configuracion/js/jquery-1.7.min.js"></script>
        <script src="../configuracion/js/funciones.operador.js"></script>
        <script src="../configuracion/js/jquery-ui.min.1.10.3.js"></script>
		<link type="text/css" rel="stylesheet" href="../configuracion/css/materialize.min.css" media="screen,projection"/>
 		<link type="text/css" rel="stylesheet" href="../configuracion/css/custom.css" />
		<script type="text/javascript" src="../configuracion/js/materialize.min.js"></script>

 </head>
 
 <body>
 
 

	
<div align="center" style="margin-top:30px;"> 
		<div id="b1"  class="waves-effect waves-light btn"><img src='../configuracion/img/seleccion.png' width='21' height='21' />Crear-Operador</div>
</div>
<div id="dialogo" class="ventana" title="Operadores">

	
   <table id="forma" width="400px">
	  <tr>
	    <td><label>Nombre del Operador: <br>
	    </label>
	      <input name="nom_op" type="text" id="nom_op"/></td>
	    <td><label>Sigla: </label>
	      <input name="sigla" type="text" id="sigla" size="15"/></td>
      </tr>
		<form>
			<tr>
			  <td width="auto"><label>Telefono: <br>
			    </label>
              <input name="telefono" type="text" id="telefono"/></td>
			  <td width="auto"><label>Direccion: <br>
			    </label>
              <input name="direccion" type="text" id="direccion" size="35"/></td>
		  </tr>
			<tr>
			  <td colspan="2"><label>Email:  
			    </label>
              <input name="email" type="text" id="email" size="35"/></td>
		  </tr>
			<tr>
				<td colspan="2" align="center">
                <div id="botones">
                
                </div>
                
                </td>
			</tr>
		</form>
	</table>
 
	<span id="res" ></span>
  
</div>
    <span>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
			<div id="content">
            <?php
			//header('Content-Type: text/html; charset=ISO-8859-1');
			require_once("consulta_operadores.php");
                ?>
			</div>
    </span>
 
</body> <?php } ?>