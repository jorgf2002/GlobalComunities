<?php	@session_start(); 
         if((@$_SESSION['opera'])==2 or (@$_SESSION['opera'])==1)  {  ?>
         <html>
	<head>
    <meta charset="utf-8"> 
       <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
    <link rel="stylesheet" type="text/css" href="../configuracion/css/jquery-ui.css"> 
		<script src="../configuracion/js/jquery-1.7.min.js"></script>
        <script src="../configuracion/js/funciones.municipio.js"></script>
        <script src="../configuracion/js/jquery-ui.min.1.10.3.js"></script>
		<link type="text/css" rel="stylesheet" href="../configuracion/css/materialize.min.css" media="screen,projection"/>
 		<link type="text/css" rel="stylesheet" href="../configuracion/css/custom.css" />
		<script type="text/javascript" src="../configuracion/js/materialize.min.js"></script>

 </head>
 
 <body>
 
 

	
<div align="center" style="margin-top:30px;"> 
		<div id="b1" class="waves-effect waves-light btn"><img src='../configuracion/img/seleccion.png' width='21' height='21' />Crear-Municipio</div>
</div>
<div id="dialogo" class="ventana" title="Dialogo Modal">

	
   <table id="forma" width="400px">
	  <tr>
	    <td><label>Nombre del Operador: <br>
	    </label>
	      <input name="nom_op" type="text" id="nom_op"/></td>
	   
      </tr>
	
			<tr>
				<td colspan="2" align="center">
                
                <div id="botones">
                <a  id="boton" class="btn-floating btn-large waves-effect waves-light red"><i class="mdi-content-archive"></i></a>
				<a  id="edita" class="btn-floating btn-large waves-effect waves-light red"><i class="mdi-content-add"></i></a>
                </div>
                
                
                </td>
			</tr>
		</form>
	</table>
 
	<span id="res" ></span>
  
</div>
    <span>
	
			<div id="content">
            <?php
			require_once("consulta_municipio.php");
                ?>
			</div>
    </span>
 
</body> <?php
			}
                ?>