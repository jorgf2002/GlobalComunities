<?php require_once("../../../config.php"); 
  
	if (mysqli_connect_errno()) {
    	printf("La conexión con el servidor de base de datos falló: %s\n", mysqli_connect_error());
    	exit();
	}
	
	$consulta = "
SELECT
	id_cronograma,
  cronograma.fecha  AS fecha,
  Concat(cronograma.hora_i, ' - ', cronograma.hora_f) AS hora,
  (select concat(municipio,'-',(IF(casco=1,'Casco Urbano','Centro Poblado'))) from municipio where municipio.id_municipio=lugar)as Lugar,
  cronograma.id_comunidad,
  (select nombre_act from actividad where actividad.id_actividad=cronograma.id_actividad)as acti,
  (select nombre from poblacion where poblacion.idpoblacion= cronograma.idpoblacion)as poblacio,
  cronograma.descripcion, if (cronograma.id_estado=1 and cronograma.activo=1 and cronograma.id_anterior=1,'Eliminada','Activa') as estado,
  if(cronograma.realizada=1,'Realizada','No Realizada')as realizada,
    if(cronograma.aval=1,'VoBo','Sin VoBo')as Visto,
  (select nombre_u from usuario    where usuario.id_usuario=cronograma.id_usuario)as encargado,
  (select operador.nombre_op from operador inner join usuario on usuario.id_operador=operador.id_operador  where usuario.id_usuario=cronograma.id_usuario)as operador,
  (select cargo.nombre from cargo inner join usuario on cargo.idcargo=usuario.Idcargo where usuario.id_usuario=cronograma.id_usuario )as cargo,
  (select telefono from usuario inner join operador on usuario.id_operador=operador.id_operador   where usuario.id_usuario=cronograma.id_usuario)as telefono
  
FROM
  cronograma";
  
	$resultado = $conexion->query($consulta);
	
	if($resultado->num_rows > 0 ){			
	
		date_default_timezone_set('America/Mexico_City');
		if (PHP_SAPI == 'cli')
			die('Este archivo solo se puede ver desde un navegador web');
		/** Se agrega la libreria PHPExcel */
		require_once '../../lib/PHPExcel/PHPExcel.php';
		// Se crea el objeto PHPExcel
		$objPHPExcel = new PHPExcel();
		// Se asignan las propiedades del libro
		$objPHPExcel->getProperties()->setCreator("Ing Jorge L Romero") //Autor
							 ->setLastModifiedBy("Ing Jorge L Romero") //Ultimo usuario que lo modificó
							 ->setTitle("Reporte Excel Actividades.")
							 ->setSubject("Reporte Excel actividades.")
							 ->setDescription("Reporte de actividades.")
							 ->setKeywords("cronograma actividades")
							 ->setCategory("Reporte excel");
		$tituloReporte = "Reporte General de Actividades";
		$titulosColumnas =array('FECHA','HORA','LUGAR','COMUNIDAD','ACTIVIDAD','POBLACION','DESCRIPCION','ESTADO','REALIZADA','VISTO','USUARIO','CARGO','OPERADOR','TELEFONO');
		$objPHPExcel->setActiveSheetIndex(0)
        		    ->mergeCells('D1:O1');
		// Se agregan los titulos del reporte
		$objPHPExcel->setActiveSheetIndex(0)
					->setCellValue('A1',$tituloReporte)
        		    ->setCellValue('A3',$titulosColumnas[0])
		            ->setCellValue('B3',$titulosColumnas[1])
        		    ->setCellValue('C3', $titulosColumnas[2])
            		->setCellValue('D3', $titulosColumnas[3])
					->setCellValue('E3', $titulosColumnas[4])
					->setCellValue('F3', $titulosColumnas[5])
					->setCellValue('G3', $titulosColumnas[6])
					->setCellValue('H3', $titulosColumnas[7])
					/*->setCellValue('I3', $titulosColumnas[7])
					->setCellValue('J3', $titulosColumnas[7])
					->setCellValue('K3', $titulosColumnas[7])
					->setCellValue('L3', $titulosColumnas[7])
					->setCellValue('M3', $titulosColumnas[7])
					->setCellValue('N3', $titulosColumnas[7])
					->setCellValue('O3', $titulosColumnas[7])*/
					->setCellValue('I3', $titulosColumnas[8])
					->setCellValue('J3', $titulosColumnas[9])
					->setCellValue('K3', $titulosColumnas[10])
					->setCellValue('L3', $titulosColumnas[11])
					->setCellValue('M3', $titulosColumnas[12])
					->setCellValue('N3', $titulosColumnas[13]);
					//->setCellValue('O3', $titulosColumnas[14]);
		//Se agregan los datos de los alumnos
		$i = 4;			
  	while ($fila = $resultado->fetch_array()) {
	/**************************************************************/	  
					 $cnt=0;$comnuni="";	
                     $piezas = explode(",", $fila['id_comunidad']);
					while (count($piezas)>$cnt)
					{   $sql=$db->query("SELECT comunidad, municipio,id_comunidad FROM municipio 
										INNER JOIN comunidad ON municipio.id_municipio=comunidad.id_municipio 
										WHERE id_comunidad='".$piezas[$cnt]."'");
							
									
									$comn=$sql->fetch_array();
									$comnuni=$comn[1].' - '.$comn[0].','.$comnuni;
									$cnt=$cnt+1;

					}	 $comnuni = trim($comnuni, '- ,'); //echo utf8_encode($comnuni); 
	/**************************************************************/
	$objPHPExcel->setActiveSheetIndex(0)
        		    ->setCellValue('A'.$i, $fila['fecha'])
		            ->setCellValue('B'.$i, $fila['hora'])
					->setCellValue('C'.$i, $fila['Lugar'])
					->setCellValue('D'.$i, utf8_encode($comnuni))
        	   		->setCellValue('E'.$i, utf8_encode($fila['acti']))
					->setCellValue('F'.$i, utf8_encode($fila['poblacio']))
					->setCellValue('G'.$i, $fila['descripcion'])	
					->setCellValue('H'.$i, $fila['estado'])
					->setCellValue('I'.$i, $fila['realizada'])
					->setCellValue('J'.$i, $fila['Visto'])
					->setCellValue('K'.$i, utf8_encode($fila['encargado']))
					->setCellValue('L'.$i, utf8_encode($fila['cargo']))		
					->setCellValue('M'.$i, utf8_encode($fila['operador']))
					->setCellValue('N'.$i, $fila['telefono']);
					/*->setCellValue('I'.$i, $fila['telefono'])
					->setCellValue('J'.$i, $fila['telefono'])
					->setCellValue('K'.$i, $fila['telefono'])
					->setCellValue('L'.$i, $fila['telefono'])
					->setCellValue('M'.$i, $fila['telefono'])
					->setCellValue('N'.$i, $fila['telefono'])
					->setCellValue('O'.$i, $fila['telefono'])*/
					$i++;
		}
		$estiloTituloReporte = array(
        	'font' => array(
	        	'name'      => 'Verdana',
    	        'bold'      => true,
        	    'italic'    => false,
                'strike'    => false,
               	'size' =>16,
	            	'color'     => array(
    	            	'rgb' => 'F3F3F3'
        	       	)
            ),
	        'fill' => array(
				'type'	=> PHPExcel_Style_Fill::FILL_SOLID,
				'color'	=> array('rgb' => 'FF8800')
			),
            'borders' => array(
               	'allborders' => array(
                	'style' => PHPExcel_Style_Border::BORDER_NONE                    
               	)
            ), 
            'alignment' =>  array(
        			'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
        			'vertical'   => PHPExcel_Style_Alignment::VERTICAL_CENTER,
        			'rotation'   => 0,
        			'wrap'          => TRUE
    		)
        );

		$estiloTituloColumnas = array(
            'font' => array(
                'name' => 'Arial',
                'bold' => true,                          
                'color'=> array(
                  'rgb'=> 'F3F3F3'
                )
            ),
            'fill' 	=> array(
				'type'		=> PHPExcel_Style_Fill::FILL_GRADIENT_LINEAR,
				'rotation'   => 90,
        		'startcolor' => array(
            		'rgb' => '00948b'
        		),
        		'endcolor'   => array(
            		'rgb' => '00948b'
        		)
			),
            'borders' => array(
            	'top'     => array(
                    'style' => PHPExcel_Style_Border::BORDER_MEDIUM ,
                    'color' => array(
                        'rgb' => '143860'
                    )
                ),
                'bottom'     => array(
                    'style' => PHPExcel_Style_Border::BORDER_MEDIUM ,
                    'color' => array(
                        'rgb' => '143860'
                    )
                )
            ),
			'alignment' =>  array(
        			'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
        			'vertical'   => PHPExcel_Style_Alignment::VERTICAL_CENTER,
        			'wrap'          => TRUE
    		));
			
		$estiloInformacion = new PHPExcel_Style();
		$estiloInformacion->applyFromArray(
			array(
           		'font' => array(
               	'name'      => 'Arial',               
               	'color'     => array(
                   	'rgb' => '000000'
               	)
           	),
           	'fill' 	=> array(
				'type'		=> PHPExcel_Style_Fill::FILL_SOLID,
				'color'		=> array('rgb' => 'd1cc9b')
			),
           	'borders' => array(
               	'left'     => array(
                   	'style' => PHPExcel_Style_Border::BORDER_THIN ,
	                'color' => array(
    	            	'rgb' => '3a2a47'
                   	)
               	)             
           	)
        ));
		$objPHPExcel->getActiveSheet()->getStyle('A1:D1')->applyFromArray($estiloTituloReporte);
		$objPHPExcel->getActiveSheet()->getStyle('A3:O3')->applyFromArray($estiloTituloColumnas);		
		$objPHPExcel->getActiveSheet()->setSharedStyle($estiloInformacion, "A4:O".($i-1));
				
		for($i = 'A'; $i <= 'O'; $i++){
			$objPHPExcel->setActiveSheetIndex(0)			
				->getColumnDimension($i)->setAutoSize(TRUE);
		}
		
		// Se asigna el nombre a la hoja
		$objPHPExcel->getActiveSheet()->setTitle('Actividades');

		// Se activa la hoja para que sea la que se muestre cuando el archivo se abre
		$objPHPExcel->setActiveSheetIndex(0);
		// Inmovilizar paneles 
		//$objPHPExcel->getActiveSheet(0)->freezePane('A4');
		$objPHPExcel->getActiveSheet(0)->freezePaneByColumnAndRow(0,4);

		// Se manda el archivo al navegador web, con el nombre que se indica (Excel2007)
		header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
		header('Content-Disposition: attachment;filename="ReportedeActividades.xlsx"');
		header('Cache-Control: max-age=0');

		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
		$objWriter->save('php://output');
		exit;
		
	}
	else{
		print_r('No hay resultados para mostrar');
	}
?>