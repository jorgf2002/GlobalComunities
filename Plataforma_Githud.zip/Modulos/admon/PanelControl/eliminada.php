                              
                                <h2>Activiadades eliminadas. </h2>
                                <h2>Espacios Liberados, en las Comunidades</h2>
                      <?php
                       requiere_once('../../../config.php');
                        @$fecha=$_GET['fecha'];
                        
                        $query_e=$db->query("SELECT
                                              cronograma.id_cronograma,
                                              cronograma.id_comunidad,
                                              cronograma.fecha,
                                              cronograma.id_estado,
                                              cronograma.activo,
                                              cronograma.id_anterior,
                                              cronograma.hora_i,
                                              cronograma.hora_f,
                                              cronograma.id_actividad,
                                              cronograma.id_operador,
                                              cronograma.descripcion,
                                              cronograma.aval,
                                              cronograma.casco,
                                              cronograma.realizada,
                                              cronograma.lugar,
                                              cronograma.idpoblacion,
                                              cronograma.id_usuario,
                                              usuario.nombre_u
                                            FROM
                                              cronograma
                                              INNER JOIN usuario ON cronograma.id_usuario = usuario.id_usuario
                                            WHERE
                                              (cronograma.id_estado = 1)and
                                              (cronograma.activo = 1) and
                                              (cronograma.id_anterior = 1) and  MONTH(cronograma.fecha) >MONTH(date_sub(curdate(), interval 2 month)) and MONTH(cronograma.fecha)> MONTH(now())
                                            ORDER BY
                                              cronograma.fecha;  ");
                        
                                        echo '<div class="">
										<table class="" cellspacing="0" cellpadding="0">
                                             <thead>
                                              <tr>
                                              <th width="110px" >Fecha</th>
                                                <th width="100px" >Hora</th>
                                                <th >Comunidad</th>
                                                <th >Pob. Objeto</th>
                                                <th >Tipo de Act.</th>
                                                <th >Cargo</th>
                                                <th >Nombre</th>
                                                ';
                                                
                            ?>
                            
                          </tr>
                          </thead>
                        <tbody>
                        <?php $num=0; $sum=0;
                            /**/
                                                    $band=0;
                                                $row_cnt = $query_e->num_rows; 	
                                                    //while($ev=$query_e->num_rows()){ $sum=$ev["aval"]+$sum; }
                                                    $cont=0;
                                        if($ev=$query_e->fetch_array()){
                                        do{ $sum=$ev["aval"]+$sum;//echo $sum; 
                                        $cont++;$cnt=0;$comnuni="";	
                                        ////////////////////////////////////////////////
                                                                            $piezas = explode(",", $ev["id_comunidad"]);
                                                                        while (count($piezas)>$cnt){
                                                                            $sql=$db->query("SELECT comunidad, municipio,id_comunidad FROM municipio INNER JOIN comunidad ON municipio.id_municipio=comunidad.id_municipio where id_comunidad='".$piezas[$cnt]."'");
                                                                                $comn=$sql->fetch_array();
                                                                                        //echo $comn[0]."-".$comn[1];
                                                                                    
                                                                                        if($piezas[$cnt]=='cen'){$comnuni='Centro Poblado'.','.$comnuni;}else{	
                                                                                            if($piezas[$cnt]=='cas'){$comnuni='Casco Urbano'.','.$comnuni;}
                                                                                                    else
                                                                                                     {$comnuni=$comn[0].','.$comnuni;}
                                                                                                                        
                                                                                        }	$cnt=$cnt+1;
                                                                        }
                                                                    
                                                                        $comnuni = trim($comnuni, ','); 
                                        /////////////////////////////////////////////////
                                        $query_pb=$db->query("SELECT
                                                                  cronograma.id_anterior,
                                                                  cargo.nombre,
                                                                  usuario.nombre_u,
                                                                  cronograma.id_cronograma,
                                                                  cronograma.activo
                                                                FROM
                                                                  municipio
                                                                  INNER JOIN comunidad ON comunidad.id_municipio =
                                                                    municipio.id_municipio
                                                                  INNER JOIN cronograma ON comunidad.id_comunidad =
                                                                    cronograma.id_comunidad
                                                                  INNER JOIN usuario ON usuario.id_usuario = cronograma.id_usuario
                                                                  INNER JOIN cargo ON usuario.Idcargo = cargo.idcargo
                                                                WHERE
                                                                  cronograma.id_cronograma ='".$ev["id_cronograma"]."'  ;");
                                                    $evp=$query_pb->fetch_array();
                                                $query_ac=$db->query("select * from actividad where id_actividad='".$ev["id_actividad"]."'");
                                                    $evac=$query_ac->fetch_array();
                                                    $query_pbb=$db->query("select * from poblacion where idpoblacion='".$ev["idpoblacion"]."'");
                                                    $evpb=$query_pbb->fetch_array();
                                
                               
                                        if($num==0){$num=1;   ?>
                                              <tr>
                                              <td><?php  echo $ev["fecha"]; ?></td>
                                                <td><?php echo "(".$ev["hora_i"]."-".$ev["hora_f"].")"; ?></td>
                                                <td><?php echo utf8_encode($comnuni); ?></td>
                                                <td><?php echo $evpb["nombre"]; ?></td>
                                                <td><?php echo utf8_encode($evac["nombre_act"]); ?></td>
                                                <td><?php echo $evp["nombre"]; ?></td>
                                                <td><?php echo $ev["nombre_u"]; ?></td>
                                             </tr>
                                            <?php }else{$num=0;?> 
                                             <tr class="alt" bgcolor="#3dc">
                                             <td><?php echo $ev["fecha"]; ?></td>
                                             <td><?php echo "(".$ev["hora_i"]."-".$ev["hora_f"].")"; ?></td>
                                            <td><?php echo utf8_encode($comnuni); ?></td>
                                            <td><?php echo $evpb["nombre"]; ?></td>
                                            <td><?php echo utf8_encode($evac["nombre_act"]); ?></td>
                                            <td><?php echo $evp["nombre"]; ?></td>
                                            <td><?php echo $ev["nombre_u"]; ?></td>
                                             </tr>
                                        <?php }
                                        }while($ev=$query_e->fetch_array());}
                                echo '</tbody></table> </div>';
                        ?>
                           