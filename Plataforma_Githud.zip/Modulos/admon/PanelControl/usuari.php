           <table cellspacing="0" cellpadding="0">
                            
                            <tr>
                                <th>Cedula</th>
                                <th style='width:120px;'>Nombre</th>
                                <th>Usuario</th>
                                 <th>Perfil</th>
                                <th>Operador</th>
                                <th></th>
                                
                                <th>
                                
                        </th>
                        
                            </tr> 
                            
                        <?php require_once("../../../config.php"); 
                        $query_eventos=$db->query("SELECT * FROM usuario  WHERE idcoordinacion<>0 AND estado=0 AND idcoordinacion='".$_SESSION['usua']."';");
                       while ($row=$query_eventos->fetch_array())
                        {
                              $sql2=$db->query("SELECT * FROM operador WHERE id_operador='".$row['5']."'");
                               $sql3=$db->query("SELECT * FROM cargo WHERE idcargo='".$row['6']."'");
                            echo "<tr>";
                            echo "<td>".utf8_encode($row['1'])."</td>";
                            echo "<td >".$row['2']."</td>";
                            echo "<td>".utf8_encode($row['3'])."</td>";
                            while($row2 = $sql3->fetch_array()){echo "<td style='width:auto;'>".utf8_encode($row2[1])."</td>";}
                            while($row1 = $sql2->fetch_array()){echo "<td style='width:200px;'>".$row1[2]."( ".utf8_encode($row1[1]).")</td>";}
                            echo "<td> <a class='colorbox' title='Editar' href='./Modulos/usuario/usuario.php?accion=edicion&idusuario=".$row['id_usuario']."'><img src='images/026.png' width='22px' height='22px'></a></td>";
                            echo "<td> <a class='colorbox' title='Eliminar' href='./Modulos/usuario/usuario.php?accion=eliminar&idusuario=".$row['id_usuario']."'><img src='images/020.png' width='22px' height='22px'></a></td>";
                            
                            }?>
                            </tr> 
                        </table>
        