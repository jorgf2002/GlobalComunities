<?php
    require_once("../../../config.php");

?><html>
	<head>
    <meta charset="utf-8"> 
       <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
    <link rel="stylesheet" type="text/css" href="../configuracion/css/jquery-ui.css"> 
		<script src="../configuracion/js/jquery-1.7.min.js"></script>
      <script src="../configuracion/js/funciones.perfil.js"></script> <!--  -->
        <script src="../configuracion/js/jquery-ui.min.1.10.3.js"></script>
		<link type="text/css" rel="stylesheet" href="../configuracion/css/materialize.min.css" media="screen,projection"/>
 		<link type="text/css" rel="stylesheet" href="../configuracion/css/custom.css" />
		<script type="text/javascript" src="../configuracion/js/materialize.min.js"></script>

 </head>
 
 <body>
 <?php @session_start();
 ?>

	 <?php if(!empty($_SESSION['login_user'])){
					$ql=$db->query("SELECT  * FROM  usuario WHERE id_usuario ='".$_SESSION['usua']."'");					
					$evento=$ql->fetch_array();					 
					?>   
                    <div id="content">
                     <form >
                              <table >
                                        <tr>
                                          <td align="right">Cedula:</td>
                                          <td><input id="cedula" name="cedula" type="text" value="<?php echo $evento['cedula'];?>"  /></td>
                                        </tr>
                                        <tr>
                                          <td align="right">Nombre:</td>
                                          <td><input name="nombre_u" id="nombre_u" type="text" value="<?php echo $evento['nombre_u'];?>" /></td>
                                        </tr>
                                        <tr>
                                            <td align="right">Usuario:</td>
                                            <td><input id="usuario" name="usuario" type="text" value="<?php echo $evento['usuario'];?>" /></td>
                                        </tr>
                                        <tr>
                                            <td align="right">Contraseña:</td>
                                            <td><label><input name="pass" id="pass" type="password" value="<?php echo $evento['password'];?> "> </label></td>
                                        </tr>
                                       <!-- <tr>
                                          <td align="right">Operadaor:</td>
                                          <td><select name="operador" >
                                            <?	while($fila=mysql_fetch_array($sqlq)){
                                                    echo "<option value='".$fila[0]."'>".$fila[2]."( ".utf8_encode($fila[1]).")</option>";
                                                                }
                                                ?>
                                          </select></td>
                                        </tr>
                                        <tr>
                                            
                                            <td>Perfil:</td>
                                            <td><select name="cargo" >
                                              <?	while($fila=mysql_fetch_array($sqlr)){
                                                    echo "<option value='".$fila[0]."'>".utf8_encode($fila[1])."</option>";
                                                                }
                                                ?>
                                            </select></td>
                                               
                                        </tr> -->
                                        <tr>
                                            <td><div id="botones"><a  id="edita" class="btn-floating btn-large waves-effect waves-light red"><i class="mdi-content-add"></i></a>
                                            </div></td>
                                        </tr>
                                      </table>
 					</form>
 					</div>
	<span id="res" ></span>
  


<?php } ?>
</body>