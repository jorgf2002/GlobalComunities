<?php
 session_start();
   require_once("../conexion/conexion.php"); 
 switch ($_POST['accion'])
		{
			
			case "editar":
			{ 
			$cedula = $_POST['cedula'];
			$nombre_u = $_POST['nombre_u'];
			$usuario = $_POST['usuario'];
			$pass = $_POST['pass'];
			$res = mysql_query("UPDATE  usuario SET cedula='".$cedula."',nombre_u='".$nombre_u."',usuario='".$usuario."',password='".$pass."' WHERE id_usuario ='".$_SESSION['usua']."'");
		if(mysql_affected_rows()>0)
			{	

session_destroy();
echo "1";
}else{	echo "2";}
			}
 			break;
			case "eliminar":
			{ 
				$usuario=$_POST['usuario'];
			$res = mysql_query("select * from usuario WHERE usuario ='".$usuario."'");
		if(mysql_affected_rows()>0)
			{	echo "1";
			}else{	echo "2";}
			}
 			break;
			
			
 		}
?>