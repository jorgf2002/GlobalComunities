	$('document').ready(function(){
	/*	muestra();
				
				
				
				function modal(){ $("#dialogo").dialog({
														width: 590,
														height: 550,
														show: "blind",
														hide: "blind",
														resizable: "true",
														position: "center",
														 modal: "true"  
       								 });
								}
					
				function muestra() {
						modal();
  					ided=$(this).attr('usuar'); 
					msgbox('ided');
					 $.ajax({	type: "POST",
								url: "../../admon/Perfiles/perfil_op.php",
								data: 'ide=' + ided+'&accion=busca', 
								dataType: "json",
								success: function(data) {limpia();
												
												$('#cedula').val(data.c1);
												$('#nombre_u').val(data.c2);
												$('#usuario').val(data.c3);
												$('#pass').val(data.c4);
												
													
											//$( "#botones" ).empty();
										//	
														}
		 									 }); 
			};			
								
				$("#b1").click(function() {  modal(); });
				
		//////boton de guardar
				$('#boton').click(function(){
					if($('#email').val()!=""){
								var nombre = $('#nom_op').val();
						}
						else{
							if (!$('#res').is(':visible'))
							{ $('#res').append("<b class='card-panel blue lighten-4'>Todos los Campos son Obligatorios.</b>");
							}
								$('#res').css('color','red');
							return false;
						
						}
					jQuery.post("../../admon/Perfiles/perfiles_op.php", {
						nombre:nombre,
					
						accion:'insertar'
					}, function(data, textStatus){
						if(data == 1){limpia();
						
							$('#res').append("<b class='card-panel green lighten-4'>Datos insertados.</b>");
							$('#content').load('consulta_perfiles.php');
							
							}else{alert(data);
							$('#res').html("Ha ocurrido un error.");
							$('#res').css('color','red');
						}
					});
				});
		//////BOTON EDITAR
		var ided;
		
			////// 	
					*/
					var bande=0;
			$('#edita').click(function(){
					if($('#usuario').val()!=""){
								var nombre_u = $('#nombre_u').val();
								var cedula = $('#cedula').val();
								var usuario = $('#usuario').val();
								var pass = $('#pass').val();
								}
						else{
							if (!$('#res').is(':visible'))
							{ $('#res').append("<b class='card-panel blue lighten-4'>Todos los Campos son Obligatorios.</b>");
							}else{}
								$('#res').css('color','red');
							return false;
						
						}
						$('#res').append("<b class='card-panel green lighten-4'>Datos Modificados.</b>");
							var r = confirm("Al modificar algun dato. Se cerrara sesion.");
					if (r == true) {
						if(bande==0){
							jQuery.post("../../admon/Perfil/perfil_op.php", {
										nombre_u:nombre_u,
										cedula:cedula,
										usuario:usuario,
										pass:pass,
										accion:'editar'
										
									}, function(data, textStatus){
										if(data == 1){limpia();
											$('#res').append("<b class='card-panel green lighten-4'>Datos Modificados.</b>");
									window.location.reload(true);
											}else{
											$('#res').html("Ha ocurrido un error.");
											$('#res').css('color','red');
										}
					}); 
						}else{alert('El Usuario ya existe. Por favor intente cambiarlo.');}}/* else {
  							alert( "Recuerde que los cambios se efectuaran despues de Iniciar nuevamente!");
									}*/
									
				});
				function limpia(){			$('#cedula').val("");
											$('#nombre_u').val("");
											$('#usuario').val("");
											$('#pass').val("");
								}
								
								
								
				$('#usuario').change(function(){
  					usuario=$('#usuario').val(); 					
					 $.ajax({	type: "POST",
								url: "../../admon/Perfil/perfil_op.php",
								data: 'usuario=' + usuario+'&accion=eliminar', 
								success: function(data) { 
												if(data == 1)
												{ bande=1;alert("Este Usuario ya existe¡");//$('#content').load('consulta_perfiles.php');
												 }else{bande=0; alert("Usuario Disponible.");}
														}
		 									 }); 
			});				
			//////elimina
			/*	$( "#eli" ).live( "click", function() {
  					idel=$(this).attr('idel'); 					
					 $.ajax({	type: "POST",
								url: "../../admon/Perfiles/perfiles_op.php",
								data: 'ide=' + idel+'&accion=eliminar', 
								success: function(data) { 
												if(data == 1)
												{ $('#content').load('consulta_perfiles.php');
												 }else{ alert("Ocurrio un Error¡");}
														}
		 									 }); 
			});*/
			////////////
			
 

			
			
			
			
			});///este es el del final