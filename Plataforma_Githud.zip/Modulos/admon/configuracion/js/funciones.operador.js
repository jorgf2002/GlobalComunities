	$('document').ready(function(){
				/// 
			/*	$("#b1").click(function() { <!-- ------> al pulsar (.click) el boton 1 (#b1) -->
        $("#dialogo").dialog({ <!--  ------> muestra la ventana  -->
            width: 590,  <!-- -------------> ancho de la ventana -->
            height: 350,<!--  -------------> altura de la ventana -->
			
            show: "scale", <!-- -----------> animación de la ventana al aparecer -->
            hide: "scale", <!-- -----------> animación al cerrar la ventana -->
            resizable: "false", <!-- ------> fija o redimensionable si ponemos este valor a "true" -->
            position: "center",<!--  ------> posicion de la ventana en la pantalla (left, top, right...) -->
            modal: "true" <!-- ------------> si esta en true bloquea el contenido de la web mientras la ventana esta activa (muy elegante) -->
        });
    }); 
				*/
				
				function modal(){ $("#dialogo").dialog({
														width: 590,
														height: 550,
														show: "blind",
														hide: "blind",
														resizable: "true",
														position: "center",
														 modal: "true"  
       								 });
								}
				function limpia(){
												$('#nom_op').val("");
												$('#sigla').val("");
												$('#telefono').val("");
												$('#direccion').val("");
												$('#email').val("");
					}				
								
				$("#b1").click(function() {
					$( "#botones" ).empty();
					$('#botones').append('<a  id="boton" class="btn-floating btn-large waves-effect waves-light red"><i class="mdi-content-archive"></i></a>');
					
                
                
       modal();
    });
				
		//////boton de guardar
				$('#boton').click(function(){
					if($('#email').val()!=""){
								var nombre = $('#nom_op').val();
							var sigla = $('#sigla').val();
							var telefono = $('#telefono').val();
							var direccion = $('#direccion').val();
							var email = $('#email').val();
							
						}
						else{
							if (!$('#res').is(':visible'))
							{ $('#res').append("<b class='card-panel blue lighten-4'>Todos los Campos son Obligatorios.</b>");
							}else{alert("sdsds");}
								$('#res').css('color','red');
							return false;
						
						}
					jQuery.post("../../admon/Operadores/2.php", {
						nombre:nombre,
						sigla:sigla,
						telefono:telefono,
						direccion:direccion,
						email:email,
						accion:'insertar'
					}, function(data, textStatus){
						if(data == 1){limpia();
						
							$('#res').append("<b class='card-panel green lighten-4'>Datos insertados.</b>");
							$('#content').load('consulta_operadores.php');
							
							}else{alert(data);
							$('#res').html("Ha ocurrido un error.");
							$('#res').css('color','red');
						}
					});
				});
		//////BOTON EDITAR
		var ided;
		$( "#edi" ).live( "click", function() {
						modal();
  					ided=$(this).attr('ided'); 
					
					 $.ajax({	type: "POST",
								url: "../../admon/Operadores/2.php",
								data: 'ide=' + ided+'&accion=busca', 
								dataType: "json",
								success: function(data) {alert(data); limpia();
												$('#nom_op').val(data.c1);
												$('#sigla').val(data.c2);
												$('#telefono').val(data.c3);
												$('#direccion').val(data.c4);
												$('#email').val(data.c5);
													
											$( "#botones" ).empty();
											$('#botones').append('<a  id="edita" class="btn-floating btn-large waves-effect waves-light red"><i class="mdi-content-add"></i></a>');
														}
		 									 }); 
			});
			//////
			
			$('#edita').click(function(){alert("cvqaqaqaq");
					if($('#email').val()!=""){
								var nombre = $('#nom_op').val();
							var sigla = $('#sigla').val();
							var telefono = $('#telefono').val();
							var direccion = $('#direccion').val();
							var email = $('#email').val();
						}
						else{
							if (!$('#res').is(':visible'))
							{ $('#res').append("<b class='card-panel blue lighten-4'>Todos los Campos son Obligatorios.</b>");
							}else{alert("sdsds");}
								$('#res').css('color','red');
							return false;
						
						}
					jQuery.post("../../admon/Operadores/2.php", {
						nombre:nombre,
						sigla:sigla,
						telefono:telefono,
						direccion:direccion,
						email:email,
						accion:'editar',
						ide:ided
					}, function(data, textStatus){
						if(data == 1){limpia();$('#content').load('consulta_operadores.php');
							$('#res').append("<b class='card-panel green lighten-4'>Datos Modificados.</b>");
							
							}else{alert(data);
							$('#res').html("Ha ocurrido un error.");
							$('#res').css('color','red');
						}
					}); 
				});
			//////elimina
				$( "#eli" ).live( "click", function() {
  					idel=$(this).attr('idel'); 					
					 $.ajax({	type: "POST",
								url: "../../admon/Operadores/2.php",
								data: 'ide=' + idel+'&accion=eliminar', 
								success: function(data) { 
												if(data == 1)
												{ $('#content').load('consulta_operadores.php');
												 }else{ alert("Ocurrio un Error¡");}
														}
		 									 }); 
			});
			////////////
			
 

			
			
			
			
			});///este es el del final