	$('document').ready(function(){
				
				function modal(){ $("#dialogo").dialog({
														width: 590,
														height: 550,
														show: "blind",
														hide: "blind",
														resizable: "true",
														position: "center",
														 modal: "true"  
       								 });
								}
				function limpia(){
												$('#ced').val("");
												$('#nomb').val("");
												$('#us').val("");
												$('#password').val("");
												$('#email').val("");
					}				
								
				$("#b1").click(function() {
					
									       modal();
									    });
				$('#boton').click(function(){
					if($('#us').val()!=""){
								
								var cedula = $('#ced').val();
								var nombre = $('#nomb').val();
								var usuar = $('#us').val();
								var pass = $('#password').val();
							
								var operador = $('#operador').val();
								var cargo = $('#cargo').val();
							
						}
						else{
							if (!$('#res').is(':visible'))
							{ $('#res').append("<b class='card-panel blue lighten-4'>Todos los Campos son Obligatorios.</b>");
							}
								$('#res').css('color','red');
							return false;
						
						}
					jQuery.post("../../admon/Usuarios/usuarios_op.php", {
						cedula:cedula,
						nombre:nombre,
						usuar:usuar,
						pass:pass,
						operador:operador,
						cargo:cargo,				
						accion:'insertar'
					}, function(data, textStatus){
						if(data == 1){//limpia();
						
							$('#res').append("<b class='card-panel green lighten-4'>Datos insertados.</b>");
							$('#content').load('consulta_usuarios.php');
							
							}else{
							$('#res').html("Ha ocurrido un error.");
							$('#res').css('color','red');
						}
					});
				});
		//////BOTON EDITAR
				var ided;
				$( "#edi" ).live( "click", function() {
								modal();
		  					ided=$(this).attr('ided'); 
							
							 $.ajax({	type: "POST",
										url: "../../admon/Usuarios/usuarios_op.php",
										data: 'ide=' + ided+'&accion=busca', 
										dataType: "json",
										success: function(data) {
														limpia();
																	$('#ced').val(data.c1);
																	$('#nomb').val(data.c2);
																	$('#us').val(data.c3);
																	$('#password').val(data.c4);
																	$('#operador').val(data.c5);
																	$('#cargo').val(data.c6);
																}
				 									 }); 
									});
	///EDITAR////////////////////////////******************************************************************************************************************************
				$('#edita').click(function(){
						if($('#email').val()!=""){
									var cedula = $('#ced').val();
									var nombre = $('#nomb').val();
									var usuar = $('#us').val();
									var pass = $('#password').val();								
									var operador = $('#operador').val();
									var cargo = $('#cargo').val();
							}
							else{
								if (!$('#res').is(':visible'))
								{ $('#res').append("<b class='card-panel blue lighten-4'>Todos los Campos son Obligatorios.</b>");
								}
									$('#res').css('color','red');
								return false;
							}
						jQuery.post("../../admon/Usuarios/usuarios_op.php", {
							cedula:cedula,
							nombre:nombre,
							usuar:usuar,
							password:pass,
							operador:operador,
							cargo:cargo,
							accion:'editar',
							ide:ided
						}, function(data, textStatus){
							if(data == 1){limpia();$('#content').load('consulta_usuarios.php');
								$('#res').append("<b class='card-panel green lighten-4'>Datos Modificados.</b>");
								}else{
								$('#res').html("Ha ocurrido un error.");
								$('#res').css('color','red');
							}
						}); 
					});
				//////elimina
					$( "#eli" ).live( "click", function() {
	  					idel=$(this).attr('idel'); 					
						 $.ajax({	type: "POST",
									url: "../../admon/Usuarios/usuarios_op.php",
									data: 'ide=' + idel+'&accion=eliminar', 
									success: function(data) { 
													if(data == 1)
													{ $('#content').load('consulta_usuarios.php');
													 }else{ alert("Ocurrio un Error¡");}
															}
			 									 }); 
				});
				//////////valida
				
				});///este es el del final