<?php
 session_start();
   require_once("../../admon/Operdadores/2.php");
   ?>
