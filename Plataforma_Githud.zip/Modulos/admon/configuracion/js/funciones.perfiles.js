	$('document').ready(function(){
				/// 
			/*	$("#b1").click(function() { <!-- ------> al pulsar (.click) el boton 1 (#b1) -->
        $("#dialogo").dialog({ <!--  ------> muestra la ventana  -->
            width: 590,  <!-- -------------> ancho de la ventana -->
            height: 350,<!--  -------------> altura de la ventana -->
			
            show: "scale", <!-- -----------> animación de la ventana al aparecer -->
            hide: "scale", <!-- -----------> animación al cerrar la ventana -->
            resizable: "false", <!-- ------> fija o redimensionable si ponemos este valor a "true" -->
            position: "center",<!--  ------> posicion de la ventana en la pantalla (left, top, right...) -->
            modal: "true" <!-- ------------> si esta en true bloquea el contenido de la web mientras la ventana esta activa (muy elegante) -->
        });
    }); 
				*/
				
				function modal(){ $("#dialogo").dialog({
														width: 590,
														height: 550,
														show: "blind",
														hide: "blind",
														resizable: "true",
														position: "center",
														 modal: "true"  
       								 });
								}
				function limpia(){
												$('#nom_op').val("");
												$('#sigla').val("");
												$('#telefono').val("");
												$('#direccion').val("");
												$('#email').val("");
					}				
								
				$("#b1").click(function() {
					//$( "#botones" ).empty();
					//$('#botones').append('');
					
                
                
       modal();
    });
				
		//////boton de guardar
				$('#boton').click(function(){
					if($('#email').val()!=""){
								var nombre = $('#nom_op').val();
							
							
						}
						else{
							if (!$('#res').is(':visible'))
							{ $('#res').append("<b class='card-panel blue lighten-4'>Todos los Campos son Obligatorios.</b>");
							}else{alert("sdsds");}
								$('#res').css('color','red');
							return false;
						
						}
					jQuery.post("../../admon/Perfiles/perfiles_op.php", {
						nombre:nombre,
					
						accion:'insertar'
					}, function(data, textStatus){
						if(data == 1){limpia();
						
							$('#res').append("<b class='card-panel green lighten-4'>Datos insertados.</b>");
							$('#content').load('consulta_perfiles.php');
							
							}else{alert(data);
							$('#res').html("Ha ocurrido un error.");
							$('#res').css('color','red');
						}
					});
				});
		//////BOTON EDITAR
		var ided;
		$( "#edi" ).live( "click", function() {
						modal();
  					ided=$(this).attr('ided'); 
					
					 $.ajax({	type: "POST",
								url: "../../admon/Perfiles/perfiles_op.php",
								data: 'ide=' + ided+'&accion=busca', 
								dataType: "json",
								success: function(data) {limpia();
												$('#nom_op').val(data.c1);
												
													
											//$( "#botones" ).empty();
										//	
														}
		 									 }); 
			});
			//////
			
			$('#edita').click(function(){alert("cvqaqaqaq");
					if($('#email').val()!=""){
								var nombre = $('#nom_op').val();
							
						}
						else{
							if (!$('#res').is(':visible'))
							{ $('#res').append("<b class='card-panel blue lighten-4'>Todos los Campos son Obligatorios.</b>");
							}else{alert("sdsds");}
								$('#res').css('color','red');
							return false;
						
						}
					jQuery.post("../../admon/Perfiles/perfiles_op.php", {
						nombre:nombre,
						accion:'editar',
						ide:ided
					}, function(data, textStatus){
						if(data == 1){limpia();$('#content').load('consulta_perfiles.php');
							$('#res').append("<b class='card-panel green lighten-4'>Datos Modificados.</b>");
							
							}else{alert(data);
							$('#res').html("Ha ocurrido un error.");
							$('#res').css('color','red');
						}
					}); 
				});
			//////elimina
				$( "#eli" ).live( "click", function() {
  					idel=$(this).attr('idel'); 					
					 $.ajax({	type: "POST",
								url: "../../admon/Perfiles/perfiles_op.php",
								data: 'ide=' + idel+'&accion=eliminar', 
								success: function(data) { 
												if(data == 1)
												{ $('#content').load('consulta_perfiles.php');
												 }else{ alert("Ocurrio un Error¡");}
														}
		 									 }); 
			});
			////////////
			
 

			
			
			
			
			});///este es el del final