 <!-- ADMINISTRACION DE USUARIOS <script type="text/javascript" src="Modulos/admon/configuracion/js/funciones.usuarios.js"></script>--> 

<script type="text/javascript">
                                 
$(document).ready(function(){ 

  $("#ins_usu").click(function() {
                                                                    var url_ins=$(this).attr('dato1'); 
                                                                  var direc='<iframe class="" style="border:0px; width:450px; height:450px;" src="'+url_ins+'"></iframe>';
                                                                    $('.modal-content').html(direc);  $('#modal122').openModal();
                                                                                      });
                                        
    $("p").on("click", function(){
 var url_ins=$(this).attr('data'); 
                                                                  var direc='<iframe class="modal-content"  marginwidth="0" marginheight="0" scrolling="no" border="0" frameborder="0"   style=" align:center; border:0px; width:750px; height:650px;" src="'+url_ins+'"></iframe>';
                                                                         $('.modal-content').html(direc);   $('#modal122').openModal();
    });
    $(".modal-close").click(function() { 
                                        $(".calendar").load('./Modulos/admon/Usuarios/admin_usuarios.php'); });
});
 

</script>
<div id="modal122" class="modal modal-fixed-footer" style="align-content: center; width: auto;">
    <div id="container" class="modal-content ">
    
    </div>
    <div class="modal-footer">
      <a href="#" id="act_usuario" class="modal-action modal-close waves-effect waves-green btn-flat "><i class="large material-icons right">close</i></a>
    </div>
   
  </div>
                      <div  id="content" align="center">
                            <h5 class="color_azul">Administracion de Usuarios</h5> 
                                     <p class="waves-effect waves-green btn-flat" data="./Modulos/Usuario/usuario.php?accion=insertar">Agregar <img src='images/021.png' width='22px' height='22px'></p>
                          
                              <table >
                            <tr>
                                <th>Cedula</th>
                                <th style='width:auto;'>Nombre</th>
                                <th>Usuario</th>
                                 <th>Perfil</th>
                                <th>Operador</th>
                                <th></th>
                                <th>
                        </th>
                            </tr> 
                        <?php @session_start(); require_once("../../../config.php");
                        $query_eventos=$db->query("SELECT * FROM usuario  WHERE idcoordinacion<>0 AND estado=0 AND idcoordinacion='".$_SESSION['usua']."';");
                       while ($row=$query_eventos->fetch_array())
                        {    $sql2=$db->query("SELECT * FROM operador WHERE id_operador='".$row['5']."'");
                             $sql3=$db->query("SELECT * FROM cargo WHERE idcargo='".$row['6']."'");
                            echo "<tr>";
                            echo "<td>".utf8_encode($row['1'])."</td>";
                            echo "<td >".$row['2']."</td>";
                            echo "<td>".utf8_encode($row['3'])."</td>";
                            while($row2 = $sql3->fetch_array()){echo "<td >".utf8_encode($row2[1])."</td>";}
                            while($row1 = $sql2->fetch_array()){echo "<td >".$row1[2]."( ".utf8_encode($row1[1]).")</td>";}
                              ?>
                            <td> 
                                <p class="waves-effect waves-green btn-flat" data='./Modulos/Usuario/usuario.php?accion=edicion&idusuario=<?php echo $row['id_usuario']; ?>'>Editar <img src='images/026.png' width='22px' height='22px'></p>

                            </td> 
                            <td>
                               <p class="waves-effect waves-green btn-flat" data='./Modulos/Usuario/usuario.php?accion=eliminar&idusuario=<?php echo $row['id_usuario']; ?>'>Eliminar <img src='images/020.png' width='22px' height='22px'></p>


                           </td>

                          
                            </tr> <?php } ?>
                        </table>
                       </div>
                            
         <!-- FIN ADMINISTRACION DE USUARIOS --> 