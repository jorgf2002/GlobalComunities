<?php
 session_start();
   require_once("../conexion/conexion.php"); 
 switch ($_POST['accion'])
		{
			case "insertar":
			{ 				
					 $cedula=$_POST["cedula"];
					 $nombre=$_POST["nombre"];
					 $usuario=$_POST["usuar"];
					 $contra=$_POST["pass"];
					 $operador=$_POST['operador'];
					 $cargo=$_POST['cargo'];
		$res = mysql_query("INSERT INTO usuario (cedula,nombre_u,usuario,password,id_operador,idcargo) VALUES ('".$cedula."','".$nombre."','".$usuario."', '".$contra."', '".$operador."','".$cargo."')");
		if(mysql_affected_rows()>0)
			{	echo "1";}else{	echo "2";}
			}
 			break;
			case "editar":
			{ 			
			
			//$ide=$_POST['ide'];
			$res = mysql_query("UPDATE usuario SET cedula='".$_POST["cedula"]."',nombre_u='".$_POST["nombre"]."',usuario='".$_POST["usuar"]."',password='".$_POST["password"]."',id_operador='".$_POST['operador']."',Idcargo='".$_POST['cargo']."' WHERE  id_usuario ='".$_POST['ide']."'");
		if(mysql_affected_rows()>0)
			{	echo "1";}else{	echo "2";}
			}
 			break;
			case "eliminar":
			{ 
	
			$ide=$_POST['ide'];
			$res = mysql_query("UPDATE usuario SET estado='1'  WHERE  id_usuario ='".$_POST['ide']."'");
		if(mysql_affected_rows()>0)
			{	echo "1";}else{	echo "2";}
			}
 			break;
 			case 'encontro';
								if($_POST['ced']!='undefined')
									{ $sql="SELECT  * FROM  usuario WHERE cedula ='".$_POST['ced']."' and estado=0;";
										$qc=mysql_query($sql,$con);
											if(mysql_fetch_array($qc)>0)
											{echo "1";}else{	echo mysql_fetch_array($qc);}}
								if($_POST["usua"]!='undefined')
									{ $sql="SELECT  * FROM  usuario WHERE usuario ='".$_POST['usua']."'and estado=0;";
										$qc=mysql_query($sql,$con);
											if(mysql_fetch_array($qc)>0)
											{echo "1";}else{	echo mysql_fetch_array($qc);}}
										

								
 			break;
			case "busca":
			{
				$ide=$_POST['ide'];
				$sql="SELECT  * FROM  usuario WHERE id_usuario ='$ide'and estado=0;";
				$qc=mysql_query($sql,$con);
				$fil=mysql_fetch_array($qc);
				$jsondata = array();
				$i = 0;
							$jsondata['c0'] = $fil[0];  
							$jsondata['c1'] = utf8_encode($fil[1]);   
							$jsondata['c2'] = utf8_encode($fil[2]);   
							$jsondata['c3'] = utf8_encode($fil[3]);   
							$jsondata['c4'] = utf8_encode($fil[4]);   
							$jsondata['c5'] = utf8_encode($fil[5]);   
							$jsondata['c6'] = utf8_encode($fil[6]);   
					echo json_encode($jsondata);
			}
 			break;
 		}
?>