 <meta charset="UTF-8">  
<table style="width:auto; alignment-adjust:central">
                    <tr >
                     <th style='width:120px;'>Nombre del Perfiles o Cargo</th>
                        <th>Editar</th>
                        <th>Elimar</th>
                    </tr> 
                     <?php 
				 require_once("../conexion/conexion.php"); 
					//consulta todos los operadores
					$sql=mysql_query("SELECT * FROM cargo where activo=0",$con);
                  while($row = mysql_fetch_array($sql)){ ?>
              
                    <tr>
                    <td ><?php echo utf8_encode($row['1']);?></td>
                    <td><a id='edi' href='#' ided='<?php echo utf8_encode($row['0']);?>'>
                    <img src='../configuracion/img/editar.png' width='22' height='22' /></a></td> 
                    <td><a id='eli' href='#' idel='<?php echo utf8_encode($row['0']);?>'>
                    <img src='../configuracion/img/elimina.png' width='22' height='22' /></a></td> 
                    </tr>
                <?php  } ?>
                 </table>