<?php
 session_start();
   require_once("../conexion/conexion.php"); 
 switch ($_POST['accion'])
		{
			case "insertar":
			{ 
			$nombre = $_POST['nombre'];
			
			$res = mysql_query("INSERT INTO comunidad (comunidad) VALUES ('".$nombre."')");
		if(mysql_affected_rows()>0)
			{	echo "1";}else{	echo "2";}
			}
 			break;
			case "editar":
			{ 
			$nombre = $_POST['nombre'];
			
			$ide=$_POST['ide'];
			$res = mysql_query("UPDATE comunidad SET comunidad='".$nombre."' WHERE id_comunidad ='$ide'");
		if(mysql_affected_rows()>0)
			{	echo "1";}else{	echo "2";}
			}
 			break;
			
			case "eliminar":
			{ 
	
			$ide=$_POST['ide'];
			$res = mysql_query("delete from comunidad WHERE id_comunidad ='$ide'");
		if(mysql_affected_rows()>0)
			{	echo "1";}else{	echo "2";}
			}
 			break;
			
			case "busca":
			{
				$ide=$_POST['ide'];
				$sql="SELECT  * FROM  comunidad WHERE id_comunidad ='$ide'";
				$qc=mysql_query($sql,$con);
				$fil=mysql_fetch_array($qc);
				$jsondata = array();
				$i = 0;
							$jsondata['c0'] = $fil[0];  
							$jsondata['c1'] = utf8_encode($fil[1]);   
							
				echo json_encode($jsondata);
			}
 			break;
 		}
?>