    <?php @session_start(); 
         if((@$_SESSION['opera'])==2 or (@$_SESSION['opera'])==1)  {  ?>

         <html>
	<head>
    <meta charset="utf-8"> 
       <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
    <link rel="stylesheet" type="text/css" href="../configuracion/css/jquery-ui.css"> 
		<script src="../configuracion/js/jquery-1.7.min.js"></script>
        <script src="../configuracion/js/funciones.comunidad.js"></script>
        <script src="../configuracion/js/jquery-ui.min.1.10.3.js"></script>
		<link type="text/css" rel="stylesheet" href="../configuracion/css/materialize.min.css" media="screen,projection"/>
 		<link type="text/css" rel="stylesheet" href="../configuracion/css/custom.css" />
		<script type="text/javascript" src="../configuracion/js/materialize.min.js"></script>

 </head>
 
 <body>
 
 

	
<div align="center" class="fra"  style="margin-top:7px;"> 

<h1>Administrar Valores Predeterminados</h1>
        <a id="admin3s" href='../Usuarios/usuarios.php' target="ventana_iframe" > 
        <div id="b1" style="width:230px;" class="waves-effect waves-light btn"><img src='../configuracion/img/perfiles.png' width='32' height='32' />Usuario</div></a>
        
        <a id="admin3s" href='../Operadores/3.php' target="ventana_iframe" >     
        <div id="b1" style="width:230px;" class="waves-effect waves-light btn"><img src='../configuracion/img/operadores.png' width='32' height='32' />Operadores</div></a>
        
        <a id="admin3s" href='../Municipio/municipio.php' target="ventana_iframe" > 
        <div id="b1" style="width:230px;" class="waves-effect waves-light btn"><img src='../configuracion/img/municipio.png' width='32' height='32' />Municipio</div></a>
        
        <a id="admin3s" href='../Comunidad/comunidad.php' target="ventana_iframe" > 
        <div id="b1" style="width:240px;" class="waves-effect waves-light btn"><img src='../configuracion/img/comunidad.png' width='32' height='32' />Comunidades</div></a>
        
        <a id="admin3s" href='../Perfiles/perfiles.php' target="ventana_iframe" > 
        <div id="b1" style="width:230px;" class="waves-effect waves-light btn"><img src='../configuracion/img/perfiles.png' width='32' height='32' />Perfiles</div></a>

        
      
</div>
 
</body><?php } ?>