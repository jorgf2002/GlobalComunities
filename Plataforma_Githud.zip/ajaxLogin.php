<?php
 require_once("config.php"); 
/*mysql_connect('localhost','root','123456')or die ('Ha fallado la conexión: '.mysql_error());
mysql_select_db('cronograma')or die ('Error al seleccionar la Base de Datos: '.mysql_error());
*/
session_start();
if(isset($_POST['username']) && isset($_POST['password']))
{
// username and password sent from Form
$username=$_POST['username']; 
$password=$_POST['password']; 

$result=mysql_query("SELECT * FROM usuario WHERE usuario='$username' and password='$password' and estado=0");
$count=mysql_num_rows($result);
$row = mysql_fetch_array($result);
// If result matched $myusername and $mypassword, table row must be 1 row
if($count>0)
{
	 
        // Establecer la zona horaria predeterminada a usar. Disponible desde PHP 5.1
        date_default_timezone_set('UTC');
        //Imprimimos la fecha actual dandole un formato
       $_SESSION['fecha']=date("Y-m-d");
        
	///idcargo
	$_SESSION['opera']=$row[6];
	///cedula
	$_SESSION['login_user']=$row['2'];
	///id_usuario
	$_SESSION['usua']=$row['0'];
	$result1=mysql_query("SELECT perfil FROM cargo WHERE idcargo='".$row[6]."' and activo=0");
	$row1 = mysql_fetch_array($result1);
	///perfil de sesion
	$_SESSION['perfil']=$row1[0];
	$_SESSION['coord']=$row[8];

echo $row['2'];

 $h_acti=$db->query("SELECT * FROM actividad limit 1 ;");
  $h_activ=$h_acti->fetch_array();
  $h_activ["nombre_act"];
}

}
?>