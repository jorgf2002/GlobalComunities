<?php require_once("config.php"); @session_start();  ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">  
<head> 
  <title>PLATAFORMA -HOGARES -BENEFICIARIOS</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
     <meta name="viewport" content="width=device-width, initial-scale=1.0"/>  
         <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>
 <!--Import Google Icon Font-->     
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
       <link rel="icon" type="image/png" href="imagenes/hombre.png" />            
            <link rel="stylesheet" type="text/css" href="css/edicion.css">
             </script>  
 <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
<script type="text/javascript" src="js/materialize.min.js"></script>
<script src="js/jquery.ui.shake.js"></script>      
                    <script type="text/javascript" src="js/configuracion.js"></script>
                     <script src="js/calendar.min.js"></script>
                    <script src="js/jquery.colorbox-min.js"></script>
                    <link href="css/calendar.min.css" rel="stylesheet">                            
                    <link href="css/colorbox.css" rel="stylesheet">
					<script src="js/jquery.ui.shake.js"></script>
					<script type="text/javascript" src="js/configuracion.js"></script> 					
                    </head>          
	<body>      
      <script type="text/javascript">

                     $(document).ready(function(){
                     	$('.modal-trigger').leanModal();                
                        $('.dropdown-button').dropdown(); 
                        $(".button-collapse").sideNav();

				 $("a").on("click", function(){
				 var url_ins=$(this).attr('data'); 
				 	if(url_ins!='undefined'){
				 	$(".calendar").load(url_ins);
							}else{ return false; }
												});             
			
                      });
                    </script>
	 <div class="navbar cabecera" >  
           <div> 
                      <div class="row">
                              <div class="col s12 m4">
                                <div class="icon-block">          
                                         <a href="inicio.php" title="Ir al Inicio"><img src="imagenes/logo.png" class="responsive-img" alt="" width='330' height='170'/>  </a>
                              </div>
                              </div>
                              <div class="col s12 m4">
                                <div class="icon-block">           
                                  <h3 class="center color_azul efecto3d">PROGRAMA ANDA</h3>
                                  <h5 align="center" class="color_verde"> Cronograma de Actividades</h5> 
                                   <?php
                                                                                                      if(!empty($_SESSION['login_user']))
                                                                                                      {   $_SESSION['fecha'];
                                                                                                           
                                                                                                      }else{echo "Invitado";}                                 
                                                                                                ?>
                                         
                                </div>
                              </div>
                              <div class="col s12 m4">
                                <div class="icon-block">
                                  <a class="modal-trigger right brand-logo color_azul" href="#sesion">
                                                                                                <br /> <img src="imagenes/hombre.png" width="82px" height="82px" /> 
                                                                                                <br /> 
                                                                                                <?php
                                                                                                      if(!empty($_SESSION['login_user']))
                                                                                                      {   $_SESSION['fecha'];
                                                                                                            echo  $_SESSION['login_user'];    
                                                                                                      }else{echo "Invitado";}                                 
                                                                                                ?><br /> 
                                                                            </a>
                                </div>
                              </div>
                      </div>
           </div>
    </div>  
   <!--////////////MODAL -->
     <!--////////////MODAL -->  

            <div class="row">
                 <div class="modal modal-fixed-footer" id="sesion">
                              <?php
                              if(!empty($_SESSION['login_user']))
                              {
                               echo " <div class='col s6 m12 card '>
                               		  <iframe name='frame12' id='botonera' src='./Modulos/admon/Perfil/perfil.php' style=' display:inline-block' marginwidth='0' marginheight='0' scrolling='no' border='0'  frameborder='0' width='100%' height='270px'> </iframe></div>";                             

                              }else{
                                ?><div id="box" style="width:50%; margin: 0 auto; padding: 10px 10px 10px 10px; ">
                                    <form action="" method="post">
                                        <div><label>Usuario:</label> 
                                        <input type="text" name="username" class="input" autocomplete="off" id="username"/>
                                         <label>Contraseña: </label>
                                        <input type="password" name="password" class="input" autocomplete="off" id="password"/></div>
                                        <input type="submit"  class="waves-effect btn secondary-content" value="Entrar" id="login"/> 
                                         <span class='msg'></span> 
                                        <div id="error"></div>
                                     </form>
                                   </div>

                                <?php 
                                }
                              ?>
                                <div class="modal-footer">
                      <a href="#" id="act_usuario" class="modal-action modal-close waves-effect waves-green btn-flat">
                        <i class="large material-icons right">close</i></a>
                    </div>
                </div>  
            </div>
          <!-- ///////////MODAL -->
    
   <!--///////// -->
  
   <!--/////////dtryrty-->

    <?php
    if(!empty($_SESSION['login_user']))
{ ?>   

 

<nav class="orange">     
			<div class="nav-wrapper responsive-img orange accent-3">

							
			  <a href="#" data-activates="slide-out" class="button-collapse"><i class="mdi-navigation-menu"></i></a>
			  <ul id="slide-out" class="side-nav">
			    <li><a id="crono" target="_self" href='inicio.php'>
				           Volver al Inicio
				      </a>
				</li>
				<li><a id="cronograma_" href='crono.php'>Volver a Cronograma</a></li>
				<li><a id="lista_chk" data='lista_chk.php' href='#'>Lista de Chequeo</a></li>
				          <?php 	if($_SESSION['coord']==0){ ?>  
	                           
				   <li><a href='Modulos/admon/Reporte/reporteexcel.php'>Descargar Reporte Gral</a></li>
				   
			       <li><a id="ad_usuario" data='./Modulos/admon/Usuarios/admin_usuarios.php'  href='#'>Admin. Usuarios</a></li>
			       <li><a id="notifi_act" data='notificacion.php' href='#'>Notificaciones</a></li>
			       <li><a id="elimina_act" data='eliminad.php'  href='#'>Eliminadas</a></li>
			       <li><a id="sin_activ" data='revision.php' href='#'>Sin Actividades</a></li>
			       <li class="divider"></li>
			     
				         <?php } ?>  <li><a href='logout.php'>Cerrar Sesion</a></li>
			  </ul>
			  
<!--  HASTA AQUI ES MOVIL    -->
                  <ul class="right hide-on-med-and-down">
	                    <li>
	                        <a id="crono" target="_self" href='inicio.php'>
	                                <span><i class="material-icons left">home</i>Volver al Inicio</span>
	                        </a>
	                    </li> 

	                    <li><a id="cronograma_" href='crono.php'><i class="material-icons left">today</i>Volver a Cronograma</a></li>

	                     <?php 	if($_SESSION['coord']==0){ ?>  
	                           
	                           <li><a href='Modulos/admon/Reporte/reporteexcel.php'><i class="material-icons left">archive</i>Descargar Reporte Gral</a></li>
							  
						      <li><a class='dropdown-button' href='#' data-activates='dropdown1'><i class="material-icons left">settings_applications</i>Administrar </a></li>  

  				
	                     <?php } ?> 

	                     <li><a id="lista_chk" data='lista_chk.php' href='#'><i class="material-icons">playlist_add_check</i></a></li> 
	                     <li><a href='logout.php'><i class="material-icons">power_settings_new</i></a></li>
                  </ul>
                   <ul id="dropdown1" class="dropdown-content"> 
                   				
                			   <li><a id="ad_usuario" data='./Modulos/admon/Usuarios/admin_usuarios.php'  href='#'>Admin. Usuarios</a></li>
						       <li><a id="notifi_act" data='notificacion.php' href='#'>Notificaciones</a></li>
						       <li><a id="elimina_act" data='eliminad.php'  href='#'>Eliminadas</a></li>
						       <li><a id="sin_activ" data='revision.php' href='#'>Sin Actividades</a></li>
						       <li class="divider"></li>
						      
                </ul>

            </div>
          </nav>


<div id="evalu" data-color="normal" style="width:17%">
</div>
	<div class="calendar" data-color="normal" style="width:97%">
			<?php
		require_once("uno.php");//echo $_SESSION['cuanto']."--". $_SESSION['cuantas'];		
 		$query_eventos=$db->query("SELECT actividad.nombre_act,actividad.sigla_act,
											cargo.nombre,
											operador.nombre_op,operador.sigla,
											cronograma.hora_i,cronograma.hora_f,
											cronograma.descripcion,cronograma.id_actividad,
											usuario.nombre_u,cronograma.fecha,
											cronograma.id_cronograma,cronograma.idpoblacion  
											FROM cronograma 
												inner join usuario on cronograma.id_usuario=usuario.id_usuario
												inner join actividad on actividad.id_actividad=cronograma.id_actividad			
												inner join cargo on cargo.idcargo=usuario.idcargo
												inner join operador on operador.id_operador=usuario.id_operador  
												where cronograma.id_estado=0 and cronograma.id_anterior=0 
												order by cronograma.hora_i asc");
				if ($eventos=$query_eventos->fetch_array())
				{
				do
				{
				?>
			  	<div data-role="day" data-day="<?php $fecha=explode("-",$eventos["fecha"]); echo $fecha[0].intval($fecha[1]).intval($fecha[2]); ?>">
                <div data-role='event' data-idevento='<?php echo $eventos['id_cronograma']; ?>' data-name='<?php echo $eventos["fecha"];?>'>				
						</div>                         
				</div>
				<?php 
				}while($eventos=$query_eventos->fetch_array());
			}
			?> 			
		</div> <input name="fe"style="visibility:hidden;width: 1px;" id="fe" size='1' type="text"  value="<?php if(!empty($_SESSION['fec']))
																			{$fecha=explode("-",$_SESSION['fec']); 
																				echo $fecha[0].intval($fecha[1]).intval($fecha[2]); 
																	}?>">
			   <input name='pasa' style="visibility:hidden" id='pasa'  type='text'  value='<?php  if($_SESSION['cuanto']==$_SESSION['cuantas']){echo 1;}else{ echo 0;};
									 ?>'> <?php }else{ echo "<div class='calendar' data-color='normal' style='width:770px; align:center;'><h4 class='efecto3d'>Debe Iniciar Sesion.</h4> <br /></div>"; }?>	  
	<script>
			var yy;
			var calendarArray =[];
			var monthOffset = [6,7,8,9,10,11,0,1,2,3,4,5];
			var monthArray = [["ENE","Enero"],["FEB","Febrero"],["MAR","Marzo"],["ABR","Abril"],["MAY","Mayo"],["JUN","Junio"],["JUL","Julio"],["AGO","Agosto"],["SEP","Septiembre"],["OCT","Octubre"],["NOV","Noviembre"],["DIC","Diciembre"]];
			var letrasArray = ["L","MA","MI","J","V","S","D"];
			var dayArray = ["7","1","2","3","4","5","6"];
			$(document).ready(function() {						
				$(document).on('click','.calendar-day.have-events',activateDay);
				$(document).on('click','.specific-day',activatecalendar);			
				$(document).on('click','.calendar-month-view-arrow',offsetcalendar);				
				$(window).resize(calendarScale);
				$(".calendar").calendar({
					"2013910": {
						"": {
							idevento: ""
						}
					}
				});
				calendarSet();
				calendarScale();
				$('body').on('click', '.colorbox', function(e) 
				{	e.preventDefault();
					$.colorbox({href:$(this).attr('href'), open:true,iframe:true,innerWidth:"700px",innerHeight:"620px",overlayClose:false,onClosed:function() {
						/*	calendarSet();	calendarScale(); */////alert(bande);							
							if(bande=='E'){$(".specific-day-scheme").load('consulta.php?fecha='+global);}else{activatecalendar();}
					} });
					return false;
				});
			});
	</script>

	<footer class="page-footer teal">
	    <div class="container">
	      <div class="row">
	        <div class="col l6 s12">
	          <h5 class="white-text">PROGRAMA ANDA - Plataforma - Beneficiarios Directos- M&E</h5>
	          <p class="grey-text text-lighten-4">Software desarrollado para la programación de actividades en campo, del Programa ANDA. Esta herramienta fue diseñada por el Equipo de M&E, para el programa ANDA, Bajo la supervisión de todas las Coordinaciones y la Gerencia.</p>


	        </div>
	              <div class="col l3 s12">
          <h5 class="white-text ">Equipo M&E</h5>
          <ul>
            
          </ul>
        </div>
        <div class="col l3 s12">
          <h5 class="white-text"></h5>
          <ul>
           
          </ul>
        </div>
      </div>
    </div>
    <div class="footer-copyright">
      <div class="container">
      Diseñado por  <a class="brown-text text-lighten-3" href="#">Ing. M&E Jorge L Romero Fonseca</a>
      Correo: <a class="brown-text text-lighten-3" href="mailto:jromero@globalcommunities.org.co">jromero@globalcommunities.org.co</a>
      </div>
    </div>


</body>
</html>