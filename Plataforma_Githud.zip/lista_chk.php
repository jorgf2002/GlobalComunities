     <!-- LISTA DE CHEQUEO -->
<script type="text/javascript">
    /////////////PERFIL////////////agregar esto en la consulta  AND (DAY(NOW())>25) 
          $('.av').click(function(e){
                 var retVal = confirm("Esta seguro(a) de Continuar con esta Operacion?");
                         if( retVal == true ){ 
                                    $.ajax({
                                         type: "POST",
                                         url: "consulta_act.php",
                                         data: 'acc=aval',
                                           success: function(data) {
                                       $("#mens").html("<p  class='ok'>Haga Clic <a href='crono.php' class=''>aqui<img src='images/check.png' width='32' height='32'></a>y continuar programando, las actividades del Proximo mes.</p>");
                              }
                            });
                            return true;
                         }
                         else{
                            alert("Ud. Cancelo la Revision de las Actividades.");
                            return false;
                         }
                });
            //check box 1
             $('.switch').change(function(e){ 
            pp=$(this).attr('oper');
            /////////////////////////////
              var idd= $(this).attr('id');
              if($('.'+idd).is(':checked')) { //alert("Está activado 1"+idd); 
                              act=1;} else { //alert("No está activado 0"+idd); 
                              act=0;}
            //alert(idd);
            $.ajax({
                       type: "POST",
                       url: "consulta_act.php",
                       data: 'act=' + act+'&idd='+idd+'&acc='+pp,
                         success: function(data) {
                    //alert(data);
                    }
                  }); 
                });
        ///////////////
</script>

<div id="content" align="center">
                            <h5 class="color_azul" >Lista de Chequeo</h5>
                            <div id="men"><h6 class="color_morado">Las Actividades que estan no marcadas, Es porque no se ejecutaron.</h6> </div>
                              <?php    @session_start();  
                    require("config.php");  
                    //echo $h_activ["nombre_act"];
                    @$fecha=$_GET['fecha'];
                    $query_e=$db->query(" SELECT * FROM 
                                ((SELECT cronograma.id_usuario,
                              cronograma.id_estado,
                              cronograma.fecha,
                              cronograma.id_cronograma,
                              cronograma.id_comunidad,
                              cronograma.hora_i,
                              cronograma.hora_f,
                              cronograma.id_actividad,
                              cronograma.id_operador,
                              cronograma.descripcion,
                              cronograma.activo,
                              cronograma.id_anterior,
                              cronograma.idpoblacion,
                              cronograma.lugar,
                              cronograma.realizada,
                              cronograma.aval,
                              cronograma.casco,
                              cronograma.municipio,
                              usuario.id_usuario AS id_usuario1,
                              usuario.cedula,
                              usuario.nombre_u,
                              usuario.usuario,
                              usuario.password,
                              usuario.id_operador AS id_operador1,
                              usuario.Idcargo,
                              usuario.estado,
                              usuario.idcoordinacion 
                                FROM cronograma 
                               INNER JOIN usuario on usuario.id_usuario=cronograma.id_usuario 
                               WHERE cronograma.id_usuario='".$_SESSION['usua']."'   AND cronograma.id_estado =0
                              AND (year(fecha)=YEAR(NOW()) and month(fecha)=(MONTH (NOW())-1) ) or (year(fecha)>YEAR(NOW()) and month(fecha)>(MONTH (NOW())) )
                              )
                               UNION
                                (SELECT cronograma.id_usuario,
                              cronograma.id_estado,
                              cronograma.fecha,
                              cronograma.id_cronograma,
                              cronograma.id_comunidad,
                              cronograma.hora_i,
                              cronograma.hora_f,
                              cronograma.id_actividad,
                              cronograma.id_operador,
                              cronograma.descripcion,
                              cronograma.activo,
                              cronograma.id_anterior,
                              cronograma.idpoblacion,
                              cronograma.lugar,
                              cronograma.realizada,
                              cronograma.aval,
                              cronograma.casco,
                              cronograma.municipio,
                              usuario.id_usuario AS id_usuario1,
                              usuario.cedula,
                              usuario.nombre_u,
                              usuario.usuario,
                              usuario.password,
                              usuario.id_operador AS id_operador1,
                              usuario.Idcargo,
                              usuario.estado,
                              usuario.idcoordinacion  FROM cronograma 
                                INNER JOIN usuario on usuario.id_usuario=cronograma.id_usuario 
                                WHERE  idcoordinacion='".$_SESSION['usua']."'   AND id_estado =0 
                                   AND (year(fecha)=YEAR(NOW()) and month(fecha)=(MONTH (NOW())-1) ) or (year(fecha)>YEAR(NOW()) and month(fecha)>(MONTH (NOW())) )   ))as t ORDER BY nombre_u ASC");
                                            echo '<table > 
                                                         <thead class="orange accent-4">
                                                          <tr>
                                                          <th width="70px" >Fecha</th>
                                                            <th width="90px" >Hora</th>
                                                            <th width="auto" align="justify" >Comunidad</th>
                                                            <th >Pob. Objeto</th>
                                                            <th >Tipo de Act.</th>
                                                            <th >Cargo</th>
                                                            <th width="170px">Nombre</th>
                                                            <th >'; 
                         ?></th>                                
                              </tr>
                              </thead>
                            <tbody><?php $num=0; $sum=0; 
                                                        $band=0;
                                                    $row_cnt = $query_e->num_rows; 
                                                        $cont=0;
                                            if($ev=$query_e->fetch_array()){
                                            do{ $sum=$ev["aval"]+$sum; 
                                            $cont++;$cnt=0;$comnuni=""; 
                        $piezas = explode(",", $ev["id_comunidad"]);
                                                while (count($piezas)>$cnt){
                                                    $sql=$db->query("SELECT comunidad, municipio,id_comunidad FROM municipio 
                                                                    INNER JOIN comunidad ON municipio.id_municipio=comunidad.id_municipio WHERE id_comunidad='".$piezas[$cnt]."'");
                                                        $comn=$sql->fetch_array(); 
                               if($piezas[$cnt]=='cen'){$comnuni='Centro Poblado'.','.$comnuni;}else{ 
                                                                    if($piezas[$cnt]=='cas'){$comnuni='Casco Urbano'.','.$comnuni;}
                                                                            else
                                                                             {$comnuni=$comn[0].','.$comnuni;}                                                                                                
                                                                } $cnt=$cnt+1;
                                                }                                            
                                                $comnuni = trim($comnuni, ','); 
                                            /////////////////////////////////////////////////
                                            $query_pb=$db->query("SELECT cargo.nombre,
                                                                      usuario.nombre_u,
                                                                      cronograma.id_cronograma
                                                                    FROM
                                                                      municipio
                                                                      INNER JOIN comunidad ON comunidad.id_municipio = municipio.id_municipio
                                                                      INNER JOIN cronograma ON comunidad.id_comunidad =cronograma.id_comunidad
                                                                      INNER JOIN usuario ON usuario.id_usuario = cronograma.id_usuario
                                                                      INNER JOIN cargo ON usuario.Idcargo = cargo.idcargo
                                                                     WHERE
                                                                      id_cronograma ='".$ev["id_cronograma"]."' ;");
                                                        $evp=$query_pb->fetch_array();
                                                        $query_ac=$db->query("SELECT * FROM actividad WHERE id_actividad='".$ev["id_actividad"]."';");
                                                        $evac=$query_ac->fetch_array();
                                                        $query_pbp=$db->query("SELECT * FROM poblacion WHERE idpoblacion='".$ev["idpoblacion"]."';");
                                                        $evpp=$query_pbp->fetch_array();
                                    
                                    if($cont==$row_cnt)
                                            {
                                    if($sum==$row_cnt)
                                            {      echo "<div id='mens'> <p  class='ok'>Haga Clic <a href='crono.php' class=''>aqui<img src='images/check.png' width='32' height='32'></a>y continuar programando, las actividades del Proximo mes. </p></div>";
                                             }else{if($_SESSION['coord']<>0){
                                                 echo "<div id='mens'><p  class='ko'><img src='images/check1.png' width='32' height='32'></a>pongase en contacto con su coordinador para poder continuar programando las actividades.</p></div>";
                                                 }else{
                                                 echo "<div id='mens'><p  class='ko'>Haga Clic<a href='#' class='av'>aqui<img src='images/check1.png' width='32' height='32'></a>para Dar VoBo a estas actividades y  continuar programando sus actividades.</p></div>";}
                                            }  }
                                            if($num==0){$num=1;   ?>
                                                  <tr>
                                                  <td><?php  echo $ev["fecha"]; ?></td>
                                                    <td><?php  echo "(".$ev["hora_i"]."-".$ev["hora_f"].")"; ?></td>
                                                    <td><?php echo utf8_encode($comnuni); ?></td>
                                                    <td><?php echo $evpp["nombre"]; ?></td>
                                                    <td><?php echo utf8_decode($evac["nombre_act"]); ?></td>
                                                    <td><?php echo $evp["nombre"]; ?></td>
                                                    <td><?php echo $ev["nombre_u"]; ?></td>
                                                    <td >  <div class="switch" id="<?php echo $ev["id_cronograma"]; ?>" oper="realizada">
                                                <label>                                                  
                                                  <input <?php if($ev['realizada']==1){ echo "checked ";} ?> class="<?php echo $ev["id_cronograma"]; ?>" type="checkbox">
                                                  <span class="lever" data-unchecked="No" data-checked="Ok"> </span>                                              
                                                </label>
                                              </div></td>
                                                 </tr>
                                                <?php   }else{$num=0;?> 
                                                 <tr>
                                                 <td><?php echo $ev["fecha"]; ?></td>
                                                 <td><?php echo "(".$ev["hora_i"]."-".$ev["hora_f"].")"; ?></td>
                                                <td><?php echo utf8_encode($comnuni); ?></td>
                                                <td><?php echo $evpp["nombre"]; ?></td>
                                                <td><?php echo utf8_encode($evac["nombre_act"]); ?></td>
                                                <td><?php echo $evp["nombre"]; ?></td>
                                                <td><?php echo $ev["nombre_u"]; ?></td>
                                                    <td >  <div class="switch" id="<?php echo $ev["id_cronograma"]; ?>" oper="realizada">
                                                <label>                                                  
                                                  <input <?php if($ev['realizada']==1){ echo "checked ";} ?> class="<?php echo $ev["id_cronograma"]; ?>" type="checkbox">
                                                  <span class="lever" data-unchecked="No" data-checked="Ok"> </span>                                              
                                                </label>
                                              </div></td>
                                                 </tr>
                                            <?php }
                                            }while($ev=$query_e->fetch_array());}
                                    echo '</tbody></table>'; 
             ?></div>
                         
         <!-- FIN LISTA DE CHEQUEO --> 