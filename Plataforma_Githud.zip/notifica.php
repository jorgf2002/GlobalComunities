<?php header('Content-Type: text/html; charset=utf-8'); 
require_once("config.php"); @session_start(); 
$s=0;
							
									
									
									$query_e=$db->query("SELECT * from notifica ");
									while($ev=$query_e->fetch_array())
									{	
									echo "<p class='ko'>Se ha producido un error modificando el evento.'".intval($ev['hi'])."'";}
									
					
				
					
						
						?>