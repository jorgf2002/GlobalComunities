﻿<?php @session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta charset="UTF-8">
      				<title>PERFIL - CRONOGRAMA</title>
                               <link rel="icon" type="image/png" href="imagenes/hombre.png" />
                    <script src="js/jquery-latest.min.js" type="text/javascript"></script>
					<script src="js/jquery.min.js"></script> 
                    <script src="js/calendar.min.js"></script>
                    <script src="js/jquery.colorbox-min.js"></script>
                      <link rel="stylesheet" href="css/style.css"/>              
                     <link rel="stylesheet" href="css/pagweb.css" />                   
                    <link href="css/calendar.min.css" rel="stylesheet">                   
                    <link href="css/colorbox.css" rel="stylesheet">
					<script src="js/jquery.ui.shake.js"></script> 
					<link rel="stylesheet" type="text/css" href="css/edicion.css">
					<script type="text/javascript" src="js/configuracion.js"></script>
	<!--	<script>
				var yy;
				var calendarArray =[];
				var monthOffset = [6,7,8,9,10,11,0,1,2,3,4,5];
				var monthArray = [["ENE","Enero"],["FEB","Febrero"],["MAR","Marzo"],["ABR","Abril"],["MAY","Mayo"],["JUN","Junio"],["JUL","Julio"],["AGO","Agosto"],["SEP","Septiembre"],["OCT","Octubre"],["NOV","Noviembre"],["DIC","Diciembre"]];
				var letrasArray = ["L","MA","MI","J","V","S","D"];
				var dayArray = ["7","1","2","3","4","5","6"];
				$(document).ready(function() 
				{
						
					$(document).on('click','.calendar-day.have-events',activateDay);
					$(document).on('click','.specific-day',activatecalendar);
					$(document).on('click','.calendar-month-view-arrow',offsetcalendar);
					
					$(window).resize(calendarScale);
					$(".calendar").calendar({
						"2013910": {
							"": {
								idevento: ""
							}
						}
					});
					calendarSet();
					calendarScale();
				/*	$('body').on('click', '.specific-day', function(e) 
					{	e.preventDefault();
						location.reload()
						 } );
						return false;
					});*/
					
					$('body').on('click', '.colorbox', function(e) 
					{	e.preventDefault();
						$.colorbox({href:$(this).attr('href'), open:true,iframe:true,align:"center",innerWidth:"450px",innerHeight:"300px",overlayClose:false,onClosed:function() { location.reload();
						 } });
						return false;
					});
					
					
					
				});
	    </script>-->
	    <script type="application/javascript">
			$(document).ready(function()
			{	
									
		$('.pestana').hide().eq(0).show();
		$('.tabs li').click(function(e)
		{
		$('#men').fadeIn(2500).delay(1250).fadeOut(2500); 
			e.preventDefault();
			$('.pestana').hide();
			$('.tabs li').removeClass("selected");
			var id = $(this).find("a").attr("href");
			$(id).fadeToggle();
			 //$("<i>Añadiendo Tabs dinamicos</i>").appendTo(id);
			$(this).addClass("selected");
		});
	});
		</script>
   
	</head>
	<body>
     <header>
   		 <hgroup align="center" >
                  <table width="100%" height="auto" border="0" style="border:none">
                    <tr height="160px">
                <td width="275" ><a href="inicio.php" title="Ir al Inicio"><img src="imagenes/logo.png" alt="" width="242" height="97" /></a></td>
                <td width="468"> <h1 align="left">PROGRAMA ANDA </h1> <br />
                    <h2 align="left">Cronograma de Actividades </h2> <br />
                    <h2><?php            
            if(!empty($_SESSION['login_user']))
            {
                        echo  $_SESSION['login_user']; ?>
                        <div>	 <label>Volver a Cronograma</label>
                                <input name='' type='image' value=""  width='42' height='42' src='imagenes/agenda.png' align='middle'  onclick='document.location.href=("crono.php")'>
                        </div>
                        <?php 
                        
            }else{echo "Invitado";}
            ?></h2></td>
                <td width="168"><?php
            
            if(!empty($_SESSION['login_user']))
            {
            echo "<a href='logout.php'>Cerrar Sesion</a>";
            }else{
                ?>                      
                  <div id="box">
			            <form action="" method="post">
			            <div><label>Usuario:</label> 
			            <input type="text" name="username" class="input" autocomplete="off" id="username"/>
			            <label>Contraseña: </label>
			            <input type="password" name="password" class="input" autocomplete="off" id="password"/></div>
			            <input type="submit" class="button button-primary" value="Entrar" id="login"/> 
			            <span class='msg'></span> 
			            <div id="error">
			            </div></form>
                 </div>            
                <?php 
                }
            ?>
            </div></td>
              </tr>
            </table>
  		</hgroup>
	</header>
    <?php
    if(!empty($_SESSION['login_user']))
{ ?>	<div id="tabl" >

		<div id="pumm" class="calendarj" data-color="normal" >

    <ul class="tabs">
    	<?php if($_SESSION['coord']==0){ ?>
        <li class="selected"><a href="#tab-2">Lista</a></li>
        <li ><a href="#tab-1">Admin. Usuarios</a></li>
		<li><a href="#tab-3">Notificaciones</a></li>
        <li><a href="#tab-4">Eliminadas</a></li> 
        <li><a href="#tab-5">Sin Registro</a></li> 
		<?php
		}?>
	</ul>
      <!-- LISTA DE CHEQUEO -->
                       <div class="pestana" id="tab-2" align="center" style="display:block;">
                        <h2>Lista de Chequeo</h2>
                       			<div id="men"><h2>Las Actividades que estan no marcadas, Es porque no se ejecutaron.</h2> </div>
                   					  <?php    @session_start();  
									  require("config.php");  
									  @$fecha=$_GET['fecha'];
  	    	                                                  $query_e=$db->query(" SELECT * FROM 
															  ((SELECT cronograma.id_usuario,
															cronograma.id_estado,
															cronograma.fecha,
															cronograma.id_cronograma,
															cronograma.id_comunidad,
															cronograma.hora_i,
															cronograma.hora_f,
															cronograma.id_actividad,
															cronograma.id_operador,
															cronograma.descripcion,
															cronograma.activo,
															cronograma.id_anterior,
															cronograma.idpoblacion,
															cronograma.lugar,
															cronograma.realizada,
															cronograma.aval,
															cronograma.casco,
															cronograma.municipio,
															usuario.id_usuario AS id_usuario1,
															usuario.cedula,
															usuario.nombre_u,
															usuario.usuario,
															usuario.password,
															usuario.id_operador AS id_operador1,
															usuario.Idcargo,
															usuario.estado,
															usuario.idcoordinacion 
															  FROM cronograma 
															 INNER JOIN usuario on usuario.id_usuario=cronograma.id_usuario 
															 WHERE cronograma.id_usuario='".$_SESSION['usua']."'  AND id_estado =0
															AND (fecha BETWEEN  DATE_SUB( CURDATE( ) , INTERVAL (DAY(NOW())+30) DAY ) AND date_sub(NOW(), INTERVAL (DAY(NOW())) day)) 
															)
															 UNION
															  (SELECT cronograma.id_usuario,
															cronograma.id_estado,
															cronograma.fecha,
															cronograma.id_cronograma,
															cronograma.id_comunidad,
															cronograma.hora_i,
															cronograma.hora_f,
															cronograma.id_actividad,
															cronograma.id_operador,
															cronograma.descripcion,
															cronograma.activo,
															cronograma.id_anterior,
															cronograma.idpoblacion,
															cronograma.lugar,
															cronograma.realizada,
															cronograma.aval,
															cronograma.casco,
															cronograma.municipio,
															usuario.id_usuario AS id_usuario1,
															usuario.cedula,
															usuario.nombre_u,
															usuario.usuario,
															usuario.password,
															usuario.id_operador AS id_operador1,
															usuario.Idcargo,
															usuario.estado,
															usuario.idcoordinacion  FROM cronograma 
															  INNER JOIN usuario on usuario.id_usuario=cronograma.id_usuario 
															  WHERE  idcoordinacion='".$_SESSION['usua']."'   AND id_estado =0 
																	AND fecha BETWEEN  DATE_SUB( CURDATE( ) , INTERVAL (DAY(NOW())+30) DAY ) AND date_sub(NOW(), INTERVAL (DAY(NOW())) day)  ))as t
 
ORDER BY nombre_u ASC");
                                            echo '<div><table cellspacing="0" cellpadding="0">
                                                         <thead>
                                                          <tr>
                                                          <th width="70px" >Fecha</th>
                                                            <th width="90px" >Hora</th>
                                                            <th width="auto" align="justify" >Comunidad</th>
                                                            <th >Pob. Objeto</th>
                                                            <th >Tipo de Act.</th>
                                                            <th >Cargo</th>
                                                            <th width="170px">Nombre</th>
                                                            <th >'; 
											   ?></th>
                                
                              </tr>
                              </thead>
                            <tbody><?php $num=0; $sum=0; /**/
                                                        $band=0;
                                                    $row_cnt = $query_e->num_rows; 
                                                        $cont=0;
                                            if($ev=$query_e->fetch_array()){
                                            do{ $sum=$ev["aval"]+$sum; 
                                            $cont++;$cnt=0;$comnuni="";	
											  $piezas = explode(",", $ev["id_comunidad"]);
                                                while (count($piezas)>$cnt){
                                                    $sql=$db->query("SELECT comunidad, municipio,id_comunidad FROM municipio 
                                                    INNER JOIN comunidad ON municipio.id_municipio=comunidad.id_municipio WHERE id_comunidad='".$piezas[$cnt]."'");
                                                        $comn=$sql->fetch_array(); 
														   if($piezas[$cnt]=='cen'){$comnuni='Centro Poblado'.','.$comnuni;}else{	
                                                                    if($piezas[$cnt]=='cas'){$comnuni='Casco Urbano'.','.$comnuni;}
                                                                            else
                                                                             {$comnuni=$comn[0].','.$comnuni;}                                                                                                
                                                                }	$cnt=$cnt+1;
                                                }                                            
                                                $comnuni = trim($comnuni, ','); 
                                            /////////////////////////////////////////////////
                                            $query_pb=$db->query("SELECT cargo.nombre,
                                                                      usuario.nombre_u,
                                                                      cronograma.id_cronograma
                                                                    FROM
                                                                      municipio
                                                                      INNER JOIN comunidad ON comunidad.id_municipio = municipio.id_municipio
                                                                      INNER JOIN cronograma ON comunidad.id_comunidad =cronograma.id_comunidad
                                                                      INNER JOIN usuario ON usuario.id_usuario = cronograma.id_usuario
                                                                      INNER JOIN cargo ON usuario.Idcargo = cargo.idcargo
                                                                     WHERE
                                                                      id_cronograma ='".$ev["id_cronograma"]."' ;");
                                                        $evp=$query_pb->fetch_array();
                                                        $query_ac=$db->query("SELECT * FROM actividad WHERE id_actividad='".$ev["id_actividad"]."';");
                                                        $evac=$query_ac->fetch_array();
                                                        $query_pbp=$db->query("SELECT * FROM poblacion WHERE idpoblacion='".$ev["idpoblacion"]."';");
                                                        $evpp=$query_pbp->fetch_array();
                                    
                                    if($cont==$row_cnt)
                                            {
                                    if($sum==$row_cnt)
                                            {      echo "<div id='mens'> <p  class='ok'>Haga Clic <a href='crono.php' class=''>aqui<img src='images/check.png' width='32' height='32'></a>y continuar programando, las actividades del Proximo mes. </p></div>";
                                             }else{if($_SESSION['coord']<>0){
                                                 echo "<div id='mens'><p  class='ko'><img src='images/check1.png' width='32' height='32'></a>pongase en contacto con su coordinador para poder continuar programando las actividades.</p></div>";
                                                 }else{
                                                 echo "<div id='mens'><p  class='ko'>Haga Clic<a href='#' class='av'>aqui<img src='images/check1.png' width='32' height='32'></a>para Dar VoBo a estas actividades y 	continuar programando sus actividades.</p></div>";}
                                            }	 }
                                            if($num==0){$num=1;   ?>
                                                  <tr>
                                                  <td><?php  echo $ev["fecha"]; ?></td>
                                                    <td><?php  echo "(".$ev["hora_i"]."-".$ev["hora_f"].")"; ?></td>
                                                    <td><?php echo utf8_encode($comnuni); ?></td>
                                                    <td><?php echo $evpp["nombre"]; ?></td>
                                                    <td><?php echo utf8_decode($evac["nombre_act"]); ?></td>
                                                    <td><?php echo $evp["nombre"]; ?></td>
                                                    <td><?php echo $ev["nombre_u"]; ?></td>
                                                    <td ><label class="toggle" id="<?php echo $ev["id_cronograma"]; ?>" oper="realizada" > 
                                                    <input  <?php if($ev['realizada']==1){ echo "checked ";} ?> class="<?php echo $ev["id_cronograma"]; ?>" type="checkbox"> 
                                                    <span  data-unchecked="No" data-checked="Ok"> </span>
                                                    </label></td>
                                                 </tr>
                                                <?php   }else{$num=0;?> 
                                                 <tr class="alt" bgcolor="#3dc">
                                                 <td><?php echo $ev["fecha"]; ?></td>
                                                 <td><?php echo "(".$ev["hora_i"]."-".$ev["hora_f"].")"; ?></td>
                                                <td><?php echo utf8_encode($comnuni); ?></td>
                                                <td><?php echo $evpp["nombre"]; ?></td>
                                                <td><?php echo utf8_encode($evac["nombre_act"]); ?></td>
                                                <td><?php echo $evp["nombre"]; ?></td>
                                                <td><?php echo $ev["nombre_u"]; ?></td>
                                                    <td ><label class="toggle" id="<?php echo $ev["id_cronograma"]; ?>" oper="realizada"  > <input <?php if($ev['realizada']==1){ echo "checked ";} ?> class="<?php echo $ev["id_cronograma"]; ?>" type="checkbox"> <span  data-unchecked="No" data-checked="Ok"> </span></label></td>
                                                 </tr>
                                            <?php }
                                            }while($ev=$query_e->fetch_array());}
                                    echo '</tbody></table> </div>'; 
             ?>
                       </div>   
         <!-- FIN LISTA DE CHEQUEO --> 
          <!-- ADMINISTRACION DE USUARIOS -->   
                       <div class="pestana" id="tab-1" align="center">
                            <h2>Administracion de Usuarios</h2>
                            <a class="colorbox" href="./Modulos/Usuario/usuario.php?accion=insertar"> <img src="images/021.png"></a>
                                      <table cellspacing="0" cellpadding="0" style='width:auto;'>
                            <tr>
                                <th>Cedula</th>
                                <th style='width:auto;'>Nombre</th>
                                <th>Usuario</th>
                                 <th>Perfil</th>
                                <th>Operador</th>
                                <th></th>
                                <th>
                        </th>
                            </tr> 
                        <?php @session_start();  require("config.php");  
                        $query_eventos=$db->query("SELECT * FROM usuario  WHERE idcoordinacion<>0 AND estado=0 AND idcoordinacion='".$_SESSION['usua']."';");
                       while ($row=$query_eventos->fetch_array())
                        {    $sql2=$db->query("SELECT * FROM operador WHERE id_operador='".$row['5']."'");
                             $sql3=$db->query("SELECT * FROM cargo WHERE idcargo='".$row['6']."'");
                            echo "<tr>";
                            echo "<td>".utf8_encode($row['1'])."</td>";
                            echo "<td >".$row['2']."</td>";
                            echo "<td>".utf8_encode($row['3'])."</td>";
                            while($row2 = $sql3->fetch_array()){echo "<td style='width:auto;'>".utf8_encode($row2[1])."</td>";}
                            while($row1 = $sql2->fetch_array()){echo "<td style='width:200px;'>".$row1[2]."( ".utf8_encode($row1[1]).")</td>";}
                            echo "<td> <a class='colorbox' title='Editar' href='./Modulos/Usuario/usuario.php?accion=edicion&idusuario=".$row['id_usuario']."'><img src='images/026.png' width='22px' height='22px'></a></td>";
                            echo "<td> <a class='colorbox' title='Eliminar' href='./Modulos/Usuario/usuario.php?accion=eliminar&idusuario=".$row['id_usuario']."'><img src='images/020.png' width='22px' height='22px'></a></td>";
                            }?>
                            </tr> 
                        </table>
                       </div>
                            
         <!-- FIN ADMINISTRACION DE USUARIOS --> 
         <!-- ACTIVIDADES ELIMINADAS -->  
                       <div class="pestana" id="tab-3" align="center">

                      		                            <h2>Actividades Eliminadas por Usuarios de mi Coordinacion.</h2>
                                                    <h2>Las Actividades que estan no marcadas, Es porque no se han aprobado para eliminacion.</h2>
                                            <?php
                                         @session_start();  require("config.php");  
                                            @$fecha=$_GET['fecha'];
                                            
                                            $query_e=$db->query("(SELECT * from cronograma inner join usuario on usuario.id_usuario=cronograma.id_usuario where cronograma.activo=0 and cronograma.id_anterior='1' and cronograma.id_usuario='".$_SESSION['usua']."'
                                                                     ORDER BY cronograma.fecha desc )
                                                                     union
                                                                     (SELECT * from cronograma inner join usuario on usuario.id_usuario=cronograma.id_usuario where cronograma.activo=0 and cronograma.id_anterior='1' and   idcoordinacion='".$_SESSION['usua']."'
                                                                     ORDER BY cronograma.fecha desc  )");
                                            
                                                            echo '<div class="">
                                                            <table cellspacing="0" cellpadding="0">
                                                                 <thead>
                                                                  <tr>
                                                                  <th width="110px" >Fecha</th>
                                                                    <th width="100px" >Hora</th>
                                                                    <th >Comunidad</th>
                                                                    <th >Pob. Objeto</th>
                                                                    <th >Tipo de Act.</th>
                                                                    <th >Cargo</th>
                                                                    <th >Nombre</th>
                                                                    <th >Reactivar</th>
                                                                    <th >Eliminar VoBo</th>';
                                                                    
                                                ?>
                                                
                                              </tr>
                                              </thead>
                                            <tbody><?php $num=0; $sum=0;
                                                /**/
                                                                        $band=0;
                                                                    $row_cnt = $query_e->num_rows; 	
                                                                        //while($ev=$query_e->num_rows()){ $sum=$ev["aval"]+$sum; }
                                                                        $cont=0;
                                                            if($ev=$query_e->fetch_array()){
                                                            do{ $sum=$ev["aval"]+$sum;//echo $sum; 
                                                            $cont++;$cnt=0;$comnuni="";	////////////////////////////////////////////////
                                                            
                                                                
                                                                
                                                                
                                                                $piezas = explode(",", $ev["id_comunidad"]);
                                                                while (count($piezas)>$cnt){
                                                                    $sql=$db->query("SELECT comunidad, municipio,id_comunidad FROM municipio INNER JOIN comunidad ON municipio.id_municipio=comunidad.id_municipio where id_comunidad='".$piezas[$cnt]."'");
                                                                        $comn=$sql->fetch_array();
                                                                                //echo $comn[0]."-".$comn[1];
                                                                            
                                                                                if($piezas[$cnt]=='cen'){$comnuni='Centro Poblado'.','.$comnuni;}else{	
                                                                                    if($piezas[$cnt]=='cas'){$comnuni='Casco Urbano'.','.$comnuni;}
                                                                                            else
                                                                                             {$comnuni=$comn[0].','.$comnuni;}
                                                                                                                
                                                                                }	$cnt=$cnt+1;
                                                                }
                                                            
                                                                $comnuni = trim($comnuni, ','); 
                                                            /////////////////////////////////////////////////
                                                            $query_pb=$db->query("SELECT
                                                                                      cronograma.id_anterior,
                                                                                      cargo.nombre,
                                                                                      usuario.nombre_u,
                                                                                      cronograma.id_cronograma,
                                                                                      cronograma.activo
                                                                                    FROM
                                                                                      municipio
                                                                                      INNER JOIN comunidad ON comunidad.id_municipio =
                                                                                        municipio.id_municipio
                                                                                      INNER JOIN cronograma ON comunidad.id_comunidad =
                                                                                        cronograma.id_comunidad
                                                                                      INNER JOIN usuario ON usuario.id_usuario = cronograma.id_usuario
                                                                                      INNER JOIN cargo ON usuario.Idcargo = cargo.idcargo
                                                                                    WHERE
                                                                                      cronograma.id_cronograma ='".$ev["id_cronograma"]."'  ;");
                                                                        $evp=$query_pb->fetch_array();
                                                                    $query_ac=$db->query("select * from actividad where id_actividad='".$ev["id_actividad"]."'");
                                                                        $evac=$query_ac->fetch_array();
                                                                        $query_pbb=$db->query("select * from poblacion where idpoblacion='".$ev["idpoblacion"]."'");
                                                                        $evpb=$query_pbb->fetch_array();
                                                    
                                                    if($cont==$row_cnt)
                                                            {
                                                    if($sum==$row_cnt)
                                                            {   /*   echo "<div id='mens'> <p  class='ok'>Haga Clic <a href='crono.php' class=''>aqui<img src='images/check.png' width='32' height='32'></a>y continuar programando, las actividades del Proximo mes. </p></div>";
                                                             }else{if($_SESSION['coord']<>0){
                                                                 echo "<div id='mens'><p  class='ko'><img src='images/check1.png' width='32' height='32'></a>pongase en contacto con su coordinador para poder continuar programando las actividades.</p></div>";
                                                                 }else{
                                                                 echo "<div id='mens'><p  class='ko'>Haga Clic<a href='#' class='av'>aqui<img src='images/check1.png' width='32' height='32'></a>para Dar VoBo a estas actividades y 	continuar programando sus actividades.</p></div>";}
                                                            */}	 }
                                                            
                                                            
                                                            
                                                            
                                                            if($num==0){$num=1;   ?>
                                                                  <tr>
                                                                  <td><?php  echo $ev["fecha"]; ?></td>
                                                                    <td><?php echo "(".$ev["hora_i"]."-".$ev["hora_f"].")"; ?></td>
                                                                    <td><?php echo utf8_encode($comnuni); ?></td>
                                                                    <td><?php echo $evpb["nombre"]; ?></td>
                                                                    <td><?php echo utf8_encode($evac["nombre_act"]); ?></td>
                                                                    <td><?php echo $evp["nombre"]; ?></td>
                                                                    <td><?php echo $ev["nombre_u"]; ?></td>
                                                                    <td ><label class="toggle" id="<?php echo $ev["id_cronograma"]; ?>" oper="reactivar" > 
                                                                            <input  <?php if($evp['id_anterior']==1){ echo "checked ";} ?> class="<?php echo $ev["id_cronograma"]; ?>" type="checkbox" > <span  data-unchecked="No" data-checked="Ok"> </span>
                                                                         </label></td>
                                                                         <td ><label class="toggle" id="<?php echo $ev["id_cronograma"]; ?>" oper="aprobada"  >
                                                                             <input <?php if($ev['id_estado']==1){ echo "checked ";} ?> class="<?php echo $ev["id_cronograma"]; ?>" type="checkbox"><span  data-unchecked="No" data-checked="VoBo"> </span></label></td>
                                                                 
                                                                 </tr>
                                                                <?php }else{$num=0;?> 
                                                                 <tr class="alt">
                                                                 <td><?php echo $ev["fecha"]; ?></td>
                                                                 <td><?php echo "(".$ev["hora_i"]."-".$ev["hora_f"].")"; ?></td>
                                                                <td><?php echo utf8_encode($comnuni); ?></td>
                                                                <td><?php echo $evpp["nombre"]; ?></td>
                                                                <td><?php echo utf8_encode($evac["nombre_act"]); ?></td>
                                                                <td><?php echo $evp["nombre"]; ?></td>
                                                                <td><?php echo $ev["nombre_u"]; ?></td>
                                                                <td ><label class="toggle" id="<?php echo $ev["id_cronograma"]; ?>" oper="reactivar" > 
                                                                        <input <?php if($evp['id_anterior']==1){ echo "checked ";} ?> class="<?php echo $ev["id_cronograma"]; ?>" type="checkbox"> 
                                            <span  data-unchecked="No" data-checked="Ok"> </span>
                                                                    </label></td>
                                                                    <td ><label class="toggle" id="<?php echo $ev["id_cronograma"]; ?>" oper="aprobada"  > 
                                                                    <input <?php if($ev['id_estado']==1){ echo "checked ";} ?> class="<?php echo $ev["id_cronograma"]; ?>" type="checkbox"> <span  data-unchecked="No" data-checked="VoBo"> </span></label></td>
                                                                 
                                                                 </tr>
                                                            <?php }
                                                            }while($ev=$query_e->fetch_array());}
                                                    echo '</tbody></table> </div>';
                                            ?>
                                                
                                               
                       </div>             
      	 <!-- </div>FIN ACTIVIDADES ELIMINADAS --> 
         <!--  ACTIVIDADES ELIMINADAS POR USUARIOS PERTENECIENTES A COORDINACIONES --> 
         				<div class="pestana" id="tab-4" align="center">

        							 
                                <h2>Activiadades eliminadas. </h2>
                                <h2>Espacios Liberados, en las Comunidades</h2>
                      <?php @session_start();  require("config.php");  
                     
                        @$fecha=$_GET['fecha'];
                        
                        $query_e=$db->query("SELECT
                                              cronograma.id_cronograma,
                                              cronograma.id_comunidad,
                                              cronograma.fecha,
                                              cronograma.id_estado,
                                              cronograma.activo,
                                              cronograma.id_anterior,
                                              cronograma.hora_i,
                                              cronograma.hora_f,
                                              cronograma.id_actividad,
                                              cronograma.id_operador,
                                              cronograma.descripcion,
                                              cronograma.aval,
                                              cronograma.casco,
                                              cronograma.realizada,
                                              cronograma.lugar,
                                              cronograma.idpoblacion,
                                              cronograma.id_usuario,
                                              usuario.nombre_u
                                            FROM
                                              cronograma
                                              INNER JOIN usuario ON cronograma.id_usuario = usuario.id_usuario
                                            WHERE
                                              (cronograma.id_estado = 1)and
                                              (cronograma.activo = 1) and
                                              (cronograma.id_anterior = 1)  and cronograma.fecha > now()
                                            ORDER BY
                                              cronograma.fecha; ");
                        
                                        echo '<div class="">
										<table class="" cellspacing="0" cellpadding="0">
                                             <thead>
                                              <tr>
                                              <th width="110px" >Fecha</th>
                                                <th width="100px" >Hora</th>
                                                <th >Comunidad</th>
                                                <th >Pob. Objeto</th>
                                                <th >Tipo de Act.</th>
                                                <th >Cargo</th>
                                                <th >Nombre</th>
                                                ';
                                                
                            ?>
                            
                          </tr>
                          </thead>
                        <tbody>
                        <?php $num=0; $sum=0;
                            /**/
                                                    $band=0;
                                                $row_cnt = $query_e->num_rows; 	
                                                    //while($ev=$query_e->num_rows()){ $sum=$ev["aval"]+$sum; }
                                                    $cont=0;
                                        if($ev=$query_e->fetch_array()){
                                        do{ $sum=$ev["aval"]+$sum;//echo $sum; 
                                        $cont++;$cnt=0;$comnuni="";	
                                        ////////////////////////////////////////////////
                                                                            $piezas = explode(",", $ev["id_comunidad"]);
                                                                        while (count($piezas)>$cnt){
                                                                            $sql=$db->query("SELECT comunidad, municipio,id_comunidad FROM municipio INNER JOIN comunidad ON municipio.id_municipio=comunidad.id_municipio where id_comunidad='".$piezas[$cnt]."'");
                                                                                $comn=$sql->fetch_array();
                                                                                        //echo $comn[0]."-".$comn[1];
                                                                                    
                                                                                        if($piezas[$cnt]=='cen'){$comnuni='Centro Poblado'.','.$comnuni;}else{	
                                                                                            if($piezas[$cnt]=='cas'){$comnuni='Casco Urbano'.','.$comnuni;}
                                                                                                    else
                                                                                                     {$comnuni=$comn[0].','.$comnuni;}
                                                                                                                        
                                                                                        }	$cnt=$cnt+1;
                                                                        }
                                                                    
                                                                        $comnuni = trim($comnuni, ','); 
                                        /////////////////////////////////////////////////
                                        $query_pb=$db->query("SELECT
                                                                  cronograma.id_anterior,
                                                                  cargo.nombre,
                                                                  usuario.nombre_u,
                                                                  cronograma.id_cronograma,
                                                                  cronograma.activo
                                                                FROM
                                                                  municipio
                                                                  INNER JOIN comunidad ON comunidad.id_municipio =
                                                                    municipio.id_municipio
                                                                  INNER JOIN cronograma ON comunidad.id_comunidad =
                                                                    cronograma.id_comunidad
                                                                  INNER JOIN usuario ON usuario.id_usuario = cronograma.id_usuario
                                                                  INNER JOIN cargo ON usuario.Idcargo = cargo.idcargo
                                                                WHERE
                                                                  cronograma.id_cronograma ='".$ev["id_cronograma"]."'  ;");
                                                    $evp=$query_pb->fetch_array();
                                                $query_ac=$db->query("select * from actividad where id_actividad='".$ev["id_actividad"]."'");
                                                    $evac=$query_ac->fetch_array();
                                                    $query_pbb=$db->query("select * from poblacion where idpoblacion='".$ev["idpoblacion"]."'");
                                                    $evpb=$query_pbb->fetch_array();
                                
                               
                                        if($num==0){$num=1;   ?>
                                              <tr>
                                              <td><?php  echo $ev["fecha"]; ?></td>
                                                <td><?php echo "(".$ev["hora_i"]."-".$ev["hora_f"].")"; ?></td>
                                                <td><?php echo utf8_encode($comnuni); ?></td>
                                                <td><?php echo $evpb["nombre"]; ?></td>
                                                <td><?php echo utf8_encode($evac["nombre_act"]); ?></td>
                                                <td><?php echo $evp["nombre"]; ?></td>
                                                <td><?php echo $ev["nombre_u"]; ?></td>
                                             </tr>
                                            <?php }else{$num=0;?> 
                                             <tr class="alt" bgcolor="#3dc">
                                             <td><?php echo $ev["fecha"]; ?></td>
                                             <td><?php echo "(".$ev["hora_i"]."-".$ev["hora_f"].")"; ?></td>
                                            <td><?php echo utf8_encode($comnuni); ?></td>
                                            <td><?php echo $evpb["nombre"]; ?></td>
                                            <td><?php echo utf8_encode($evac["nombre_act"]); ?></td>
                                            <td><?php echo $evp["nombre"]; ?></td>
                                            <td><?php echo $ev["nombre_u"]; ?></td>
                                             </tr>
                                        <?php }
                                        }while($ev=$query_e->fetch_array());}
                                echo '</tbody></table> </div>';
                        ?>
                                
                        </div>
     	 <!-- FIN  ACTIVIDADES ELIMINADAS POR USUARIOS PERTENECIENTES A COORDINACIONES --> 
         <!-- REGISTRO DE COORDIANCIONES QUE NO Y SI REGISTRARON ACTIVIDADES -->    
					<?php if($_SESSION['opera']=='1' or $_SESSION['opera']=='2'){ ?>
                     	<div class="pestana" id="tab-5" align="center">
                          	<p>Aqui presenta las coordinaciones que no hayan registrado sus actividades del siguiente mes.</p>
                           			  <?php
@session_start();  require("config.php");
?>
<h3>Coordinador con Actividad Registradas.</h3>
  <table cellspacing="0" cellpadding="0">
	<tr>
		<th >Coordinacion</th>
        <th >Nombre</th>
   	</tr> 
    
<?php

$ano_mes = substr($_SESSION['fecha'],0,7);
				$ano_mes=$ano_mes."-30";
				//echo $ano_mes; 
				$qls="SELECT	  usuario.nombre_u,
						  usuario.id_usuario,
						  usuario.Idcargo
					from 
								  cronograma
								  RIGHT OUTER JOIN usuario ON cronograma.id_usuario =
									usuario.id_usuario
					where   
								  (cronograma.fecha > '".$ano_mes."' AND
								  cronograma.activo ='0' AND cronograma.aval='0')and  estado='0' and idcoordinacion='0'";
		  	    
					  $resultado=mysql_query($qls);
	while($rw=mysql_fetch_array($resultado))
		{		echo "<tr>"; 
					$sql3="SELECT * from cargo where    idcargo='".$rw['2']."'";
						$resulta=mysql_query($sql3);		
		 		while ($row2=mysql_fetch_array($resulta))
					{ echo "<td style='text-align:right;  padding-right: 12px;'>".utf8_encode($row2['1'])."</td>";}	
					 		echo "<td style='text-align:left;padding-left: 12px;' >".$rw['0']."</td>";	echo "</tr>";
 	
		}?>
  	
</table>
<h3>Coordinador sin Actividad Registradas.</h3>
 <table cellpadding="0" cellspacing="0">
	<tr>
		<th >Coordinacion</th>
        <th >Nombre</th>
	</tr> 
<?php

	$ano_mes = substr($_SESSION['fecha'],0,7);
				$ano_mes=$ano_mes."-30";
				//echo $ano_mes; 
$qls="select usuario.nombre_u, usuario.id_usuario, usuario.Idcargo  from usuario LEFT JOIN 
							(select usuario.nombre_u,
								  usuario.id_usuario,
								  usuario.Idcargo
							from cronograma
									  left join usuario ON cronograma.id_usuario = usuario.id_usuario
							where   
							     (cronograma.fecha > '".$ano_mes."' AND 
							      cronograma.activo ='0' AND cronograma.aval='0')) AS USU ON 
					USU.id_usuario=usuario.id_usuario
					where    USU.id_usuario is NULL AND estado='0' AND idcoordinacion='0'";
					
		$resultado=mysql_query($qls);
	while ($rw=mysql_fetch_array($resultado))
		{		echo "<tr >"; 
						$sql3="SELECT * from cargo where    idcargo='".$rw['2']."'";
						$resulta=mysql_query($sql3);
		 		while ($row2=mysql_fetch_array($resulta))
					{ echo "<td style='text-align:right; padding-right: 12px;'>".utf8_encode($row2['1'])."</td>";}
					 		echo "<td style='text-align:left; padding-left: 12px;' >".$rw['0']."</td>";
							echo "</tr>";
								}?>
  	
</table>
                        </div>
                  	<?php  } ?>
         <!-- FIN REGISTRO DE COORDIANCIONES QUE NO Y SI REGISTRARON ACTIVIDADES -->                   
	
</div>
<?php
}else{ echo "<div class='calendar' data-color='normal' style='width:780px'><h1>Debe Iniciar Sesion.</h1> <br /></div>"; }?>	
        
	
	

</body>
</html>