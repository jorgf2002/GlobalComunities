 <?php header('Content-Type: text/html; charset=utf-8');
 require_once("config.php"); 
 
 
 
 echo "<option value='".$eventos[0]."'>".$_POST["com"]."</option>";
 
 
 $query_eventos=$db->query("SELECT * FROM comunidad where id_municipio='".$_POST["elegido"]."'");
	
	while ($eventos=$query_eventos->fetch_array())
 		{   if ($eventos["id_comunidad"]==$_POST["com"])
				{ echo "<option selected value='".$eventos[0]."'>".$eventos[1]."</option>"; }
		  	 echo utf8_encode("<option value='".$eventos[0]."'>".$eventos[1]."</option>"); 
		} 
												
 
 ?>
