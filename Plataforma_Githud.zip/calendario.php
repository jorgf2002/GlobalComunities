<?php
			/* BUSCAMOS EVENTOS */
				$query_eventos=$db->query("SELECT actividad.nombre_act,sigla_act,cargo.nombre,comunidad.comunidad,municipio.municipio,
			operador.nombre_op,operador.sigla,cronograma.hora_i,cronograma.hora_f,cronograma.descripcion,cronograma.id_actividad,usuario.nombre_u,cronograma.fecha,id_cronograma,idpoblacion  
 				FROM cronograma 
					inner join usuario on cronograma.id_usuario=usuario.id_usuario
					inner join actividad on actividad.id_actividad=cronograma.id_actividad
					inner join comunidad on comunidad.id_comunidad=cronograma.id_comunidad
					inner join municipio on municipio.id_municipio=comunidad.id_municipio
					inner join cargo on cargo.idcargo=usuario.idcargo
					inner join operador on operador.id_operador=usuario.id_operador  where id_estado=0 order by cronograma.hora_i asc");
				if ($eventos=$query_eventos->fetch_array())
				{
				do
				{
				?>
				<div data-role="day" data-day="<?php $fecha=explode("-",$eventos["fecha"]); echo $fecha[0].intval($fecha[1]).intval($fecha[2]); ?>">
           
                 <div data-role='event' data-idevento='<?php echo $eventos['id_cronograma']; ?>' data-name='<?php echo $eventos["fecha"];/* "(".$eventos['7']."-".$eventos['8'].")".$eventos['1']."-".$eventos['2']."-".$eventos['11']."-".utf8_encode($eventos['3']);*/ ?>'		>				
						</div>
				</div>
				<?php 
				}while($eventos=$query_eventos->fetch_array());
			}
			?>