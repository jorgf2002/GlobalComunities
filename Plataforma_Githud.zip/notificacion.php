  <!-- ACTIVIDADES ELIMINADAS -->  
  
          <script type="text/javascript"> //check box 1
      $('.toggle').change(function(e){ 
          pp=$(this).attr('oper');
      //alert(pp);
        var idd= $(this).attr('id');
        if($('.'+idd).is(':checked')) { alert("Está activado 1"+idd); 
                        act=1;} else { alert("No está activado 0"+idd); 
                        act=0;}
             $.ajax({
                       type: "POST",
                       url: "consulta_act.php",
                       data: 'act=' + act+'&idd='+idd+'&acc='+pp,
                         success: function(data) {
                    //alert(data);
                    }
                  }); 
                });</script>
                 <h5 class="color_azul" align="center">Actividades Eliminadas por Usuarios de mi Coordinacion.</h5>
                 <h6 class="color_azul" align="center">Las Actividades que estan no marcadas, Es porque no se han aprobado para eliminacion.</h6>
                <?php
                      @session_start();  require("config.php");  
                      @$fecha=$_GET['fecha'];                                            
                       $query_e=$db->query("(SELECT * from cronograma inner join usuario on usuario.id_usuario=cronograma.id_usuario where cronograma.activo=0 and cronograma.id_anterior='1' and cronograma.id_usuario='".$_SESSION['usua']."'
                                                                     ORDER BY cronograma.fecha desc )
                                                                     union
                                                                     (SELECT * from cronograma inner join usuario on usuario.id_usuario=cronograma.id_usuario where cronograma.activo=0 and cronograma.id_anterior='1' and   idcoordinacion='".$_SESSION['usua']."'
                                                                     ORDER BY cronograma.fecha desc  )");
                                            
                                                            echo '<div id="content">
                                                            <table >
                                                                 <thead>
                                                                  <tr>
                                                                  <th width="110px" >Fecha</th>
                                                                    <th width="100px" >Hora</th>
                                                                    <th >Comunidad</th>
                                                                    <th >Pob. Objeto</th>
                                                                    <th >Tipo de Act.</th>
                                                                    <th >Cargo</th>
                                                                    <th >Nombre</th>
                                                                    <th >Reactivar</th>
                                                                    <th >Eliminar VoBo</th>';
                                                  ?>                                                
                                              </tr>
                                              </thead>
                                            <tbody><?php $num=0; $sum=0;
                                                           $band=0;
                                                           $row_cnt = $query_e->num_rows;  
                                                                        //while($ev=$query_e->num_rows()){ $sum=$ev["aval"]+$sum; }
                                                                        $cont=0;
                                                            if($ev=$query_e->fetch_array()){
                                                            do{ $sum=$ev["aval"]+$sum;//echo $sum; 
                                                            $cont++;$cnt=0;$comnuni=""; ////////////////////////////////////////////////
                                                                         $piezas = explode(",", $ev["id_comunidad"]);
                                                                while (count($piezas)>$cnt){
                                                                    $sql=$db->query("SELECT comunidad, municipio,id_comunidad FROM municipio INNER JOIN comunidad ON municipio.id_municipio=comunidad.id_municipio where id_comunidad='".$piezas[$cnt]."'");
                                                                        $comn=$sql->fetch_array();
                                                                                //echo $comn[0]."-".$comn[1];
                                                                            
                                                                                if($piezas[$cnt]=='cen'){$comnuni='Centro Poblado'.','.$comnuni;}else{  
                                                                                    if($piezas[$cnt]=='cas'){$comnuni='Casco Urbano'.','.$comnuni;}
                                                                                            else
                                                                                             {$comnuni=$comn[0].','.$comnuni;}
                                                                                                                
                                                                                } $cnt=$cnt+1;
                                                                }
                                                            
                                                                $comnuni = trim($comnuni, ','); 
                                                            /////////////////////////////////////////////////
                                                            $query_pb=$db->query("SELECT
                                                                                      cronograma.id_anterior,
                                                                                      cargo.nombre,
                                                                                      usuario.nombre_u,
                                                                                      cronograma.id_cronograma,
                                                                                      cronograma.activo
                                                                                    FROM
                                                                                      municipio
                                                                                      INNER JOIN comunidad ON comunidad.id_municipio =
                                                                                        municipio.id_municipio
                                                                                      INNER JOIN cronograma ON comunidad.id_comunidad =
                                                                                        cronograma.id_comunidad
                                                                                      INNER JOIN usuario ON usuario.id_usuario = cronograma.id_usuario
                                                                                      INNER JOIN cargo ON usuario.Idcargo = cargo.idcargo
                                                                                    WHERE
                                                                                      cronograma.id_cronograma ='".$ev["id_cronograma"]."'  ;");
                                                                        $evp=$query_pb->fetch_array();
                                                                    $query_ac=$db->query("select * from actividad where id_actividad='".$ev["id_actividad"]."'");
                                                                        $evac=$query_ac->fetch_array();
                                                                        $query_pbb=$db->query("select * from poblacion where idpoblacion='".$ev["idpoblacion"]."'");
                                                                        $evpb=$query_pbb->fetch_array();
                                                    
                                                    if($cont==$row_cnt)
                                                            {
                                                    if($sum==$row_cnt)
                                                            {   /*   echo "<div id='mens'> <p  class='ok'>Haga Clic <a href='crono.php' class=''>aqui<img src='images/check.png' width='32' height='32'></a>y continuar programando, las actividades del Proximo mes. </p></div>";
                                                             }else{if($_SESSION['coord']<>0){
                                                                 echo "<div id='mens'><p  class='ko'><img src='images/check1.png' width='32' height='32'></a>pongase en contacto con su coordinador para poder continuar programando las actividades.</p></div>";
                                                                 }else{
                                                                 echo "<div id='mens'><p  class='ko'>Haga Clic<a href='#' class='av'>aqui<img src='images/check1.png' width='32' height='32'></a>para Dar VoBo a estas actividades y  continuar programando sus actividades.</p></div>";}
                                                            */}  }
                                                        if($num==0){$num=1;   ?>
                                                                  <tr>
                                                                  <td><?php  echo $ev["fecha"]; ?></td>
                                                                    <td><?php echo "(".$ev["hora_i"]."-".$ev["hora_f"].")"; ?></td>
                                                                    <td><?php echo utf8_encode($comnuni); ?></td>
                                                                    <td><?php echo $evpb["nombre"]; ?></td>
                                                                    <td><?php echo utf8_encode($evac["nombre_act"]); ?></td>
                                                                    <td><?php echo $evp["nombre"]; ?></td>
                                                                    <td><?php echo $ev["nombre_u"]; ?></td>
                                                                    <td ><label class="toggle" id="<?php echo $ev["id_cronograma"]; ?>" oper="reactivar" >     <input  <?php if($evp['id_anterior']==1){ echo "checked ";} ?> class="<?php echo $ev["id_cronograma"]; ?>" type="checkbox" > <span  data-unchecked="No" data-checked="Ok"> </span>
                                                                         </label></td>
                                                                         <td ><label class="toggle" id="<?php echo $ev["id_cronograma"]; ?>" oper="aprobada"  >
                                                                             <input <?php if($ev['id_estado']==1){ echo "checked ";} ?> class="<?php echo $ev["id_cronograma"]; ?>" type="checkbox"><span  data-unchecked="No" data-checked="VoBo"> </span></label></td>
                                                                 
                                                                 </tr>
                                                                <?php }else{$num=0;?> 
                                                                 <tr class="alt">
                                                                 <td><?php echo $ev["fecha"]; ?></td>
                                                                 <td><?php echo "(".$ev["hora_i"]."-".$ev["hora_f"].")"; ?></td>
                                                                <td><?php echo utf8_encode($comnuni); ?></td>
                                                                <td><?php echo $evpb["nombre"]; ?></td>
                                                                <td><?php echo utf8_encode($evac["nombre_act"]); ?></td>
                                                                <td><?php echo $evp["nombre"]; ?></td>
                                                                <td><?php echo $ev["nombre_u"]; ?></td>
                                                                <td ><label class="toggle" id="<?php echo $ev["id_cronograma"]; ?>" oper="reactivar" > 
                                                                        <input <?php if($evp['id_anterior']==1){ echo "checked ";} ?> class="<?php echo $ev["id_cronograma"]; ?>" type="checkbox"> 
                                            <span  data-unchecked="No" data-checked="Ok"> </span>
                                                                    </label></td>
                                                                    <td ><label class="toggle" id="<?php echo $ev["id_cronograma"]; ?>" oper="aprobada"  > 
                                                                    <input <?php if($ev['id_estado']==1){ echo "checked ";} ?> class="<?php echo $ev["id_cronograma"]; ?>" type="checkbox"> <span  data-unchecked="No" data-checked="VoBo"> </span></label></td>
                                                                 
                                                                 </tr>
                                                            <?php }
                                                            }while($ev=$query_e->fetch_array());}
                                                    echo '</tbody></table> </div>';
                                            ?>
                                                
                                               
                              
         <!-- </div>FIN ACTIVIDADES ELIMINADAS --> 