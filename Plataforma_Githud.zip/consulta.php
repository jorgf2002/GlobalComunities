<?php
header('Content-Type: text/html; charset=utf-8'); 
?>
<script type="text/javascript">
//check box 1
             $('.switch').change(function(e){ 
		            pp=$(this).attr('oper');
		            /////////////////////////////
		              var idd= $(this).attr('id');
		              if($('.'+idd).is(':checked')) { //alert("Está activado 1"+idd); 
		                              act=1;} else { //alert("No está activado 0"+idd); 
		                              act=0;}
		            //alert(idd);
		            $.ajax({
		                       type: "POST",
		                       url: "consulta_act.php",
		                       data: 'act=' + act+'&idd='+idd+'&acc='+pp,
		                         success: function(data) {
		                    //alert(data);
		                    }
		                  }); 
                });

             $('#evalua').keyup(function(e){alert($(this).val());
             			$(".specific-day-scheme").load('consulta.php?fecha='+global);

             			 $.ajax({
                       type: "POST",
                        url: "consulta_act.php",
                       data: 'act=' + act+'&idd='+idd+'&acc='+pp,
                         success: function(data) {
                    //alert(data);
                    }
                  }); 


             })
        ///////////////
        </script>
<style type="text/css">


</style>

<?php
require_once("config.php"); 
@session_start(); 
$fecha=$_GET['fecha'];
/*$sql_cadena=$_GET['sql_cadena'];

if ($fecha=="") {
	$sql_cadena="";
}else{ $sql_cadena="";}*/



$query_e=$db->query("SELECT actividad.nombre_act,actividad.sigla_act, cargo.nombre,  operador.nombre_op, operador.sigla, cronograma.hora_i,
							cronograma.hora_f, cronograma.descripcion, cronograma.id_actividad, usuario.nombre_u, cronograma.fecha,
							cronograma.id_cronograma, cronograma.fecha,cronograma.idpoblacion,cronograma.id_comunidad,  cronograma.realizada,cronograma.id_usuario
								FROM cronograma
								INNER JOIN usuario ON cronograma.id_usuario = usuario.id_usuario
								INNER JOIN actividad ON actividad.id_actividad = cronograma.id_actividad
								INNER JOIN cargo ON cargo.idcargo = usuario.idcargo
								INNER JOIN operador ON operador.id_operador = usuario.id_operador
								WHERE id_estado =0 and id_anterior=0
								AND cronograma.fecha =  '".$fecha."'
								ORDER BY cronograma.hora_i, cronograma.hora_f ASC ");
				echo '<div id="content" class="" align="center">';
			$hoy=date("Y-m-d");if($fecha>=$hoy){  
									 echo $_SESSION['cuanto']."--".$_SESSION['cuantas'];
									if($_SESSION['cuanto']==$_SESSION['cuanto'])
									{ 	echo ' <div class="button raised grey narrow label-red">
														<div class="center colorbox" title="Agregar Actividad" href="ajax.php?accion=insertar&dia='.$fecha.'" fit>
															<img src="images/021.png" width="22px" height="22px">
														</div>
														<paper-ripple fit></paper-ripple>
												   </div>';
									}else{echo "<p class='ok'>Para Crear una actividad. Debe dar un VoBo de las actividades del mes Anterior.</p>";
										 }	   }
				echo '<table>
						 <thead>
						  <tr><th>#</th>
						    <th>Hora</th>
						    <th width="auto" >Comunidad</th>
						    <th>Pob. Objeto</th>
						    <th>Tipo de Act.</th>
						    <th>Cargo</th>
						    <th width="auto">Nombre</th>
							<th></th>
							<th></th>
							<th></th>
						  </tr>
						  </thead>
						<tbody>';
						$num=0;	$numero=0;
				while($ev=$query_e->fetch_array())
				{	$comnuni="";$cnt=0;$piezas = explode(",", $ev["id_comunidad"]);				
					while (count($piezas)>$cnt)
				    {  $sql=$db->query("SELECT comunidad, municipio,id_comunidad 
										   FROM municipio 
										   INNER JOIN comunidad ON municipio.id_municipio=comunidad.id_municipio 
										   WHERE id_comunidad='".$piezas[$cnt]."'");
										$comn=$sql->fetch_array();
										$comnuni=$comn[1].' - '.$comn[0].','.$comnuni;$cnt=$cnt+1;
					}
					$comnuni = trim($comnuni, '- ,');
					
					$query_pb=$db->query("select * from poblacion where idpoblacion='".$ev["idpoblacion"]."'");
							$evp=$query_pb->fetch_array();
						$query_ac=$db->query("select * from actividad where id_actividad='".$ev["id_actividad"]."'");
							$evac=$query_ac->fetch_array();
							$numero++;
				if($num==0){$num=1;						
					?>
                	  <tr class="teh">
                	  <td><?php echo $numero;  ?></td>
                      	<td><?php echo "(".$ev["hora_i"]."-".$ev["hora_f"].")"; ?></td>
                      	<td><?php echo utf8_encode( $comnuni); ?></td>
   						<td><?php echo $evp["nombre"]; ?></td>
    					<td><?php echo utf8_encode( $evac["nombre_act"]); ?></td>
    					<td><?php echo utf8_encode($ev["nombre"]); ?></td>
    					<td><?php echo $ev["nombre_u"]; ?></td>
   					<td>  <a class="colorbox" bandera="E" title="Editar &rArr; <?php echo $ev["descripcion"]; ?>" href="ajax.php?accion=edicion&idevento=<?php echo $ev["id_cronograma"]; ?>"><img src="images/026.png" width="22px" height="22px"></a>
   					</td>
   					<td > <?php if($fecha>=$hoy){  ?>
				                    <a class="colorbox" bandera="E" title="Eliminar" href="ajax.php?accion=eliminar&idevento=<?php echo  $ev["id_cronograma"]; ?>">
				                    <img src="images/020.png" width="22px" height="22px"></a>      
				                     <?php }?> 
					</td>
					<td ><?php  if(($fecha<=$hoy)&&($_SESSION['usua']==$ev["id_usuario"])){ ?> <div class="switch" id="<?php echo $ev["id_cronograma"]; ?>" oper="realizada">
                                                <label>
                                                  
                                                  <input <?php if($ev['realizada']==1){ echo "checked ";} ?> class="<?php echo $ev["id_cronograma"]; ?>" type="checkbox">
                                                  <span class="lever" data-unchecked="No" data-checked="Ok"> </span>
                                              
                                                </label>
                                              </div>
                          <?php } ?></td>
					
 					</tr>
                    <?php   }else{$num=0;?> 
                     <tr class="color_azul">
                      	  <td><?php echo $numero;  ?></td>
                     	  <td><?php echo "(".$ev["hora_i"]."-".$ev["hora_f"].")"; ?></td>
  					  <td><?php echo utf8_encode( $comnuni); ?></td> 
                   			<td><?php echo $evp["nombre"]; ?></td>
    						<td><?php echo utf8_encode( $evac["nombre_act"]); ?></td>
    						<td><?php echo utf8_encode($ev["nombre"]); ?></td>
    						<td><?php echo $ev["nombre_u"]; ?></td>
   						<td > <a class="colorbox" bandera="E" title="Editar &rArr; <?php echo $ev["descripcion"]; ?>" href="ajax.php?accion=edicion&idevento=<?php echo $ev["id_cronograma"]; ?>">
   						<img src="images/026.png" width="22px" height="22px"></a> 
   						</td>
   							<td > <?php if($fecha>=$hoy){  ?>
				                    <a class="colorbox" bandera="E" title="Eliminar" href="ajax.php?accion=eliminar&idevento=<?php echo  $ev["id_cronograma"]; ?>">
				                    <img src="images/020.png" width="22px" height="22px"></a>      
				                     <?php }?> 
					</td>
					<td ><?php if(($fecha<=$hoy)&&($_SESSION['usua']==$ev["id_usuario"])){ ?> <div class="switch" id="<?php echo $ev["id_cronograma"]; ?>" oper="realizada">
                                                <label>
                                                  <input <?php if($ev['realizada']==1){ echo "checked ";} ?> class="<?php echo $ev["id_cronograma"]; ?>" type="checkbox">
                                                  <span class="lever" data-unchecked="No" data-checked="Ok"> </span>
                                                </label>
                                              </div>
                          <?php } ?></td>
 				 </tr>
 				<?php }
					}
		echo '</tbody></table> </div>';  
?>