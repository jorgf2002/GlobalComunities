<?php header('Content-Type: text/html; charset=utf-8'); 
require_once("config.php"); @session_start(); 
if (isset($_POST) && count($_POST)>0)
				{	switch ($_POST["acc"])
					{	case "realizada":							
							$query_eventos=$db->query("UPDATE  cronograma  SET realizada='".$_POST["act"]."' WHERE  
														id_cronograma ='".$_POST["idd"]."'");
									if ($query_eventos) 
									{echo "El evento se ha modificado correctamente.";
									}else{ 
									echo "Se ha producido un error modificando el evento.";}
					break;
					case "aprobada":							
							$query_eventos=$db->query("UPDATE  cronograma  SET id_anterior='".$_POST["act"]."',activo='".$_POST["act"]."',id_estado='".$_POST["act"]."' WHERE id_cronograma ='".$_POST["idd"]."'");
									if ($query_eventos) 
									{echo "El evento se ha modificado correctamente.'";
									}else{ 
									echo "Se ha producido un error modificando el evento.'";}
					break;
					case "reactivar":							
							$query_eventos=$db->query("UPDATE  cronograma  SET id_anterior='".$_POST["act"]."',activo='".$_POST["act"]."',id_estado='".$_POST["act"]."' WHERE id_cronograma ='".$_POST["idd"]."'");
									if ($query_eventos) 
									{echo "El evento se ha modificado correctamente.'";
									}else{ 
									echo "Se ha producido un error modificando el evento.'";}
					break;
					case 'aval':
							$query_eventos=$db->query("UPDATE  cronograma inner join usuario on usuario.id_usuario=cronograma.id_usuario  
														SET aval='1' where  idcoordinacion=".$_SESSION['usua']."   
															  AND (year(fecha)=YEAR(NOW()) and month(fecha)=(MONTH (NOW())-1) ) or (year(fecha)>YEAR(NOW()) and month(fecha)>(MONTH (NOW())) )
															 and id_estado =0");
						 
						    $query_eventos1=$db->query("UPDATE  cronograma  SET aval='1' where  id_usuario=".$_SESSION['usua']."   
                       									  AND (year(fecha)=YEAR(NOW()) and month(fecha)=(MONTH (NOW())-1) ) or (year(fecha)>YEAR(NOW()) and month(fecha)>(MONTH (NOW())) )
															  and id_estado =0");
									if ($query_eventos&&$query_eventos1) 
									{echo "El evento se ha modificado correctamente.";
									}else{ 
									 echo "Se ha producido un error modificando el evento.";}
					break;
					
				}
				}
					
						
						?>